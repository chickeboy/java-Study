package tk2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class G {
	public static Scanner scanner = new Scanner(System.in);
	public static void remove(ArrayList<Book> bo){
		System.out.println("type");
		String type=scanner.next();
		ArrayList<Book>bi=new ArrayList<Book>();
		for (Book book : bo) {
			if(!type.equals(book.getType())){
				bi.add(book);
			}
		}
		bo=bi;
		for (Book book : bo) {
			System.out.println(book);
		}
	}
	public static void remove(LinkedList<Book> bo){
		System.out.println("type");
		String type=scanner.next();
		LinkedList<Book>bi=new LinkedList<Book>();
		for (Book book : bo) {
			if(!type.equals(book.getType())){
				bi.add(book);
			}
		}
		bo=bi;
		for (Book book : bo) {
			System.out.println(book);
		}
	}
	public static void remove(TreeSet<Book> bo){
		System.out.println("type");
		String type=scanner.next();
		TreeSet<Book>bi=new TreeSet<Book>();
		for (Book book : bo) {
			if(!type.equals(book.getType())){
				bi.add(book);
			}
		}
		bo=bi;
		for (Book book : bo) {
			System.out.println(book);
		}
	}
	public static void remove(HashSet<Book> bo){
		System.out.println("type");
		String type=scanner.next();
		HashSet<Book> bi=new HashSet<Book>();
		for (Book book : bo) {
			if(!type.equals(book.getType())){
				bi.add(book);
			}
		}
		bo=bi;
		for (Book book : bo) {
			System.out.println(book);
		}
	}
	public static void remove(TreeMap<Integer,Book> bo){
		System.out.println("type");
		String type=scanner.next();
		TreeMap<Integer,Book> bi=new TreeMap<Integer, Book>();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if(!type.equals(entry.getValue().getType())){
				bi.put(entry.getKey(), entry.getValue());
			}
		}
		bo=bi;
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry);
		}
	}
	public static void remove(HashMap<Integer,Book> bo){
		System.out.println("type");
		String type=scanner.next();
		HashMap<Integer,Book> bi=new HashMap<Integer, Book>();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if(!type.equals(entry.getValue().getType())){
				bi.put(entry.getKey(), entry.getValue());
			}
		}
		bo=bi;
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry);
		}
	}
	public static void con(ArrayList<Book> bo){
		ArrayList<Book>b=new ArrayList<Book>(bo);
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Book book : b) {
				System.out.println(book);
			}
		}
	}
	public static void con(LinkedList<Book> bo){
		LinkedList<Book> b=new LinkedList<Book>(bo);
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Book book : b) {
				System.out.println(book);
			}
		}
	}
	public static void con(HashSet<Book> bo){
		LinkedList<Book> b=new LinkedList<Book>(bo);
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Book book : b) {
				System.out.println(book);
			}
		}
	}
	public static void con(TreeSet<Book> bo){
		LinkedList<Book> b=new LinkedList<Book>(bo);
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Book book : b) {
				System.out.println(book);
			}
		}
	}
	public static void con(TreeMap<Integer,Book> bo){
		LinkedList<Book> b=new LinkedList<Book>();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.add(entry.getValue());
		}
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Entry<Integer, Book> entry : entrySet) {
				System.out.println(entry);
			}
		}
	}
	public static void con(HashMap<Integer,Book> bo){
		LinkedList<Book> b=new LinkedList<Book>();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.add(entry.getValue());
		}
		Collections.sort(b);
		if(b.size()>=5){
		int i=0;
		while(i++<5){
			System.out.println(b.get(i));
		}}else{
			for (Entry<Integer, Book> entry : entrySet) {
				System.out.println(entry);
			}
		}
	}
	public static int look(ArrayList<Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		for (int i = 0; i < bo.size(); i++) {
			if (t == bo.get(i).getId()) {
				t = i;
				break;
			}
		}
		return t;
	}

	public static void lookName(ArrayList<Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		for (int i = 0; i < bo.size(); i++) {
			if (name.equals(bo.get(i).getName())) {
				System.out.println(bo.get(i));
			}
		}
		
	}

	public static void lookName(LinkedList<Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		for (int i = 0; i < bo.size(); i++) {
			if (name.equals(bo.get(i).getName())) {
				System.out.println(bo.get(i));
			}
		}
	}

	public static void lookName(HashSet<Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		for (Book book : bo) {
			if (name.equals(book.getName())) {
				System.out.println(book);
			}
		}

	}

	public static void lookName(TreeSet<Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		for (Book book : bo) {
			if (name.equals(book.getName())) {
				System.out.println(book);
			}
		}

	}

	public static void lookName(HashMap<Integer, Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (name.equals(entry.getValue().getName())) {
				System.out.println(entry.getKey() + "+" + entry.getValue());
			}
		}
	}

	public static void lookName(TreeMap<Integer, Book> bo) {
		System.out.println("name");
		String name = scanner.next();
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (name.equals(entry.getValue().getName())) {
				System.out.println(entry.getKey() + "+" + entry.getValue());
			}
		}
	}

	public static int look(LinkedList<Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		for (int i = 0; i < bo.size(); i++) {
			if (t == bo.get(i).getId()) {
				t = i;
				break;
			}
		}
		return t;
	}

	public static void look(HashSet<Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		for (Book book : bo) {
			if (t == book.getId()) {
				System.out.println(book);
			}
		}

	}

	public static void look(TreeSet<Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		for (Book book : bo) {
			if (t == book.getId()) {
				System.out.println(book);
			}
		}

	}

	public static void look(HashMap<Integer, Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (t == entry.getKey()) {
				System.out.println(entry.getKey() + "+" + entry.getValue());
			}
		}
	}

	public static void look(TreeMap<Integer, Book> bo) {
		int t = -1;
		System.out.println("id");
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		Set<Entry<Integer, Book>> entrySet = bo.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (t == entry.getKey()) {
				System.out.println(entry.getKey() + "+" + entry.getValue());
			}
		}
	}

	public static void get(ArrayList<Book> bo) {
		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(id++, name, type, count);
			if (!bo.contains(book)) {
				bo.add(book);
			} else {
				System.out.println("�Ѵ���");
			}
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void get(LinkedList<Book> bo) {

		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(id++, name, type, count);
			if (!bo.contains(book)) {
				bo.add(book);
			} else {
				System.out.println("�Ѵ���");
			}
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void get(HashSet<Book> bo) {
		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(id++, name, type, count);
			if (!bo.add(book)) {
				System.out.println("�Ѵ���");
			}
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void get(TreeSet<Book> bo) {
		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(id++, name, type, count);
			if (!bo.add(book)) {
				System.out.println("�Ѵ���");
			}
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void get(TreeMap<Integer, Book> bo) {
		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(name, type, count);
			System.out.println("������ϢΪ��" + bo.put(id++, book));
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void get(HashMap<Integer, Book> bo) {
		int id = 0;
		int count = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			while (true) {
				try {
					count = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("��������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			Book book = new Book(name, type, count);
			System.out.println("������ϢΪ��" + bo.put(id++, book));
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if ("n".equals(str)) {
				break;
			}
		}

	}

	public static void print(ArrayList<Book> bo) {
		for (Book book : bo) {
			System.out.println(book);
		}
		System.out.println("=======================");
		for (Iterator iterator = bo.iterator(); iterator.hasNext();) {
			Book book = (Book) iterator.next();
			System.out.println(book);
		}
	}
	public static void print(LinkedList<Book> bo) {
		for (Book book : bo) {
			System.out.println(book);
		}
		System.out.println("=======================");
		for (Iterator iterator = bo.iterator(); iterator.hasNext();) {
			Book book = (Book) iterator.next();
			System.out.println(book);
		}
	}
	public static void print(TreeSet<Book> t) {
		for (Book book : t) {
			System.out.println(book);
		}
		System.out.println("========================");
		for (Iterator iterator = t.iterator(); iterator.hasNext();) {
			Book book = (Book) iterator.next();
			System.out.println(book);
		}
	}
	public static void print(HashSet<Book> t) {
		for (Book book : t) {
			System.out.println(book);
		}
		System.out.println("========================");
		for (Iterator iterator = t.iterator(); iterator.hasNext();) {
			Book book = (Book) iterator.next();
			System.out.println(book);
		}
	}
	public static <K, V> void print(HashMap<K, V> t) {
		Set<Entry<K, V>> entrySet = t.entrySet();
		for (Entry<K, V> entry : entrySet) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		System.out.println("=======================");
		for (Entry<K, V> entry : entrySet) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
	}

	public static <K, V> void print(TreeMap<K, V> t) {
		Set<Entry<K, V>> entrySet = t.entrySet();
		for (Entry<K, V> entry : entrySet) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		System.out.println("=======================");
		for (Entry<K, V> entry : entrySet) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
	}
}
