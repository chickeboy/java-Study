package tk1;
/*1.Student id  name sex address
2.Score eng math chn avg
   Map  Student Score
(1)1.添加，判重
2.查询
  1.遍历所有信息
  2.遍历所有男性学员
  3.输入一门学科，遍历出这门学科所有合格的学员
  4.打印出所有学科的平均分
  5.按照总分排序
  6.按照某一门课的成绩排序
  7.根据id排序
3.修改
  1.根据id修改学员信息
  2.根据id修改学员成绩信息
  3.根据姓名修改学员信息
  4.根据姓名修改学员成绩信息 
4.删除
  1.根据id删除学员信息
  2.根据姓名删除学员信息
 * 
 */
public class tk1 {
public static void main(String[] args) {
	G g=new G();
	g.cai();
}
}
