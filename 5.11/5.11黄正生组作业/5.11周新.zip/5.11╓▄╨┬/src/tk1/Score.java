package tk1;

import java.util.Comparator;

public class Score extends Map implements Comparator<Score>{
	private double eng;
	private double math;
	private double chn;
	private double avg;
	@Override
	public String toString() {
		return "eng=" + eng + ", math=" + math + ", chn=" + chn
				+ ", avg=" + avg;
	}
	public double getEng() {
		return eng;
	}
	public void setEng(double eng) {
		this.eng = eng;
	}
	public double getMath() {
		return math;
	}
	public void setMath(double math) {
		this.math = math;
	}
	public double getChn() {
		return chn;
	}
	public void setChn(double chn) {
		this.chn = chn;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public Score() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Score(double eng, double math, double chn) {
		super();
		this.eng = eng;
		this.math = math;
		this.chn = chn;
		this.avg = (this.eng+this.math+this.chn)/3;
	}
	@Override
	public int compare(Score o1, Score o2) {
		// TODO Auto-generated method stub
		return Double.compare(o1.getChn(), o2.getChn());
	}
	
}
