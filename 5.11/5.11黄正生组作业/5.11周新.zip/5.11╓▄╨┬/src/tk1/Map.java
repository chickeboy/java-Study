package tk1;

public class Map implements Comparable<Map>{
	private Student student;
	private Score score;
	public Map(Score score) {
		super();
		this.score = score;
	}
	public Map(Student student) {
		super();
		this.student = student;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((student == null) ? 0 : student.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Map other = (Map) obj;
		if (student == null) {
			if (other.student != null)
				return false;
		} else if (!student.equals(other.student))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "student=" + student + ", score=" + score;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}
	public Map() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Map(Student student, Score score) {
		super();
		this.student = student;
		this.score = score;
	}
	@Override
	public int compareTo(Map o) {
		// TODO Auto-generated method stub
		return Double.compare(o.getScore().getAvg(), getScore().getAvg());
	}
}
