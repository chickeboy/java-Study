package tk1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class G {
public static ArrayList<Map>st=new ArrayList<Map>();	
public static Scanner scanner=new Scanner(System.in);	
public static ArrayList<Map>st1=new ArrayList<Map>();
public static int y=0;
public void remove() {
	while (true) {
		System.out.println("=======ѧ������ɾ��ϵͳ======");
		System.out.println("1.����idɾ��ѧԱ��Ϣ");
		System.out.println(" 2.��������ɾ��ѧԱ��Ϣ");
		System.out.println("3.������һҳ");
		int t = 0;
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		switch (t) {
		case 1:
			y=indext(st);
			if(y>=0){
				System.out.println(st.remove(y));
			}
			break;
		case 2:
			y=indext1(st);
			if(y>=0){
				System.out.println(st.remove(y));
			}
			break;
		case 3:
			return;
		default:
			System.out.println("��������");
			break;
		}

	}
}
public void chang() {
	while (true) {
		System.out.println("=======ѧ�������޸�ϵͳ======");
		System.out.println("1.����id�޸�ѧԱ��Ϣ");
		System.out.println(" 2.����id�޸�ѧԱ�ɼ���Ϣ");
		System.out.println("3.���������޸�ѧԱ��Ϣ");
		System.out.println("4.���������޸�ѧԱ�ɼ���Ϣ");
		System.out.println("5.������һҳ");
		int t = 0;
		while (true) {
			try {
				t = scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		switch (t) {
		case 1:
			y=indext(st);
			if(y>=0){
			set(st,t);
			print(st);
			}
			break;
		case 2:
			y=indext(st);
			if(y>=0){
			set1(st,t);
			print(st);
			}
			break;
		case 3:
			y=indext1(st);
			if(y>=0){
			set(st,t);
			print(st);
			}
			break;
		case 4:
			y=indext1(st);
			if(y>=0){
			set1(st,t);
			print(st);
			}
			break;
		case 5:
			return;
		default:
			System.out.println("��������");
			break;
		}

	}
}
public int  indext1(ArrayList<Map>st){
	System.out.println("name");
	String name=scanner.next();
	for (int i = 0; i < st.size(); i++) {
		if(name==st.get(i).getStudent().getName()){
			System.out.println(st.get(i));
		}
	}
	int indext=-1;
	System.out.println("id");
	while(true){
	try {
		indext=scanner.nextInt();
	} catch (Exception e) {
		System.out.println("����������");
		scanner.nextLine();
		continue;
	}
	break;
	}
	
	return indext;
}
public void set1(ArrayList<Map>st,int t){
	
	
		double eng=0;
		double math=0;
		double chn=0;
		while(true){
		try {
			eng=scanner.nextDouble();
		} catch (Exception e) {
			System.out.println("������Double��");
			scanner.nextDouble();
			continue;
		}
		break;
		}
		System.out.println("math");
		while(true){
			try {
				math=scanner.nextDouble();
			} catch (Exception e) {
				System.out.println("������Double��");
				scanner.nextDouble();
				continue;
			}
			break;
			}
		System.out.println("chn");
		while(true){
			try {
				chn=scanner.nextDouble();
			} catch (Exception e) {
				System.out.println("������Double��");
				scanner.nextDouble();
				continue;
			}
			break;
			}
	st.set(t, new Map(new Score(eng, math, chn)));
	
}
public void set(ArrayList<Map>st,int t){
	System.out.println("name");
	String name=scanner.next();
	System.out.println("sex");
	String sex=scanner.next();
	System.out.println("address");
	String address=scanner.next();
	st.set(t, new Map(new Student(st.get(t).getStudent().getId(), name, sex, address)));
	
}
public int  indext(ArrayList<Map>st){
	int indext=-1;
	System.out.println("id");
	while(true){
	try {
		indext=scanner.nextInt();
	} catch (Exception e) {
		System.out.println("����������");
		scanner.nextLine();
		continue;
	}
	break;
	}
	for (int i = 0; i < st.size(); i++) {
		if(indext==st.get(i).getStudent().getId()){
			indext=i;
		}
	}
	return indext;
}
	public void look() {
		while (true) {
			System.out.println("=======ѧ��������ѯϵͳ======");
			System.out.println("1.����������Ϣ");
			System.out.println("2.������������ѧԱ");
			System.out.println("3.����һ��ѧ�ƣ�����������ѧ�����кϸ��ѧԱ");
			System.out.println("4.��ӡ������ѧ�Ƶ�ƽ����");
			System.out.println("5.�����ܷ�����");
			System.out.println("6.����ĳһ�ſεĳɼ�����");
			System.out.println(" 7.����id����");
			System.out.println("8.������һҳ");
			int t = 0;
			while (true) {
				try {
					t = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			switch (t) {
			case 1:
				print(st);
				break;
			case 2:
				print1(st);
				break;
			case 3:
				print2(st);
				break;
			case 4:
				print3(st);
				break;
			case 5:
				pai(st1);
				break;
			case 6:
				pai1(st1);
				break;
			case 7:
				print(st);
				break;
			case 8:
				return;
			default:
				System.out.println("��������");
				break;
			}

		}
}
	public void pai1(ArrayList<Map>st){
		System.out.println("������ѧ��");
		String str=scanner.next();
		switch(str){
		case "eng":
			Collections.sort(st,new Comparator<Map>() {
				@Override
				public int compare(Map o1, Map o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getScore().getEng(), o2.getScore().getEng());
				}
			});
			print(st);

			break;
		case "math":
			Collections.sort(st,new Comparator<Map>() {
				@Override
				public int compare(Map o1, Map o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getScore().getMath(), o2.getScore().getMath());
				}
			});
			print(st);
			break;
		case "chn":
			Collections.sort(st,new Comparator<Map>() {
				@Override
				public int compare(Map o1, Map o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getScore().getChn(), o2.getScore().getChn());
				}
			});
			print(st);
			break;
			default:
				System.out.println("��������");
				break;
		}
	}
	public void pai(ArrayList<Map>st){
		Collections.sort(st);
		print(st);
	}
	public void print3(ArrayList<Map>st){
		for (int i = 0; i < st.size(); i++) {
			System.out.println(st.get(i).getScore().getAvg());
		}
	}
	public void print2(ArrayList<Map>st){
		System.out.println("������ѧ��");
		String str=scanner.next();
		switch(str){
		case "eng":
			for (int i = 0; i < st.size(); i++) {
				if(st.get(i).getScore().getEng()>=60){
					System.out.println(st.get(i));
				}
			}

			break;
		case "math":
			for (int i = 0; i < st.size(); i++) {
				if(st.get(i).getScore().getMath()>=60){
					System.out.println(st.get(i));
				}
			}
			break;
		case "chn":
			for (int i = 0; i < st.size(); i++) {
				if(st.get(i).getScore().getChn()>=60){
					System.out.println(st.get(i));
				}
			}
			break;
			default:
				System.out.println("��������");
				break;
		}
		
		
	}
	public void print1(ArrayList<Map>st){
		for (Map map : st) {
			if(st.contains("��")){
				System.out.println(map);
			}
		}
	}
	public  void cai() {
		while (true) {
			System.out.println("=======ѧ������ϵͳ======");
			System.out.println("1.����");
			System.out.println("2.��ѯ");
			System.out.println("3.�޸�");
			System.out.println("4.ɾ��");
			System.out.println("5.�˳�");
			int t = 0;
			while (true) {
				try {
					t = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			switch (t) {
			case 1:
				st=add(st);
				st1=st;
				print(st);
				break;
			case 2:
				look();
				break;
			case 3:
				chang();
				break;
			case 4:
				remove();
				break;
			case 5:
				System.exit(0);
			default:
				System.out.println("��������");
				break;
			}
		}
	}
	public void print(ArrayList<Map>st){
		for (Map map : st) {
			System.out.println(map);
		}
	}
	public ArrayList<Map> add(ArrayList<Map>st){
		int id=1;
		while(true){
			System.out.println("name");
			String name=scanner.next();
			System.out.println("sex");
			String sex=scanner.next();
			System.out.println("address");
			String address=scanner.next();
			System.out.println("eng");
			double eng=0;
			double math=0;
			double chn=0;
			while(true){
			try {
				eng=scanner.nextDouble();
			} catch (Exception e) {
				System.out.println("������Double��");
				scanner.nextDouble();
				continue;
			}
			break;
			}
			System.out.println("math");
			while(true){
				try {
					math=scanner.nextDouble();
				} catch (Exception e) {
					System.out.println("������Double��");
					scanner.nextDouble();
					continue;
				}
				break;
				}
			System.out.println("chn");
			while(true){
				try {
					chn=scanner.nextDouble();
				} catch (Exception e) {
					System.out.println("������Double��");
					scanner.nextDouble();
					continue;
				}
				break;
				}
			Student student=new Student(id, name, sex, address);
			Score score=new Score(eng, math, chn);
			Map map=new Map(student, score);
			if(st.contains(map)){
				System.out.println("�Ѵ���");
			}else{
			st.add(new Student(id++,name,sex,address));
		}
			if(ji()<0){
				break;
			}
		}
		return st;
	}
	public int ji(){
		System.out.println("�Ƿ����y/n");
		String str=scanner.next();
		char a=str.charAt(0);
		if(a=='n'||a=='N'){
			return-1;
		}
		return 1;
	}
}
