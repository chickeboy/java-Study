package Hk3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Manager {
	private TreeSet<Books> ts;
	private Scanner scanner;

	public Manager() {
		ts = new TreeSet<Books>();
		scanner = new Scanner(System.in);
	}

	public void add() {
		ts = new TreeSet<Books>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				// TODO Auto-generated method stub
				return o1.getId() - o2.getId();
			}
		});
		ts.add(new Books(1, "a", "aa", 3));
		ts.add(new Books(2, "b", "bb", 4));
		ts.add(new Books(3, "c", "cc", 5));
		ts.add(new Books(4, "d", "dd", 6));
		ts.add(new Books(5, "e", "ee", 7));
	}

	public void show() {
		for (Books book : ts) {
			System.out.println(book);
		}
	}

	public void show1() {
		Iterator<Books> iterator = ts.iterator();
		while (iterator.hasNext()) {
			Books next = iterator.next();
			System.out.println(next);
		}
	}

	public void search() {
		ArrayList<Books> al = new ArrayList<Books>(ts);
		System.out.println("������Ҫ��ѯ��ID");
		int id = scanner.nextInt();
		for (Books books : al) {
			if (id == books.getId()) {
				System.out.println(books);
			}
		}
	}

	public void search1() {
		TreeSet<Books> ts1 = new TreeSet<Books>(ts);
		System.out.println("������Ҫ��ѯ������");
		String name = scanner.next();
		for (Books books : ts1) {
			if (name.equals(books.getName())) {
				System.out.println(books);
			}
		}
	}

	public void sort() {
		ArrayList<Books> al1 = new ArrayList<Books>(ts);
		Collections.sort(al1, new Comparator<Books>() {
			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		for (int i = 0; i < 5; i++) {
			System.out.println(al1.get(i));
		}
	}

	public void remove() {
		System.out.println("������Ҫɾ����ID");
		int id = scanner.nextInt();
		Books book = new Books(id);
		if (ts.remove(book)) {
			System.out.println("ɾ���ɹ�");
		} else {
			System.out.println("ɾ��ʧ��");
		}
		for (Books books : ts) {
			System.out.println(books);
		}
	}

	public void remove1() {
		System.out.println("������Ҫɾ����type");
		String type = scanner.next();
		Iterator<Books> iterator = ts.iterator();
		while (iterator.hasNext()) {
			Books next = iterator.next();
			if (type.equals(next.getType())) {
				iterator.remove();
			}
		}
		for (Books books : ts) {
			System.out.println(books);
		}
	}

	public void set() {
		System.out.println("������Ҫ����Ϣ��ID");
		int id = scanner.nextInt();
		for (Books books : ts) {
			if (id == books.getId()) {
				System.out.println("������Ҫ�ĵ�count");
				int count = scanner.nextInt();
				books.setCount(count);
			}
			System.out.println(books);
		}
	}

	public void sum() {
		int sum = 0;
		for (Books books : ts) {
			sum += books.getCount();
		}
		System.out.println(sum);
	}

	public void remove2() {
		while (true) {
			System.out.println("������Ҫɾ����type");
			String type = scanner.next();
			for (Books books : ts) {
				if (type.equals(books.getType())) {
					System.out.println(books);
				}
			}
			System.out.println("������Ҫɾ����ID");
			int id = scanner.nextInt();
			Books books = new Books(id);
			if (ts.remove(books)) {
				System.out.println("ɾ���ɹ�");
			}
			System.out.println("�����Ƿ����������n�˳�");
			String choice = scanner.next();
			if (choice.equals("n")) {
				break;
			}
		}
	}

	public void sort1() {
		TreeSet<Books> list = new TreeSet<Books>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				// TODO Auto-generated method stub
				return o2.getId() - o1.getId();
			}
		});
		list.addAll(ts);
		for (Books books : list) {
			System.out.println(books);
		}
	}

	public void sort2() {
		TreeSet<Books> list = new TreeSet<Books>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				// TODO Auto-generated method stub
				return o2.getName().compareTo(o1.getName());
			}
		});
		list.addAll(ts);
		for (Books books : list) {
			System.out.println(books);
		}
	}

	public void sort3() {
		TreeSet<Books> list = new TreeSet<Books>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		list.addAll(ts);
		for (Books books : list) {
			System.out.println(books);
		}
	}

	public void sort4() {
		TreeSet<Books> list = new TreeSet<Books>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getId() - o1.getId();
				if (res == 0) {
					res = o2.getName().compareTo(o1.getName());
					if (res == 0) {
						res = o2.getCount() - o1.getCount();
					}
					return res;
				}
				return res;
			}
		});
		list.addAll(ts);
		for (Books books : list) {
			System.out.println(books);
		}
	}
}
