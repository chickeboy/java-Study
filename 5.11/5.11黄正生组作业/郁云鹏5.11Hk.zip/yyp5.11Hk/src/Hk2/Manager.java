package Hk2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

public class Manager {
	private ArrayList<Books> al;
	private Scanner scanner;

	public void add() {
		al = new ArrayList<Books>();
		scanner = new Scanner(System.in);
		while (true) {
			System.out.println("��������Ҫ�����Id");
			int id = scanner.nextInt();
			System.out.println("��������Ҫ�����name");
			String name = scanner.next();
			System.out.println("��������Ҫ�����type");
			String type = scanner.next();
			System.out.println("��������Ҫ�����count");
			int count = scanner.nextInt();
			Books books = new Books(id, name, type, count);
			if (al.contains(books)) {
				System.out.println("�Ѵ��ڣ�");
			} else {
				al.add(books);
				System.out.println("���ӳɹ�");
			}
			System.out.println("�����Ƿ����������n�˳�");
			String choice = scanner.next();
			if (choice.equals("n")) {
				break;
			}
		}
	}

	public void show() {
		for (Books books : al) {
			System.out.println(books);
		}
	}

	public void show1() {
		Iterator<Books> iterator = al.iterator();
		while (iterator.hasNext()) {
			Books next = iterator.next();
			System.out.println(next);
		}
	}

	public void search() {
		ArrayList<Books> al1 = new ArrayList<Books>();
		System.out.println("������Ҫ��ѯ��ID");
		int id = scanner.nextInt();
		for (int i = 0; i < al.size(); i++) {
			if (id == al.get(i).getId()) {
				al1.add(al.get(i));
			}
		}
		if (al1.isEmpty()) {
			System.out.println("������");
		} else {
			System.out.println(al1);
		}
	}

	public void search1() {
		ArrayList<Books> al2 = new ArrayList<Books>();
		System.out.println("������Ҫ��ѯ������");
		String name = scanner.next();
		for (int i = 0; i < al.size(); i++) {
			if (name.equals(al.get(i).getName())) {
				al2.add(al.get(i));
			}
		}
		if (al2.isEmpty()) {
			System.out.println("������");
		} else {
			System.out.println(al2);
		}
	}

	public void sort() {
		ArrayList<Books> al2 = new ArrayList<Books>(al);
		Collections.sort(al2, new Comparator<Books>() {
			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		for (int i = 0; i < 5; i++) {
			System.out.println(al2.get(i));
		}
	}

	public void remove() {
		System.out.println("������Ҫɾ����ID");
		int id = scanner.nextInt();
		Books book = new Books(id);
		if (al.remove(book)) {
			System.out.println("ɾ���ɹ�");
		} else {
			System.out.println("ɾ��ʧ��");
		}
	}

	public void remove1() {
		System.out.println("������Ҫɾ����type");
		String type = scanner.next();
		Iterator<Books> iterator = al.iterator();
		while (iterator.hasNext()) {
			Books next = iterator.next();
			if (type.equals(next.getType())) {
				iterator.remove();
			}
		}
		for (Books book : al) {
			System.out.println(book);
		}
	}

	public void set() {
		System.out.println("������Ҫ����Ϣ��ID");
		int id = scanner.nextInt();
		for (int i = 0; i < al.size(); i++) {
			if (id == al.get(i).getId()) {
				System.out.println("������Ҫ�ĵ�count");
				int count = scanner.nextInt();
				al.get(i).setCount(count);
			}
			System.out.println(al.get(i));
		}
	}

	public void sum() {
		int sum = 0;
		for (int i = 0; i < al.size(); i++) {
			sum = sum + al.get(i).getCount();
		}
		System.out.println(sum);
	}

	public void remove2() {
		while (true) {
			System.out.println("������Ҫɾ����Type");
			String type = scanner.next();
			for (int i = 0; i < al.size(); i++) {
				if (type.equals(al.get(i).getType())) {
					System.out.println(al.get(i));
				}
			}

			System.out.println("������Ҫɾ����ID");
			int id = scanner.nextInt();
			Books books = new Books(id);
			if (al.remove(books)) {
				System.out.println("ɾ���ɹ�");
				for (Books books1 : al) {
					System.out.println(books1);
				}
			}
			System.out.println("�����Ƿ����������n�˳�");
			String choice = scanner.next();
			if (choice.equals("n")) {
				break;
			}
		}

	}

	public void sort1() {
		ArrayList<Books> list = new ArrayList<Books>(al);
		Collections.sort(list, new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {

				return o2.getId() - o1.getId();
			}
		});
		for (Books book : list) {
			System.out.println(book);
		}
	}

	public void sort2() {
		ArrayList<Books> list = new ArrayList<Books>(al);
		Collections.sort(list, new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				return o2.getName().compareTo(o1.getName());
			}
		});
		for (Books book : list) {
			System.out.println(book);
		}
	}

	public void sort3() {
		ArrayList<Books> b = new ArrayList<Books>(al);
		Collections.sort(b, new Comparator<Books>() {
			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		for (int i = 0; i < al.size(); i++) {
			System.out.println(b.get(i));
		}
	}

	public void sort4() {
		ArrayList<Books> b = new ArrayList<Books>(al);
		Collections.sort(b, new Comparator<Books>() {
			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getId() - o1.getId();
				if (res == 0) {
					res = o2.getName().compareTo(o1.getName());
					if (res == 0) {
						res = o2.getCount() - o1.getCount();
					}
					return res;
				}
				return res;
			}
		});
		for (int i = 0; i < al.size(); i++) {
			System.out.println(b.get(i));
		}
	}
}
