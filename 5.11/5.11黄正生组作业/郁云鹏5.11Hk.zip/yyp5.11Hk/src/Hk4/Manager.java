package Hk4;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;


public class Manager {
	private HashMap<Integer, Books> hm;
	private Scanner scanner;

	public Manager() {
		hm = new HashMap<Integer, Books>();
		scanner = new Scanner(System.in);
	}

	public void add() {
		hm.put(1, new Books("a", "aa", 3));
		hm.put(2, new Books("b", "bb", 4));
		hm.put(3, new Books("c", "cc", 5));
		hm.put(4, new Books("d", "dd", 6));
		hm.put(5, new Books("e", "ee", 7));		
	}

	public void show() {
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	}

	public void show1() {
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		Iterator<Entry<Integer, Books>> iterator = entrySet.iterator();
		while (iterator.hasNext()) {
			Entry<Integer, Books> next = iterator.next();
			System.out.println(next);
		}
	}

	public void search() {
		System.out.println("������Ҫ��ѯ��ID");
		int id = scanner.nextInt();
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			if (id == entry.getKey()) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	public void search1() {
		System.out.println("������Ҫ��ѯ������");
		String name = scanner.next();
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			if (name.equals(entry.getValue().getName())) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	public void sort() {
		TreeMap<Books, Integer> tm = new TreeMap<Books, Integer>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			tm.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Books, Integer>> entrySet1 = tm.entrySet();
		for (Entry<Books, Integer> entry : entrySet1) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	public void remove() {
		System.out.println("������Ҫɾ����id");
		int id = scanner.nextInt();
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		Iterator<Entry<Integer, Books>> iterator = entrySet.iterator();
		while (iterator.hasNext()) {
			Entry<Integer, Books> next = iterator.next();
			// System.out.println(next);
			if (next.getKey() == id) {
				iterator.remove();
			}
		}
		for (Entry<Integer, Books> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	  }
     
     public void remove1() {
	
     }
	public void set() {
		System.out.println("������Ҫ����Ϣ��ID");
		int id = scanner.nextInt();
		Set<Entry<Integer, Books>> Set = hm.entrySet();
		for (Entry<Integer, Books> entry : Set) {
			if (entry.getKey() == id) {
				System.out.println("������Ҫ�ĵ�count");
				int count = scanner.nextInt();
				entry.getValue().setCount(count);
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	public void sum() {
		int sum = 0;
		Set<Entry<Integer, Books>> Set = hm.entrySet();
		for (Entry<Integer, Books> entry : Set) {
			sum += entry.getValue().getCount();
		}
		System.out.println(sum);
	}
	
	public void remove2() {
		
	}

	public void sort1() {
		TreeMap<Integer, Books> list = new TreeMap<Integer, Books>(new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o2 - o1;
			}
		});
		Set<Entry<Integer, Books>> entrySet2 = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet2) {
			list.put(entry.getKey(), entry.getValue());
		}
		Set<Entry<Integer, Books>> entrySet = list.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	public void sort2() {
		TreeMap<Books, Integer> tm = new TreeMap<Books, Integer>(new Comparator<Books>() {

			@Override
			public int compare(Books o1, Books o2) {
				int res = o2.getName().compareTo(o1.getName());
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Books>> entrySet = hm.entrySet();
		for (Entry<Integer, Books> entry : entrySet) {
			tm.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Books, Integer>> entrySet2 = tm.entrySet();
		for (Entry<Books, Integer> entry : entrySet2) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	public void sort3() {
		
	}
	public void sort4() {
		
	}
}
