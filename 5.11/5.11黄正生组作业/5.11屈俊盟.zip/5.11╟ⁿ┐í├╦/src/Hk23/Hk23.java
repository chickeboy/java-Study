package Hk23;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class Hk23 {

	public static void main(String[] args) {
		Manager manager = new Manager();
		manager.add();
		System.out.println("===============================");
		manager.show1();
		System.out.println("===============================");
		manager.show2();
		System.out.println("===============================");
		manager.searchById();
		System.out.println("===============================");
		manager.searchByName();
		System.out.println("===============================");
		manager.sortByCount();
		System.out.println("===============================");
		manager.removeById();
		System.out.println("===============================");
//		manager.removeByType();
		System.out.println("===============================");
		manager.setCount();
		System.out.println("===============================");
		manager.sum();
		System.out.println("===============================");
//		manager.removeBytypeAndId();
		System.out.println("===============================");
		manager.sortById();
		System.out.println("===============================");
		manager.sortByName();
		System.out.println("===============================");
		manager.sortByCount2();

	}

}
class Book {
	private int id;
	private String name;
	private String type;
	private int count;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Book(String name, String type, int count) {
		super();
		// this.id = id;
		this.name = name;
		this.type = type;
		this.count = count;
	}

	public Book(int id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "book [name=" + name + ", type=" + type + ", count=" + count + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (id != other.id)
			return false;
		return true;
	}
}

class Manager {
	private HashMap<Integer, Book> hm;
	private Scanner scanner;

	public Manager() {
		hm = new HashMap<Integer, Book>();
		scanner = new Scanner(System.in);
	}

	public void add() {
		hm.put(1, new Book("aa", "ef", 2));
		hm.put(2, new Book("a", "e", 2));
		hm.put(3, new Book("aa", "e", 4));
		hm.put(4, new Book("aafg", "f", 5));
		hm.put(5, new Book("efaa", "efsg", 4));
		hm.put(6, new Book("dfaa", "eef", 3));
		hm.put(7, new Book("afdga", "aefef", 1));
		hm.put(8, new Book("aera", "wegef", 7));
	}

	public void show1() {
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	}

	public void show2() {
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		Iterator<Entry<Integer, Book>> iterator = entrySet.iterator();
		while (iterator.hasNext()) {
			Entry<Integer, Book> next = iterator.next();
			System.out.println(next);
		}
	}

	// 3.��������һ��id����ȡ���id��Ӧ���鱾��Ϣ�����ǵ�����ӡ��
	public void searchById() {
		System.out.println("������Ҫ��ѯ��ID");
		int id = scanner.nextInt();
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (id == entry.getKey()) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	// 4.��������һ��name,��ȡ���name��Ӧ�������鱾��Ϣ�����ǵ�����ӡ��
	public void searchByName() {
		System.out.println("������Ҫ��ѯ������");
		String name = scanner.next();
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (name.equals(entry.getValue().getName())) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	// 5.��ȡcountʣ������ǰ��λ���鱾��Ϣ�����ǵ�����ӡ��
	public void sortByCount() {
		TreeMap<Book, Integer> b = new TreeMap<Book, Integer>(new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Book, Integer>> entrySet2 = b.entrySet();
		for (Entry<Book, Integer> entry : entrySet2) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	// 6.��������һ��idɾ�����id��Ӧ�鱾��Ϣ
	public void removeById() {
		System.out.println("������Ҫɾ����id");
		int id = scanner.nextInt();
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		Iterator<Entry<Integer, Book>> iterator = entrySet.iterator();
		while (iterator.hasNext()) {
			Entry<Integer, Book> next = iterator.next();
			// System.out.println(next);
			if (next.getKey() == id) {
				iterator.remove();
			}
		}
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	}


	// 8.��������һ��id��ͨ������count,�����޸�ԭ���鱾��count��Ϣ
	public void setCount() {
		System.out.println("������Ҫ����Ϣ��ID");
		int id = scanner.nextInt();
		Set<Entry<Integer, Book>> enSet = hm.entrySet();
		for (Entry<Integer, Book> entry : enSet) {
			if (entry.getKey() == id) {
				System.out.println("������Ҫ�ĵ�count");
				int count = scanner.nextInt();
				entry.getValue().setCount(count);
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}

	// 9.����������鱾��ʣ�������ܺ�
	public void sum() {
		int sum = 0;
		Set<Entry<Integer, Book>> enSet = hm.entrySet();
		for (Entry<Integer, Book> entry : enSet) {
			sum += entry.getValue().getCount();
		}
		System.out.println(sum);
	}

	// 11.����id�����������
	public void sortById() {
		TreeMap<Integer, Book> list = new TreeMap<Integer, Book>(new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o2 - o1;
			}
		});
		Set<Entry<Integer, Book>> entrySet2 = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet2) {
			list.put(entry.getKey(), entry.getValue());
		}
		Set<Entry<Integer, Book>> entrySet = list.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	// 12.����name ���н������
	public void sortByName() {
		TreeMap<Book, Integer> b = new TreeMap<Book, Integer>(new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				int res = o2.getName().compareTo(o1.getName());
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Book, Integer>> entrySet2 = b.entrySet();
		for (Entry<Book, Integer> entry : entrySet2) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}

	// 13.ʹ�������ڲ����count��������
	public void sortByCount2() {
		TreeMap<Book, Integer> b = new TreeMap<Book, Integer>(new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Book, Integer>> entrySet2 = b.entrySet();
		for (Entry<Book, Integer> entry : entrySet2) {
			System.out.println(entry.getKey() + "," + entry.getValue());
		}
	}

}

