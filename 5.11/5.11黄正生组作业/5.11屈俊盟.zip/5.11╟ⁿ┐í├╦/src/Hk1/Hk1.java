package Hk1;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import Util.Util;

/*
 *1.Student id  name sex address
2.Score eng math chn avg
   Map  Student Score
(1)1.添加，判重
2.查询
  1.遍历所有信息
  2.遍历所有男性学员
  3.输入一门学科，遍历出这门学科所有合格的学员
  4.打印出所有学科的平均分
  5.按照总分排序
  6.按照某一门课的成绩排序
  7.根据id排序
3.修改
  1.根据id修改学员信息
  2.根据id修改学员成绩信息
  3.根据姓名修改学员信息
  4.根据姓名修改学员成绩信息 
4.删除
  1.根据id删除学员信息
  2.根据姓名删除学员信息
 */
public class Hk1 {
	public static void main (String [] args) {
		Map<Student, Score> hm = new HashMap<Student, Score>();
		hm.put(new Student(1,"aa","男","山东"), new Score(33,44,55));
		hm.put(new Student(2,"bb","女","东北"), new Score(46,64,33));
		hm.put(new Student(3,"cc","女","山西"), new Score(33,66,55));
		hm.put(new Student(3,"dd","男","安徽"), new Score(33,75,88));
		hm.put(new Student(4,"dd","男","上海"), new Score(88,73,11));
		hm.put(new Student(5,"ee","男","北京"), new Score(33,44,99));
		Util util = new Util();
		util.show(hm);
		System.out.println("===================================");
		Set<Student> keySet=hm.keySet();
		 for (Student student : keySet) {
			if (student.getSex().equals("男")) {
				System.out.print(student);
				System.out.println(hm.get(student));
			}
		}
		System.out.println("===================================");
		Set<Entry<Student, Score>> entrySet = hm.entrySet();
		for (Entry<Student, Score> entry : entrySet) {
			if ( entry.getKey().getSex().equals("男")) {
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		System.out.println("===================================");
		for (Entry<Student, Score> entry : entrySet) {
			if (entry.getValue().getChn()>=60) {
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		// 4.打印出所有学科的平均分
		System.out.println("===================================");
		Set<Entry<Student, Score>> entrySet2 = hm.entrySet();	double sum =0;
		for (Entry<Student, Score> entry : entrySet2) {		
			sum=sum+entry.getValue().getChn();;
		}
		System.out.println("语文的平均分是："+sum/hm.size());
		System.out.println("===================================");
		//5.按照总分排序
		TreeSet<Entry<Student,Score>> ts = new TreeSet<Entry<Student,Score>>(new Comparator<Entry<Student,Score>>() {

			@Override
			public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
				double sum1 = o1.getValue().getChn()+o1.getValue().getMath()+o1.getValue().getEng();
				double sum2 = o2.getValue().getChn()+o2.getValue().getMath()+o2.getValue().getEng();
				return Double.compare(sum1, sum2);
			}
		});
		ts.addAll(entrySet);
		for (Entry<Student, Score> entry : ts) {
			System.out.println(entry);
		}
		//  6.按照某一门课的成绩排序
		System.out.println("===================================");
		TreeSet<Entry<Student,Score>> ts1 = new TreeSet<Entry<Student,Score>>(new Comparator<Entry<Student,Score>>() {

			@Override
			public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
				// TODO Auto-generated method stub
				return Double.compare(o1.getValue().getChn(), o2.getValue().getChn());
			}
		});
		ts1.addAll(entrySet);
		for (Entry<Student, Score> entry : ts1) {
			System.out.println(entry);
		}
		//  7.根据id排序
		System.out.println("===================================");
		util.show(hm);
		//  1.根据id修改学员信息
		Scanner scanner = new Scanner(System.in);
		System.out.println("请修改Id的学员信息名字为bbbb");
		int num = scanner.nextInt();
		for (Entry<Student, Score> entry : ts1) {
			if (num==entry.getKey().getId()) {
				entry.getKey().setName("bbbb");
			}
		}
		util.show(hm);
		System.out.println("===================================");
		System.out.println("修改Id的语文成绩为100");
		num=scanner.nextInt();
		for (Entry<Student, Score> entry : ts1) {
			if (num == entry.getKey().getId()) {
				entry.getValue().setChn(100);
			}
		}
		util.show(hm);
		 //3.根据姓名修改学员信息
		System.out.println("===================================");
		System.out.println("根据姓名修改地址信息为大连");
		String name = scanner.next();
		for (Entry<Student, Score> entry : ts1) {
			if(entry.getKey().getName()==name) {
				entry.getKey().setAddress("大连");
			}
		}
		util.show(hm);
		//  4.根据姓名修改学员成绩信息 
		System.out.println("===================================");
		System.out.println("根据姓名修改语文成绩为99.5");
		name = scanner.next();
		for (Entry<Student, Score> entry : ts1) {
			if(entry.getKey().getName()==name) {
				entry.getValue().setChn(99.5);
			}
		}
		util.show(hm);
		System.out.println("===================================");
		// 1.根据id删除学员信息
		System.out.println("请输入您要删除的学员信息的Id");
		num = scanner.nextInt();
		for (Entry<Student, Score> entry : ts1) {
			if (entry.getKey().getId()==num) {
				hm.remove(entry.getKey());
			}
		}
		util.show(hm);
		System.out.println("===================================");
		// 1.根据姓名删除学员信息
		System.out.println("根据姓名删除学员信息");
		name=scanner.next();
		for (Entry<Student, Score> entry : ts1) {
			if(entry.getKey().getName()==name) {
				hm.remove(entry.getKey());
			}
		}
		util.show(hm);
	
	
	
	
	
	}
}
