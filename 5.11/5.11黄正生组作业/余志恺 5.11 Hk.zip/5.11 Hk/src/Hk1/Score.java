package Hk1;

public class Score {
	private int eng; 
	private int math;
	private int chn;
	private int avg;
	public Score(int eng, int math, int chn, int avg) {
		super();
		this.eng = eng;
		this.math = math;
		this.chn = chn;
		this.avg = avg;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getChn() {
		return chn;
	}
	public void setChn(int chn) {
		this.chn = chn;
	}
	public int getAvg() {
		return avg;
	}
	public void setAvg(int avg) {
		this.avg = avg;
	}
	@Override
	public String toString() {
		return "����	Ӣ��:" + eng + "	��ѧ:" + math + "	����" + chn + "	ƽ����" + avg ;
	}
	
}
