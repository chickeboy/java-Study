package Hk1;

public class Method {

}
