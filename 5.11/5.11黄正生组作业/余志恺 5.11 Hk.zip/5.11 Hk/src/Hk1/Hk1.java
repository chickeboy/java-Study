package Hk1;

import java.util.Map.Entry;

import java.util.*;

/*
 * 1.Student id name sex address
2.Score eng math chn avg
   Map  Student Score
(1)1.添加，判重(id)
2.查询
  1.遍历所有信息
  2.遍历所有男性学员
  3.输入一门学科，遍历出这门学科所有合格的学员
  4.打印出所有学科的平均分
  5.按照总分排序
  6.按照某一门课的成绩排序
  7.根据id排序
3.修改
  1.根据id修改学员信息
  2.根据id修改学员成绩信息
  3.根据姓名修改学员信息
  4.根据姓名修改学员成绩信息 
4.删除
  1.根据id删除学员信息
  2.根据姓名删除学员信息

 */
public class Hk1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		HashMap<Student, Score> hm = new HashMap<Student, Score>();
		hm.put(new Student(1, "张三", "男", "上海"), new Score(55, 60, 75, 65));
		hm.put(new Student(1, "李四", "男", "武汉"), new Score(77, 55, 75, 65));
		hm.put(new Student(2, "李四", "男", "武汉"), new Score(80, 35, 74, 77));
		hm.put(new Student(3, "小红", "女", "海南"), new Score(45, 85, 73, 67));
		hm.put(new Student(4, "王燕", "女", "广东"), new Score(97, 76, 72, 83));
		hm.put(new Student(5, "王五", "男", "山东"), new Score(99, 88, 71, 87));
		Set<Entry<Student, Score>> entrySet = hm.entrySet();
		for (Entry<Student, Score> entry : entrySet) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		System.out.println("===遍历所有男性学生===");		
		ArrayList<Entry<Student, Score>> al = new ArrayList<Entry<Student, Score>>(entrySet);
		Set<Entry<Student, Score>> entrySet11 = hm.entrySet();
		for (Entry<Student, Score> entry : entrySet11) {
			if ( entry.getKey().getSex().equals("男")) {
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
		}
		System.out.println("===输入一门学科，遍历出这门学科所有合格的学员====");	
		System.out.println("请输入学科eng,math,chn");
		String str = sc.next();
		switch (str) {
		case "eng":
			for (int i = 0; i < al.size(); i++) {
				if (al.get(i).getValue().getEng() >= 60) {
					System.out.println(al.get(i));
				}
			}

			break;
		case "math":
			for (int i = 0; i < al.size(); i++) {
				if (al.get(i).getValue().getMath() >= 60) {
					System.out.println(al.get(i));
				}
			}
			break;
		case "chn":
			for (int i = 0; i < al.size(); i++) {
				if (al.get(i).getValue().getChn() >= 60) {
					System.out.println(al.get(i));
				}
			}
			break;
		default:
			System.out.println("输入有误");
			break;
		}
		System.out.println("===打印出所有学科的平均分===");
		for (int i = 0; i < al.size(); i++) {
			System.out.println(al.get(i).getValue().getAvg());
		}
		System.out.println("===按照总分排序===");
		List<Entry<Student, Score>> list = new ArrayList<Entry<Student, Score>>(entrySet);
		Collections.sort(list, new Comparator<Entry<Student, Score>>() {
			@Override
			public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
				// TODO Auto-generated method stub
				if (o2.getValue().getAvg() > o1.getValue().getAvg()) {
					return 1;
				} else {
					return -1;
				}

			}
		});
		for (Entry<Student, Score> entry : list) {
			System.out.print(entry.getKey() + "\t");
			System.out.println(entry.getValue());
		}
		System.out.println("===按照学科的成绩排序===");
		System.out.println("请输入学科eng/math/chn");
		String str1 = sc.next();
		switch (str) {
		case "eng":
			Collections.sort(al, new Comparator<Entry<Student, Score>>() {

				@Override
				public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getValue().getEng(), o2.getValue().getEng());
				}
			});
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
			break;
		case "math":
			Collections.sort(al, new Comparator<Entry<Student, Score>>() {
				@Override
				public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getValue().getMath(), o2.getValue().getMath());
				}
			});
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
			break;
		case "chn":
			Collections.sort(al, new Comparator<Entry<Student, Score>>() {
				@Override
				public int compare(Entry<Student, Score> o1, Entry<Student, Score> o2) {
					// TODO Auto-generated method stub
					return Double.compare(o1.getValue().getChn(), o2.getValue().getChn());
				}
			});
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
			break;
		default:
			System.out.println("输入有误");
			break;
		}
		System.out.println("===根据id排序===");
		TreeMap<Student, Score> ts = new TreeMap<Student, Score>();
		ts = new TreeMap<Student, Score>(new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.getId() - o2.getId();
			}
		});
		for (Entry<Student, Score> entry : al) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
		System.out.println("===根据id修改学员姓名为ss===");			
		int id = sc.nextInt();
		for (Entry<Student, Score> entry : al) {
			if (id==entry.getKey().getId()) {
				entry.getKey().setName("ss");
			}
		}
		for (Entry<Student, Score> entry : list) {
			System.out.println(entry);
		}
		
			System.out.println("===根据id修改语文成绩为100===");	
			int id1 = sc.nextInt();
			for (Entry<Student, Score> entry : al) {
				if (id1 == entry.getKey().getId()) {
					entry.getValue().setChn(100);
				}
			}
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
		System.out.println("===根据姓名修改学员地址为北京===");
		String name = sc.next();
		for (Entry<Student, Score> entry : al) {
			if(entry.getKey().getName()==name) {
				entry.getKey().setAddress("北京");
			}
		}
		for (Entry<Student, Score> entry : list) {
			System.out.println(entry);
		}
			System.out.println("===根据姓名修改学员语文成绩信息为99 ===");
			name = sc.next();
			for (Entry<Student, Score> entry : al) {
				if(entry.getKey().getName()==name) {
					entry.getValue().setChn(99);
				}
			}
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
			System.out.println("===根据id删除学员信息===");
			int id2 = sc.nextInt();
			for (Entry<Student, Score> entry : al) {
				if (entry.getKey().getId()==id2) {
					hm.remove(entry.getKey());
				}
			}
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
			System.out.println("===根据姓名删除学员信息===");
			name=sc.next();
			for (Entry<Student, Score> entry : al) {
				if(entry.getKey().getName()==name) {
					hm.remove(entry.getKey());
				}
			}
			for (Entry<Student, Score> entry : list) {
				System.out.println(entry);
			}
		}
	}

	