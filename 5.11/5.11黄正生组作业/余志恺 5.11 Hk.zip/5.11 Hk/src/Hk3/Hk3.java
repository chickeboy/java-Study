package Hk3;

public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookManager book = new BookManager();
		book.add();
		book.show();
		book.show1();
		book.findAllByName();
		book.findAllByName1();
		book.findByCount();
		book.RemoveById();
		book.RemoveByType();
		book.SetByCount();
		book.CountAll();
		book.RemoveByTypeFromBook();
		book.SortById();
		book.SortByName();
		book.SortByCount();
		book.Collect();

	}
}
