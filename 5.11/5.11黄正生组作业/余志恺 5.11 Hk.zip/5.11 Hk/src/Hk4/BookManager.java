package Hk4;

import java.util.*;
import java.util.Map.Entry;

public class BookManager {
	private HashMap<Integer, Book> hm;
	private Scanner scanner;

	public BookManager() {
		hm = new HashMap<Integer, Book>();
		scanner = new Scanner(System.in);
	}

	public void add() {
		int i = 1;
		while (true) {

			System.out.println("name");
			String name = scanner.next();
			System.out.println("type");
			String type = scanner.next();
			System.out.println("count");
			int count = scanner.nextInt();
			hm.put(i++, new Book(name, type, count));
			System.out.println("�Ƿ����y/n");
			String a = scanner.next();
			if (a.equals("n")) {
				break;
			}
		}
	}

	public void show1() {
		System.out.println("������ʽ2");
		Set<Integer> keySet = hm.keySet();
		Iterator<Integer> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			Integer integer = (Integer) iterator.next();
			System.out.println("id=" + integer + "," + hm.get(integer));
		}

	}

	public void show() {
		System.out.println("������ʽ1");
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println("id=" + entry.getKey() + "," + entry.getValue());
		}

	}
	public void findAllByName() {
		System.out.println("========��ѯһ��id�����о�����Ϣ======");
		System.out.println("������id");
		int id = scanner.nextInt();
		if(hm.containsKey(id)) {
			System.out.println(hm.get(id));
		}
	}
	public void findAllByName1() {
		System.out.println("=====��ѯһ�����ֵ����о�����Ϣ=====");
		System.out.println("����������");
		String name = scanner.next();
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (name.equals(entry.getValue().getName())) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}
	public void findByCount() {
		System.out.println("===��ȡcountʣ������ǰ��λ���鱾��Ϣ===");
		TreeMap<Book, Integer> b = new TreeMap<Book, Integer>(new Comparator<Book>() {

			@Override
			public int compare(Book o1, Book o2) {
				int res = o2.getCount() - o1.getCount();
				return res == 0 ? 1 : res;
			}
		});
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			b.put(entry.getValue(), entry.getKey());
		}
		Set<Entry<Book, Integer>> entrySet2 = b.entrySet();
		for (Entry<Book, Integer> entry : entrySet2) {
			System.out.println(entry.getKey() + "," + entry.getValue());

		}
	}
	public void RemoveById() {
		System.out.println("��������һ��idɾ�����id��Ӧ�鱾��Ϣ");
		System.out.println("id");
		int id = scanner.nextInt();
		if(hm.containsKey(id)) {
			hm.remove(id);
		}
		System.out.println("ɾ��id��ʣ�µ���Ϣ"+hm);
	}
	public void RemoveByType() {
		System.out.println("===��������һ��typeɾ��������Ͷ�Ӧ�������鱾��Ϣ===");
		System.out.println("type");
		String type = scanner.next();
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			if (type.equals(entry.getValue().getType())) {
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}
	public void SetByCount() {
		System.out.println("===��������һ��id��ͨ������count,�����޸�ԭ���鱾��count��Ϣ===");
		System.out.println("id");
		int id = scanner.nextInt();
		Set<Entry<Integer, Book>> ESet = hm.entrySet();
		for (Entry<Integer, Book> entry : ESet) {
			if (entry.getKey() == id) {
				System.out.println("������Ҫ�ĵ�count");
				int count = scanner.nextInt();
				entry.getValue().setCount(count);
				System.out.println(entry.getKey() + "," + entry.getValue());
			}
		}
	}
	public void CountAll() {
		System.out.println("===����������鱾��ʣ�������ܺ�===");
		int sum = 0;
		Set<Entry<Integer, Book>> eSet = hm.entrySet();
		for (Entry<Integer, Book> entry : eSet) {
			sum += entry.getValue().getCount();
		}
		System.out.println(sum);
	}
	public void RemoveByTypeFromBook() {
		System.out.println("===��������һ��type��Ȼ��ѡ���Ե�ɾ��һ����(�ٴ�ѡ�����ɾ��)===");
		
	}
	public void SortById(){
		System.out.println("===����id�����������===");
		TreeMap<Integer, Book> tm = new TreeMap<Integer, Book>();
		tm.putAll(hm);
		Set<Entry<Integer, Book>> entrySet = hm.entrySet();
		 entrySet = tm.entrySet();
		for (Entry<Integer, Book> entry : entrySet) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
		}
	}
	public void SortByName() {	
		System.out.println("===����name ���н������===");
		 TreeMap<Book, Integer> tm = new TreeMap<Book, Integer>();
			tm = new TreeMap<Book, Integer>(new Comparator<Book>() {

				@Override
				public int compare(Book o1, Book o2) {
					// TODO Auto-generated method stub
					return o2.getName().compareTo(o1.getName());
				}
			});
			Set<Entry<Book, Integer>> entrySet2 = tm.entrySet();
			for (Entry<Book, Integer> entry : entrySet2) {
				System.out.println( "id="+entry.getValue() + "��" + entry.getKey());
			}
	}
	public void SortByCount() {
		System.out.println("===ʹ�������ڲ����count��������===");
		 TreeMap<Book, Integer> tm = new TreeMap<Book, Integer>();
			tm = new TreeMap<Book, Integer>(new Comparator<Book>() {

				@Override
				public int compare(Book o1, Book o2) {
					// TODO Auto-generated method stub
					return o2.getCount()-o1.getCount();
				}
			});
			Set<Entry<Book, Integer>> entrySet2 = tm.entrySet();
			for (Entry<Book, Integer> entry : entrySet2) {
				System.out.println( "id="+entry.getValue() + "��" + entry.getKey());
			}
	
	}
	public void Collect() {
	}
	
}
