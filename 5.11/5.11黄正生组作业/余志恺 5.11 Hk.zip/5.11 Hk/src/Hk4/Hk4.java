package Hk4;


public class Hk4 {
	public static void main(String[] args) {
		
	
	BookManager book = new BookManager();
	book.add();
	book.show();
	book.show1();
	book.findAllByName();
	book.findAllByName1();
	book.findByCount();
	book.RemoveById();
	book.RemoveByType();
	book.SetByCount();
	book.CountAll();
	book.RemoveByTypeFromBook();
	book.SortById();
	book.SortByName();
	book.SortByCount();
	book.Collect();
	}
}
