package HomeWork2;

import java.util.ArrayList;

public class Util {
	public void show(ArrayList<Student> arrayList) {
		for (Student student : arrayList) {
			System.out.println(student);
		}
	}
}
