package TK3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.TreeSet;

public class G {
	private FileInputStream fis;
	private ObjectInputStream ois;
	private FileOutputStream fos;
	private ObjectOutputStream oos;
	private Scanner scanner = new Scanner(System.in);

	@SuppressWarnings("unchecked")
	public ArrayList<Animal> reder(File file, ArrayList<Animal> st) {

		if (!file.isFile()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			fis = null;
			ois = null;
			try {
				fis = new FileInputStream(file);
				ois = new ObjectInputStream(fis);
				st = (ArrayList<Animal>) ois.readObject();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				werit(file, st);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return st;
	}
public void print(ArrayList<Animal> st){
	for (Animal animal : st) {
		System.out.println(animal);
	}
}
	public ArrayList<Animal> inprint(File file, ArrayList<Animal> st) {
		while (true) {
			System.out.println("age");
			String age = scanner.next();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("sex");
			String sex = scanner.next();
			Animal stu = new Animal(name, age, sex);
			if(st.contains(stu)){
				System.out.println("�Ѵ���");
			}else{
			st.add(stu);
			}
			System.out.println("�Ƿ����y/n");
			String str = scanner.next();
			if (str.equals("n") || str.equalsIgnoreCase("N")) {
				break;
			}
		}
		Collections.sort(st,new Comparator<Animal>() {

			@Override
			public int compare(Animal o1, Animal o2) {
				// TODO Auto-generated method stub
				return o1.getAge().compareTo(o2.getAge());
			}
		});
		return st;
	}

	public void werit(File f, ArrayList<Animal> st) {
		fos = null;
		oos = null;
		try {
			fos = new FileOutputStream(f);
			oos = new ObjectOutputStream(fos);
			TreeSet<Animal>S=new TreeSet<Animal>(st);
			oos.writeObject(S);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
