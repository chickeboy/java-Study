package TK3;

import java.io.Serializable;

public class Animal implements Serializable,Comparable<Animal>{
	private String name;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	private String age;
	private String sex;
	@Override
	public String toString() {
		return "name=" + name + ", age=" + age + ", \tsex=" + sex;
	}
	public Animal() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Animal(String name, String age, String sex) {
		super();
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	@Override
	public int compareTo(Animal o) {
		// TODO Auto-generated method stub
		return o.getAge().compareTo(getAge());
	}
}
