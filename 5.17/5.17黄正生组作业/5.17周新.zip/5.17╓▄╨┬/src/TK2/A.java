package TK2;

import java.io.Serializable;

public class A implements Serializable{
	private int id;
	private String name;
	private double score;
	private String adress;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		A other = (A) obj;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "id=" + id + ", \tname=" + name + ", \tscore=" + score
				+ ", \tadress=" + adress;
	}
	public A() {
		super();
		// TODO Auto-generated constructor stub
	}
	public A(int id, String name, double score, String adress) {
		super();
		this.id = id;
		this.name = name;
		this.score = score;
		this.adress = adress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	
}
