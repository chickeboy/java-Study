package TK2;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/*ʹ�ö�������һ����,ɾ,��,��Ĺ���.  
 * Student����(ѧ��,�ɼ�,����,��ַ)
 */
public class TK2 {
public static void main(String[] args) {
	File f=new File("s.txt");
	if(!f.isFile()){
		try {
			f.createNewFile();
		} catch (IOException e) {
						e.printStackTrace();
		}
	}
	ArrayList<A>a=new ArrayList<A>();
	a=new G().reder(a, f);
	Scanner scanner=new Scanner(System.in);
	while(true){
		System.out.println("===============");
		System.out.println("1.��");
		System.out.println("2.ɾ");
		System.out.println("3.��");
		System.out.println("4.��");
		System.out.println("5.�˳�");
		int t=0;
		while(true){
			try {
				t=scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		switch(t){
		case 1:
			a=new G().add(a, f);
			break;
		case 2:
			a=new G().remove(a);
			break;
		case 3:
			new G().chage(a);
			break;
		case 4:
			a=new G().look(a,f);
			break;
		case 5:
			new G().werit(a, f);
			System.exit(0);
		default :
			System.out.println("��������");
			break;
		}
	}
}
}
