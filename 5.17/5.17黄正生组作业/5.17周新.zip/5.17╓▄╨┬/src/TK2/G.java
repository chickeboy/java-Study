package TK2;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import TK3.Animal;
public class G {
	private FileInputStream fis;
	private FileOutputStream fos;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	public Scanner scanner = new Scanner(System.in);
	@SuppressWarnings("unchecked")
	public ArrayList<A> reder(ArrayList<A> a, File f) {
		if (!f.isFile()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
							e.printStackTrace();
			}
		} else {

			try {
				fis = new FileInputStream(f);
				ois = new ObjectInputStream(fis);
				a = (ArrayList<A>) ois.readObject();
			} catch (IOException e) {			
			} catch (ClassNotFoundException e) {
							e.printStackTrace();
			}
		}
		return a;
	}

	public ArrayList<A> add(ArrayList<A> a, File f) {
		a = reder(a, f);
		int id = 0;
		while (true) {
			System.out.println("name");
			String name = scanner.next();
			System.out.println("score");
			Double score = scanner.nextDouble();
			System.out.println("adress");
			String adress = scanner.next();
			a.add(new A(id++, name, score, adress));
			System.out.println("�Ƿ����y/n");
			String sre = scanner.next();
			if (sre.equals("n") || sre.equalsIgnoreCase("N")) {
				break;
			}
		}
		return a;
	}

	public int see(ArrayList<A> a, String str) {
		int t = -1;
		switch (str) {
		case "id":
			System.out.println("id");
			int id = scanner.nextInt();
			for (int i = 0; i < a.size(); i++) {
				if (id == a.get(i).getId()) {
					t = i;
					break;
				}
			}
			break;
		case "name":
			System.out.println("name");
			String name = scanner.next();
			for (int i = 0; i < a.size(); i++) {
				if (name.equals(a.get(i).getName())) {
					System.out.println(a.get(i));
				}
			}
			System.out.println("id");
			id = scanner.nextInt();
			for (int i = 0; i < a.size(); i++) {
				if (id == a.get(i).getId()) {
					t = i;
					break;
				}
			}
			break;
		case "score":
			System.out.println("score");
			Double score = scanner.nextDouble();
			for (int i = 0; i < a.size(); i++) {
				if (score == a.get(i).getScore()) {
					System.out.println(a.get(i));
				}
			}
			System.out.println("id");
			id = scanner.nextInt();
			for (int i = 0; i < a.size(); i++) {
				if (id == a.get(i).getId()) {
					t = i;
					break;
				}
			}
			break;
		case "adress":
			System.out.println("adress");
			String adress = scanner.next();
			for (int i = 0; i < a.size(); i++) {
				if (adress.equals(a.get(i).getAdress())) {
					System.out.println(a.get(i));
				}
			}
			System.out.println("id");
			id = scanner.nextInt();
			for (int i = 0; i < a.size(); i++) {
				if (id == a.get(i).getId()) {
					t = i;
					break;
				}
			}
			break;
		default:
			System.out.println("��������");
			break;
		}
		return t;
	}
	public int se(ArrayList<A> a, String str) {
		int t = -1;
		switch (str) {
		case "id":
			System.out.println("id");
			int id = scanner.nextInt();
			for (int i = 0; i < a.size(); i++) {
				if (id == a.get(i).getId()) {
					t = i;
					break;
				}
			}
			break;
		case "name":
			System.out.println("name");
			String name = scanner.next();
			for (int i = 0; i < a.size(); i++) {
				if (name.equals(a.get(i).getName())) {
					System.out.println(a.get(i));
					t=i;
				}
			}
			break;
		case "score":
			System.out.println("score");
			Double score = scanner.nextDouble();
			for (int i = 0; i < a.size(); i++) {
				if (score == a.get(i).getScore()) {
					System.out.println(a.get(i));
					t=i;
				}
			}
			break;
		case "adress":
			System.out.println("adress");
			String adress = scanner.next();
			for (int i = 0; i < a.size(); i++) {
				if (adress.equals(a.get(i).getAdress())) {
					System.out.println(a.get(i));
					t=i;
				}
			}
			break;
		default:
			System.out.println("��������");
			break;
		}
		return t;
	}
	public ArrayList<A> remove(ArrayList<A> a) {
		while (true) {
			System.out.println("1.ɾ��ȫ��");
			System.out.println("2.����idɾ��");
			System.out.println("3.����nameɾ��");
			System.out.println("4.����scoreɾ��");
			System.out.println("5.����adressɾ��");
			System.out.println("6.������һ��");
			int t = 0;
			while (true) {
				try {
					t = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			switch (t) {
			case 1:
				a.clear();
				break;
			case 2:
				int c = see(a, "id");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println(a.remove(c));
					break;
				}
			case 3:
				c = see(a, "name");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println(a.remove(c));
					break;
				}
			case 4:
				c = see(a, "score");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println(a.remove(c));
					break;
				}
			case 5:
				c = see(a, "adress");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println(a.remove(c));
					break;
				}
			case 6:
				return a;
			default:
				System.out.println("��������");
				break;
			}
		}
	}

	public void chage(ArrayList<A> a) {
		while (true) {
			System.out.println("1.����name��");
			System.out.println("2.����score��");
			System.out.println("3.����adress��");
			System.out.println("4.������һ��");
			int t = 0;
			while (true) {
				try {
					t = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			switch (t) {
			case 1:
				int c = see(a, "name");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println("name");
					String name = scanner.next();
					a.get(c).setAdress(name);
					break;
				}
			case 2:
				c = see(a, "score");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println("score");
					Double score = scanner.nextDouble();
					a.get(c).setScore(score);

					break;
				}
			case 3:
				c = see(a, "adress");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println("adress");
					String adress = scanner.next();
					a.get(c).setAdress(adress);
					break;
				}
			case 4:
				return;
			default:
				System.out.println("��������");
				break;
			}
		}
	}

	public ArrayList<A> look(ArrayList<A> a, File f) {
		a = reder(a, f);
		while (true) {
			System.out.println("1.�鿴ȫ��");
			System.out.println("2.����id");
			System.out.println("3.����name");
			System.out.println("4.����score");
			System.out.println("5.����adress");
			System.out.println("6.������һ��");
			int t = 0;
			while (true) {
				try {
					t = scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
			}
			switch (t) {
			case 1:
				print(a);
				break;
			case 2:
				int c = se(a, "id");
				if (c == -1) {
					System.out.println("������ ");
					break;
				} else {
					System.out.println(a.get(c));
					break;
				}
			case 3:
				c = se(a, "name");
				if (c == -1) {
					System.out.println("������ ");
				}
				break;
			case 4:
				c = se(a, "score");
				if (c == -1) {
					System.out.println("������ ");
				}
				break;
			case 5:
				c = se(a, "adress");
				if (c == -1) {
					System.out.println("������ ");
				}
				break;
			case 6:
				return a;
			default:
				System.out.println("��������");
				break;
			}
		}
	}

	public void print(ArrayList<A> a) {
		for (A a2 : a) {
			System.out.println(a2);
		}
	}

	public void werit(ArrayList<A> a, File f) {

		try {
			fos = new FileOutputStream(f);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(a);
		} catch (IOException e) {
					e.printStackTrace();
		}
	}
}
