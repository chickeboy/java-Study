package Hk2;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * ʹ�ö�������һ����,ɾ,��,��Ĺ���.  Student����(ѧ��,�ɼ�,����,��ַ)
 */
public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("2.txt");
		Util util = new Util(file);
		ArrayList<Student> al = new ArrayList<Student>();
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("score");
			double score = scanner.nextDouble();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("adress");
			String adress = scanner.next();
			Student student = new Student(id, score, name, adress);
			al.add(student);
		}
		util.write(al);
		ArrayList<Student> read = util.read();
		for (Student student : read) {
			System.out.println(student);
		}

		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫ�޸ĵ�id");
			int id = scanner.nextInt();			
				if (id == al.get(i).getId()) {					
					System.out.println("�޸�name");
					String name1 = scanner.next();
					al.get(i).setName(name1);	
					break;
			}
		}
		util.write(al);
		ArrayList<Student> read2 = util.read();
		for (Student stu : read2) {
			System.out.println(stu);
		}
		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫɾ����id");
			int id = scanner.nextInt();
			if (id == al.get(i).getId()) {
				al.remove(i);				
				break;
			}
		}
		util.write(al);
		ArrayList<Student> read1 = util.read();
		for (Student stu : read1) {
			System.out.println(stu);
		}
		
		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫ��ѯ��id");
			int id = scanner.nextInt();
			if (al.get(i).getId() == id) {
				System.out.println(al.get(i));
				id = -1;
				break;
			}	
		if (id != -1)
			System.out.println("������");
		}
		
		util.write(al);
		ArrayList<Student> read3 = util.read();
		for (Student student : read3) {
			System.out.println(student);
		}
	}

}