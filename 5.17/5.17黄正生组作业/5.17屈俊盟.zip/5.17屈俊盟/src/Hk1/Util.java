package Hk1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;
public class Util implements Serializable{
	private FileInputStream fis;
	private ObjectInputStream ois;
	private FileOutputStream fos;
	private ObjectOutputStream oos;
	private Scanner scanner=new Scanner(System.in);
	@SuppressWarnings("unchecked")
	public ArrayList<Student> reder(File file,ArrayList<Student>st){
		
		if(!file.isFile()){
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
		fis=null;
		ois=null;
		try {
			fis=new FileInputStream(file);
			ois=new ObjectInputStream(fis);
			st=(ArrayList<Student>) ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			write(file,st);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		return st;
		}
	public void print(ArrayList<Student> st) {
		for (Student stu : st) {
			System.out.println(stu);
		}
	}
	
	
	public void write(File f,ArrayList<Student> st){
		fos=null;
		oos=null;
		try {
			fos=new FileOutputStream(f);
			oos=new ObjectOutputStream(fos);
			oos.writeObject(st);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}