package Hk1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Hk1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		File file = new File("e:\\a.txt");
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		ArrayList<Student> al = new ArrayList<Student>();
		al.add(new Student("chenhao"));
		al.add(new Student("zhangsan"));
		al.add(new Student("zhangsan"));
		al.add(new Student("chenhao"));
		al.add(new Student("lisi"));
		al.add(new Student("wangwu"));
		al.add(new Student("zhaoliu"));
		al.add(new Student("xiaoqiang"));
		al.add(new Student("Haha"));
		Collections.sort(al,new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				int i=o1.getName().length()-o2.getName().length();
				if(i==0){
					i=o1.getName().compareTo(o2.getName());
				}
				return i;
			}
		});
		oos.writeObject(al);
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		al = (ArrayList<Student>) ois.readObject();
		for (Student student : al) {
			System.out.println(student);
		}
	}

}
