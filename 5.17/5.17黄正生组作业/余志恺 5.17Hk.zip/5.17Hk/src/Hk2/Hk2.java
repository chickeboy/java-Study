package Hk2;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * ʹ�ö�������һ����,ɾ,��,��Ĺ���.  Student����(ѧ��,�ɼ�,����,��ַ)
 */
public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("d:\\ooo.txt");
		Util util = new Util(file);
		ArrayList<Student> al = new ArrayList<Student>();
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("score");
			double score = scanner.nextDouble();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("adress");
			String adress = scanner.next();
			Student a = new Student(id, score, name, adress);
			al.add(a);
		}
		util.write(al);
		ArrayList<Student> read = util.read();
		for (Student a : read) {
			System.out.println("���Ӻ�"+a);
		}

		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫ�޸ĵ�id");
			int id = scanner.nextInt();			
				if (id == al.get(i).getId()) {					
					System.out.println("�޸ĳɼ�");
					double score = scanner.nextDouble();
					al.get(i).setScore(score);	
					break;
			}
		}
		util.write(al);
		ArrayList<Student> read2 = util.read();
		for (Student a : read2) {
			System.out.println("�޸ĺ�"+a);
		}
		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫɾ����id");
			int id = scanner.nextInt();
			if (id == al.get(i).getId()) {
				al.remove(i);				
				break;
			}
		}
		util.write(al);
		ArrayList<Student> read1 = util.read();
		for (Student a : read1) {
			System.out.println("ɾ����"+a);
		}
		
		for (int i = 0; i < al.size(); i++) {
			System.out.println("������Ҫ��ѯ��id");
			int id = scanner.nextInt();
			if (al.get(i).getId() == id) {
				System.out.println("��ѯ"+al.get(i));
				id = -1;
				break;
			}	
		if (id != -1)
			System.out.println("������");
		}
		
		util.write(al);
		ArrayList<Student> read3 = util.read();
		for (Student a : read3) {
			System.out.println("��ѯ��"+a);
		}
	}

}