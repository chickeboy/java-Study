package Hk2;

import java.io.Serializable;

public class Student implements Serializable{
private int id;
private double score;
private String name;
private String adress;
public Student(int id, double score, String name, String adress) {
	super();
	this.id = id;
	this.score = score;
	this.name = name;
	this.adress = adress;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getScore() {
	return score;
}
public void setScore(double score) {
	this.score = score;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAdress() {
	return adress;
}
public void setAdress(String adress) {
	this.adress = adress;
}
@Override
public String toString() {
	return "Student [id=" + id + ", score=" + score + ", name=" + name + ", adress=" + adress + "]";
}

}
