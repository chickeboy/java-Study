package Hk2;

public class Show {
	int a;
	int b;
	double c;
	double d;
	double e;
	String str1;
	String str2;
public void max(int a,int b) {
	int max=0;
	if(max>=b) {
		max=a;
	}else {
		max=b;
	}
	System.out.println("�ϴ��һ������:"+max);
}
public void sum(double c,double d,double e) {
	System.out.println("�������ĳ˻���:"+c*d*e) ;
}
public void deng(String str1,String str2) {
	if(str1.equals(str2)) {
		System.err.println(true);
	}else {
		System.err.println(false);;
	}
}
}