package Hk2;

public class Show {
	int a;
	int b;
	double c;
	double d;
	double e;
	String str;
	String str1;
public void duibi(int a,int b) {
	int max=0;
	if(max>=b) {
		max=a;
	}else {
		max=b;
	}
	System.out.println("�ϴ��һ����"+max);
}
public void sum(double c,double d,double e) {
	System.out.println("�������ĳ˻���"+c*d*e) ;
}
public void deng(String str,String str1) {
	if(str.equals(str1)) {
		System.err.println(true);
	}else {
		System.err.println(false);;
	}
}
}