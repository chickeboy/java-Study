package Hk3;

public class Number {
	private int n1;
	private int n2;
	public void setN1(int n1,int n2) {
		this.n1 = n1;
		this.n2 = n2;
	}
	
}

