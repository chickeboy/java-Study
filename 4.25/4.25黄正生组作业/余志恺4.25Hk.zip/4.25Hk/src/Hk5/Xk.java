package Hk5;
//�Կ�
public class Xk {
	int x;
	String brand;

	public Xk() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Xk(int x, String brand) {
		super();
		this.x = x;
		this.brand = brand;
	}
}
