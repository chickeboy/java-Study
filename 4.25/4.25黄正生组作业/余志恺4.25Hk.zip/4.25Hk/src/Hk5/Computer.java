package Hk5;
import java.util.*;
public class Computer {
	String Xk;

	String Sk;

	String Cpu;
	public void install() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("�����۸�");
		int s=scanner.nextInt();
		System.out.println("Ʒ��");
		String brand=scanner.next();
		Sk sk=new Sk(s, brand);
		System.out.println("�Կ��۸�");
		int x=scanner.nextInt();
		System.out.println("Ʒ��");
		String brand1=scanner.next();
		Xk xk=new Xk(x, brand);
		System.out.println("Cpu�۸�");
		int c=scanner.nextInt();
		System.out.println("Ʒ��");
		String brand2=scanner.next();
		Cpu cpu=new Cpu(c, brand2);
		System.out.println("Ʒ��\t"+"�۸�\n"+sk.brand+"\t"+sk.s+"\n"+xk.brand+"\t"+xk.x+"\n"+cpu.brand+"\t"+cpu.c);
	}

	}
