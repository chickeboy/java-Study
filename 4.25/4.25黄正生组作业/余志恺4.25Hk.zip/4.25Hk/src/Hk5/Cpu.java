package Hk5;

public class Cpu {
	int c;
	String brand;

	public Cpu() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cpu(int c, String brand) {
		super();
		this.c = c;
		this.brand = brand;
	}
}
