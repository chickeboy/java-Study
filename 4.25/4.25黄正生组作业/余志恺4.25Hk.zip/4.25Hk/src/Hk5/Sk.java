package Hk5;

//����
public class Sk {
	int s;
	String brand;

	public Sk() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sk(int s, String brand) {
		super();
		this.s = s;
		this.brand = brand;
	}
}
