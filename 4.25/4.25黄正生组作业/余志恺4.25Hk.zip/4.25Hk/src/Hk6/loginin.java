package Hk6;

import java.util.*;

public class loginin {
	

	String username;
	String password;

	public void ce() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("����ע���˺�");
		String username = scanner.next();
		this.username = username;
		System.out.println("����ע������");
		String password = scanner.next();
		this.password = password;
	}

}
