package Hk6;

import java.util.ArrayList;

public class Hk6 {
	public static void main(String[] args) {
		new Menu().mainMenu();
		ArrayList<Student> arrayList = new ArrayList<Student>();
		arrayList.add(new Student(3, "����","��",22,89));
	}
}