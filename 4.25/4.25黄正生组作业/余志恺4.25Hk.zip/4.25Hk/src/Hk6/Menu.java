package Hk6;

import java.util.*;

public class Menu {
	private Scanner scanner = new Scanner(System.in);
	private String choice;
	private Manager manager = new Manager();

	public void mainMenu() {
		while (true) {
			System.out.println("1.ע��");
			System.out.println("2.��¼");
			System.out.println("3.����ѧ��");
			System.out.println("4.ɾ��ѧ��");
			System.out.println("5.�޸�ѧ��");
			System.out.println("6.�鿴ѧ��");			
			choice = scanner.next();
			switch (choice) {
			case "1":
				loginin login = new loginin();
				System.out.println("ע��ɹ�");
				break;
			case"2":
				register();							
				break;
			case "3":
				addMenu();
				break;
			case "4":
				removeByIdMenu();
				break;
			case "5":
				updateMenu();
				break;
			case "6":
				searchAllMenu();
				break;			
			}
		}
	}

	public void updateMenu() {
		while (true) {
			System.out.println("������Ҫ�޸ĵ�ѧ��id");
			int id = scanner.nextInt();
			System.out.println("������Ҫ�޸ĵ�name");
			String name = scanner.next();
			System.out.println("������Ҫ�޸ĵ�id");
			int newId = scanner.nextInt();
			System.out.println("������Ҫ�޸ĵ�gender");
			String gender = scanner.next();
			System.out.println("������Ҫ�޸ĵ�age");
			int age = scanner.nextInt();
			System.out.println("������Ҫ�޸ĵ�score");
			double score = scanner.nextInt();
			Student student = new Student(newId, name,gender,age,score);
			if (manager.update(id, student)) {
				System.out.println("�޸ĳɹ�");
			} else {
				System.out.println("�޸�ʧ��");
			}
			if (!job.isGoOn()) {
				break;
			}
		}
	}

	public void searchAllMenu() {
		Student[] stus = manager.getAll();
		job.show(stus, "����ѧ����Ϣ");
	}

	public void removeByIdMenu() {
		while (true) {
			System.out.println("������Ҫɾ����id");
			int id = scanner.nextInt();
			if (manager.remove(id)) {
				System.out.println("ɾ���ɹ�");
			} else {
				System.out.println("ɾ��ʧ��");
			}
			if (!job.isGoOn()) {
				break;
			}
		}
	}

	public void addMenu() {
		while (true) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("name");
			String gender = scanner.next();
			System.out.println("name");
			int age = scanner.nextInt();
			System.out.println("name");
			double score = scanner.nextDouble();
			Student student = new Student(id, name,gender,age,score);
			if (manager.save(student)) {
				System.out.println("���ӳɹ�");
			} else {
				System.out.println("����ʧ��");
			}
			if (!job.isGoOn()) {
				break;
			}
		}
	}
	public void register() {
		loginin login = new loginin();
		while(true) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("��¼�˺�");
			String users1 = scanner.next();		
			System.out.println("��¼����");
			String number1 = scanner.next();	
			if (!users1.equals(login.username)||!number1.equals(login.password)){
				System.out.println("��������");				
			}else {
				System.out.println("��½�ɹ�");
				break;
			}
		}
	}
	

}	

