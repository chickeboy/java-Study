package Hk3;

public class Number {
	private int n1;
	private int n2;

	public Number(int n1, int n2) {

		this.n1 = n1;
		this.n2 = n2;
	}

	public void addition() {
		System.out.println("additionΪ: "+(n1 + n2));
	}

	public void subtration() {
		System.out.println("subtratioΪ: "+(n1 - n2));
	}

	public void multiplication() {
		System.out.println("multiplicationΪ: "+(n1 * n2));
	}

	public void division() {
		System.out.println("divisionΪ: "+(n1 / n2));
	}


}