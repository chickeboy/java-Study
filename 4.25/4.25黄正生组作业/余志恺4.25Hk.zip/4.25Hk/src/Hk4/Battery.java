package Hk4;

public class Battery {


String str;
int a=100;
public void setStr(String str) {
	this.str = str;
}
public double hao(int a) {
	return a;
}
}


