package Hk4;
import java.util.*;
public class Jixu {
	
public boolean pan() {
	Scanner scanner = new Scanner(System.in);
	System.err.println("�Ƿ����ͨ����y/n��");
	String str=scanner.next();
	if(str.equals("Y")||str.equals("y")) {
		return false;
	}else {
		return true;
	}

}
}
