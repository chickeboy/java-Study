package Hk4;

public class Phone {
	String str;
	double duo=100;
	public void setStr(String str) {
		this.str = str;
	}
	public void use(int b) {
		Battery battery=new Battery();
		duo=duo-battery.hao(b);
	}
	}

