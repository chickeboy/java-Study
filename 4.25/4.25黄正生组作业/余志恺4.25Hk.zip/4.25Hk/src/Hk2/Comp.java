package Hk2;

public class Comp {
	int a;
	int b;
	double d1;
	double d2;
	double d3;
	String s1;
	String s2;

	Comp(int a, int b) {
		this.a = a;
		this.b = b;
		System.out.println("a: " + a);
		System.out.println("b: " + b);
		if (a > b)
			System.out.println("�ϴ��ֵ��: " + a);
		else
			System.out.println("�ϴ��ֵ��: " + b);
	}

	Comp(double d1, double d2, double d3) {
		this.d1 = d1;
		this.d2 = d2;
		this.d3 = d3;
		System.out.println("d1: " + d1);
		System.out.println("d2: " + d2);
		System.out.println("d3: " + d3);
		System.out.println("�������ĳ˻���: " + d1 * d2 * d3);
	}

	Comp(String s1, String s2) {
		this.s1 = s1;
		this.s2 = s2;
		System.out.println("s1: " + s1);
		System.out.println("s2: " + s2);
		if (s1.compareTo(s2) == 0)
			System.out.println("�����ַ�����ͬ");
		else
			System.out.println("�����ַ�����ͬ");
	}

	public void newLine() {
		System.out.println();
		System.out.println();
	}

	
}
