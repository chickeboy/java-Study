package tk5;

import tk3.Student;

public class G implements Comparable<G>{
private Integer id;
private Student student;
@Override
public String toString() {
	return "id=" + id + ", student=" + student;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public Student getStudent() {
	return student;
}
public void setStudent(Student student) {
	this.student = student;
}
public G() {
	super();
	// TODO Auto-generated constructor stub
}
public G(Integer id, Student student) {
	super();
	this.id = id;
	this.student = student;
}
@Override
public int compareTo(G o) {
	// TODO Auto-generated method stub
	return (int) (o.getStudent().getScore()-getStudent().getScore());
}


}
