package Hk1;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

/*
 * ��asdascveasrgdfsdf����ȡ���ַ����У�ÿһ����ĸ���ֵĴ�����
Ҫ�󣺴�ӡ����ǣ�a(2)b(1)...
 */
public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "asdascveasrgdfsdf";
		char[] arr = str.toCharArray();
		HashMap<Character, Integer> hm = new HashMap<>();
		for (char c : arr) {
			if (!hm.containsKey(c)) {
				hm.put(c, 1);
			} else {
				hm.put(c, hm.get(c) + 1);
			}
		}
		Set<Entry<Character, Integer>> entrySet = hm.entrySet();
		for (Entry<Character, Integer> entry : entrySet) {
			System.out.println(entry.getKey()+"("+entry.getValue()+")");		
		}
		
	}

}