package Hk4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] array={"chenchao","zhangsan","zhangsan","chenhao","lisi","wangwu","zhaoliu","xiaopqiang","haha","chenchao"};
     
        Map<String,Integer> map = new HashMap<String,Integer>();
        for(int i=0;i<array.length;i++){
            if(!map.containsKey(array[i])){
                map.put(array[i],1);
            }else{
                map.put(array[i], map.get(array[i])+1);
            }
        }     
        Iterator<Map.Entry<String, Integer>> entries = map.entrySet().iterator();
        while(entries.hasNext()){
            Map.Entry<String, Integer> entry = entries.next();
            System.out.println(entry.getKey()+"("+entry.getValue()+")");
        }
	}

}
