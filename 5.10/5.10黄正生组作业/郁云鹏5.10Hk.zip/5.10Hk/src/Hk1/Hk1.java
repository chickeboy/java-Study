package Hk1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "asdascveasrgdfsdf";
	    char[] array = str.toCharArray();
     
        Map<Character,Integer> map = new HashMap<Character,Integer>();
        for(int i=0;i<array.length;i++){
            if(!map.containsKey(array[i])){
                map.put(array[i],1);
            }else{
                map.put(array[i], map.get(array[i])+1);
            }
        }     
        Iterator<Map.Entry<Character, Integer>> entries = map.entrySet().iterator();
        while(entries.hasNext()){
            Map.Entry<Character, Integer> entry = entries.next();
            System.out.println(entry.getKey()+"("+entry.getValue()+")");
        }

	}

}
