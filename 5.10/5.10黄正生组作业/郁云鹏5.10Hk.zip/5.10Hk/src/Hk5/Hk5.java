package Hk5;

import java.util.HashMap;

import Hk5.Student;

public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Student,String> map = new HashMap<>(); 
		map.put(new Student("����",1,23,88),"1");
		map.put(new Student("����",2,24,53),"2");
		map.put(new Student("����",3,25,73),"3");
		map.put(new Student("����",4,26,98),"4");
		map.put(new Student("����",1,21,82),"5");		
        System.out.println(map);
	}

}
