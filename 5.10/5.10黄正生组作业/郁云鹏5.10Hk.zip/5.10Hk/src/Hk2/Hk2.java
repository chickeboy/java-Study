package Hk2;

import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry; 

public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random random = new Random();
		TreeMap<Integer, Integer> map = new TreeMap<Integer, Integer>();
	    for (int i = 0; i < 50; i++) {
	        int n = random.nextInt(6) + 30;
	        Integer count = map.get(n);
	        if (count == null) {
	            map.put(n, 1);
	        } else {
	            map.put(n, count + 1);
	        }
	    }
	    Set<Entry<Integer, Integer>> entrySet = map.entrySet();
	    int max = 0;
	    Entry<Integer, Integer> entryMax = null;
	    for (Entry<Integer, Integer> entry : entrySet) {
	        if (entry.getValue() > max) {
	            max = entry.getValue();
	            entryMax = entry;
	        }
	        System.out.println(entry.getKey() + ":" + entry.getValue());
	    }
	    System.out.println("===========================");
	    System.out.println("������������" + entryMax.getKey() + ",������" + entryMax.getValue() + "��");

	}

}
