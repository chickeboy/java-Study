package Hk2;
/*
 *  随机产生50个30到35的整数，统计每个数字出现的次数（TreeMap实现），输出时按照数字的降序排列，并且统计出现次数最多的数字和它的次数。
PS：如果有两个数字出现的次数一样，则只需输出其中一个。
 */
import java.util.*;
import java.util.Map.Entry;
public class Hk2 {
	public static void main (String [] args) {
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>();
		Random random = new Random ();
		for (int i = 0;i<50;i++) {
			int num = random.nextInt(6)+30;
			int count = 1;
			if(hm.containsKey(num)) {
				count=hm.get(num)+1;
			}
			hm.put(num, count);
		}
		TreeMap<Integer, Integer> tm = new TreeMap<Integer, Integer>(new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				return o2-o1;
			}
		});
		tm.putAll(hm);

		Set<Entry<Integer, Integer>> entrySet = tm.entrySet();
		for (Entry<Integer, Integer> entry : entrySet) {
			System.out.println(entry.getKey()+":"+entry.getValue());
			
		}
		System.out.println("========================================");
		int max = 0;
		int key =0;
		for (Entry<Integer, Integer> entry : entrySet) {
			if (tm.get(entry.getKey())>max) {
				max =tm.get(entry.getKey());
				key =entry.getKey();
			}if (tm.get(entry.getKey())==max) {
				key = entry.getKey();
			}
		}
		System.out.println(key+":"+max);
	}
}
