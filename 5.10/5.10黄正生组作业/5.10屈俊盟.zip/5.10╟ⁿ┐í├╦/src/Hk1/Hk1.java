package Hk1;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*
 * ��asdascveasrgdfsdf����ȡ���ַ����У�ÿһ����ĸ���ֵĴ�����
Ҫ�󣺴�ӡ����ǣ�a(2)b(1)...
 */

public class Hk1 {

	public static void main(String [] args) {
		
		String num = "asdascveasrgdfsdf";
		char [] array = num.toCharArray();
		Map<Character, Integer> hm= new HashMap<Character, Integer>();
		for (int i = 0;i<array.length;i++) {
			int count = 1;
			if(hm.containsKey(array[i])) {
				count=hm.get(array[i])+1;
			}
			hm.put(array[i], count);
		}
		Set<Entry<Character, Integer>> entrySet = hm.entrySet();
		for (Entry<Character, Integer> entry : entrySet) {
			System.out.print(entry.getKey());
			System.out.println(entry.getValue());
		}
	}

}
