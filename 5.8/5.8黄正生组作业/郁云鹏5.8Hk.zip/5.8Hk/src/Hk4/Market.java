package Hk4;

import java.util.ArrayList;
import java.util.Scanner;

import Hk1.Student;


public class Market {
	private ArrayList<Shop> al;
	private Scanner scanner;
	
	public Market() {
		al = new ArrayList<>();
		scanner = new Scanner(System.in);
		
	}
	
	public void add() {
		while (true) {
			System.out.println("id");
			int id = scanner.nextInt();			
			System.out.println("size");
			int size = scanner.nextInt();
			Shop shop = new Shop(id,size);
			if(al.contains(shop)) {
				System.out.println("id�ظ�");
			} else {
				al.add(shop);
				System.out.println("���ӳɹ������n�˳�");
				String choice = scanner.next();
				if(choice.equals("n")){
					break;
				}
			}
		}
	}
	public void del() {
		System.out.println("��������Ҫɾ������Ʒid");
		int id = scanner.nextInt();
		Shop shop = new Shop(id);
		if (al.remove(shop)) {
			System.out.println("ɾ���ɹ�");
		} else {
			System.out.println("ɾ��ʧ��");
		}
	}
}
