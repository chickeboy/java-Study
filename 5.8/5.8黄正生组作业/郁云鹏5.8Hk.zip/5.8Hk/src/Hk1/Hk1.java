package Hk1;

public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m = new Manager();
		m.add();
		m.del();
		m.check1();
		m.check2();
		m.check3();
		m.search1();
		m.search2();
	}

}
