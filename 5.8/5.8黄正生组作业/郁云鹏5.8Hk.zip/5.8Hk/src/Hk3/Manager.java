package Hk3;

import java.util.ArrayList;
import java.util.Random;

public class Manager {
   public void strat() {
	   ArrayList<Integer> al = new ArrayList<>(50);
		Random random = new Random();
		for (int i = 0;i<50;i++) {
			int num = random.nextInt(6)+30;
			al.add(num);
		}
   }
}
