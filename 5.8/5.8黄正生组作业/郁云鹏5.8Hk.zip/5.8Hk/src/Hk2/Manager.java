package Hk2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import Hk2.Student;
public class Manager {
	
	public static void start() {
	ArrayList<Student> al = new ArrayList<>();
	Student student = new Student(4,"a",99);
	al.add(student);
	student = new Student(5,"b",88);
	al.add(student);
	for (Student stu : al) {
		System.out.println(stu);
	}
	for(int i = 0 ; i<al.size();i++)
		if (al.get(i).getId()==4) {
			al.remove(i);
		}
	for (int i = 0; i < al.size(); i++) {
		if (al.get(i).getId()==5) {
			al.get(i).setName("666");
		}
	}
	for (Student stu : al) {
		System.out.println(stu);
	}
	}
}
