package Hk2;

public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Manager.start();
	}

}
