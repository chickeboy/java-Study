package Hk4;
/*
 * 创建购物车实体类，模拟购物车功能
需求：
1) 添加商品到购物车（输入商品的编号和数量）
2) 删除商品（删除购物车中的指定购物项）
3) 修改商品（修改商品的数量）
4) 显示所购买的商品信息（按购买商品的总价进行升序显示）
 */

public class Hk4 {
	public static void main (String [] args) {
		
	}

}
