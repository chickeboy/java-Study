package Hk2;

import java.util.ArrayList;
import java.util.Iterator;

/*
 * 2. 使用listIterator获取学生对象
 在迭代器中添加一个学号为4，名字叫 a 成绩为99的学生
 遍历，删除 学号为4的学生，
 修改学号为5的学员的name 为 666
 */

public class Hk2 {
	public static void main (String [] args) {
		ArrayList<Student> al = new ArrayList<>();
		Student student = new Student(4,"a",99);
		al.add(student);
		student = new Student(5,"b",99);
		al.add(student);
		for (Student st : al) {
			System.out.println(st);
		}
		for(int i = 0 ; i<al.size();i++)
			if (al.get(i).getId()==4) {
				al.remove(i);
			}
		for (int i = 0; i < al.size(); i++) {
			if (al.get(i).getId()==5) {
				al.get(i).setName("666");
			}
		}
		System.out.println("*****************************");
		for (Student stu : al) {
			System.out.println(stu);
		}
	}		
}
