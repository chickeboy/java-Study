package tk4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Shoop {
private String id;
private int ton;
private int jia;
private int sum;
@Override
public String toString() {
	return "id=" + id + ", ton=" + ton + ", jia=" + jia + ", sum=" + sum;
}
public void print(ArrayList<Shoop>sh){
	Collections.sort(sh,new Comparator<Shoop>() {

		@Override
		public int compare(Shoop o1, Shoop o2) {
			// TODO Auto-generated method stub
			return (int) (o2.getSum()-o1.getSum());
		}
	});
	for (Shoop shoop : sh) {
		System.out.println(shoop);
	}
}
public void set(ArrayList<Shoop>sh){
	Scanner scanner=new Scanner(System.in);
	System.out.println("id");
	String id=scanner.next();
	int ton=0;
	while(true){
		System.out.println("ton");
		try {
			ton=scanner.nextInt();
		} catch (Exception e) {
			System.out.println("����������");
			scanner.nextLine();
			continue;
		}
		break;
		}
	if(!sh.contains(id)){
	sh.set(sh.indexOf(new Shoop(id,0,1,1)), new Shoop(id,ton,1,1));
	System.out.println("�޸ĳɹ�");
	}else{
		System.out.println("û�д���Ʒ");
	}
}
public void remove(ArrayList<Shoop>sh){
	Scanner scanner=new Scanner(System.in);
	System.out.println("id");
	String id=scanner.next();
	if(!sh.contains(id)){
	sh.remove(sh.indexOf(new Shoop(id,0,1,1)));
	System.out.println("ɾ���ɹ�");
	}else{
		System.out.println("û�д���Ʒ");
	}
}
public ArrayList<Shoop> get(ArrayList<Shoop>sh){
	Scanner scanner=new Scanner(System.in);
	while(true){
		int ton=0;
		System.out.println("id");
		String id=scanner.next();
		while(true){
		System.out.println("ton");
		try {
			ton=scanner.nextInt();
		} catch (Exception e) {
			System.out.println("����������");
			scanner.nextLine();
			continue;
		}
		break;
		}
		Shoop shoop=new Shoop(id, ton,1,1);
		if(!sh.contains(shoop)){
			sh.add(shoop);
			System.out.println("���ӳɹ�");
		}else{
			System.out.println("����ʧ��");
		}
		System.out.println("�Ƿ����y/n");
		String str=scanner.next();
		char a=str.charAt(0);
		if(a=='n'||a=='N'){
			break;
		}
	}
	return sh;
}
public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public int getTon() {
	return ton;
}

public void setTon(int ton) {
	this.ton = ton;
}

public int getJia() {
	return jia;
}

public void setJia(int jia) {
	this.jia = jia;
}

public double getSum() {
	return sum;
}

public void setSum(int sum) {
	this.sum = sum;
}

public Shoop(String id, int ton,int sum,int jia) {
	super();
	this.id = id;
	this.ton = ton;
	this.sum=ton*jia;
	this.jia=jia;
}

public Shoop() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((id == null) ? 0 : id.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Shoop other = (Shoop) obj;
	if (id == null) {
		if (other.id != null)
			return false;
	} else if (!id.equals(other.id))
		return false;
	return true;
}
}
