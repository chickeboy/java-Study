package tk1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student {
	public static Scanner scanner=new Scanner(System.in);
	private int id;
	private String name;
	private int age;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", age=" + age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public void get3(ArrayList<Student>st){
		for (int i = 0; i < st.size(); i++) {
			if(4==st.get(i).getAge()){
				System.out.println(st.get(i));
			}
		}
	}
	public void get2(ArrayList<Student>st){
		System.out.println("name");
		String name=scanner.next();
		int age=-1;
		while(true){
			System.out.println("age");
			try {
				age=scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		int id=look1();
		int t=-1;
		for (int i = 0; i < st.size(); i++) {
			if(name.contains(st.get(i).getName())&&age==st.get(i).getAge()&&id==st.get(i).getId()){
				t=i;
				break;
			}
		}
		if(t>=0){
			st.set(t, new Student(id,name,55));
		}else{
			System.out.println("������");
		}
	}
	public void get1(ArrayList<Student>st){
		System.out.println("name");
		String name=scanner.next();
		int age=-1;
		while(true){
			System.out.println("age");
			try {
				age=scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		int t=-1;
		for (int i = 0; i < st.size(); i++) {
			if(name.contains(st.get(i).getName())&&age==st.get(i).getAge()){
				t=i;
				break;
			}
		}
		if(t>=0){
			System.out.println("����\t"+t);
		}else{
			System.out.println("������");
		}
	}
	public void get(ArrayList<Student>st){
		System.out.println("name");
		String name=scanner.next();
		int t=-1;
		for (int i = 0; i < st.size(); i++) {
			if(name.contains(st.get(i).getName())){
				t=i;
				break;
			}
		}
		if(t>=0){
			System.out.println("����\t"+t);
		}else{
			System.out.println("������");
		}
	}
	public void remove(ArrayList<Student>st){
		int t=look(st);
		if(t>=0){
			st.remove(t);
		System.out.println("ɾ���ɹ�");
		print(st);
		}else{
			System.out.println("������");
		}
	}
	public <T>void print(List<T>list){
		for (T t : list) {
			System.out.println(t);
		}
	}
	public int look(ArrayList<Student>st){
		int t=-1;
		while(true){
		t=look1();
		if(t<0){
			System.out.println("��������");
			continue;
		}else{
			t=st.indexOf(new Student(t,"",1));
			break;
		}
		}
		return t;
	}
	public int look1(){
		int t=-1;
		while(true){
			System.out.println("id");
			try {
				t=scanner.nextInt();
			} catch (Exception e) {
				System.out.println("��������");
				scanner.nextLine();
				continue;
			}
			break;
		}
		return t;
	}
	public void input(ArrayList<Student>st){
		int id=-1;String name="";int age=-1;
		for (int i = 0; i < 5; i++) {
			while(true){
			System.out.println("id");
			try {
				id=scanner.nextInt();
			} catch (Exception e) {
				System.out.println("����������");
				scanner.nextLine();
				continue;
			}
			break;
			}
			System.out.println("name");
					name=scanner.next();
			while(true){
				System.out.println("age");
				try {
					age=scanner.nextInt();
				} catch (Exception e) {
					System.out.println("����������");
					scanner.nextLine();
					continue;
				}
				break;
				}
			Student student=new Student(id, name, age);
			if(!st.contains(student)){
			st.add(student);
			System.out.println("¼��ɹ�");
		}else{
			System.out.println("��������");
			}
		}
	}
}
