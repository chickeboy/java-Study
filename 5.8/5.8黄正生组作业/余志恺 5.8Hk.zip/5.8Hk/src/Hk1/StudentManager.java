package Hk1;

import java.util.*;

public class StudentManager {
	private Scanner scanner;
	private ArrayList<Student> stu;

	public StudentManager() {
		scanner = new Scanner(System.in);
		stu = new ArrayList<Student>();

	}

	public void add() {
		int count = 0;
		while (count < 5) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("age");
			int age = scanner.nextInt();
			Student student = new Student(id, name, age);
			if (stu.contains(student)) {
				System.out.println("�ظ�id������������");
			} else {
				stu.add(student);
				System.out.println("���ӳɹ�");
			}
			count++;
		}
	}

	public void removeById() {
		System.out.println("������һ��id");
		int id = scanner.nextInt();
		Student student = new Student(id);
		if (stu.remove(student)) {
			System.out.println("ɾ���ɹ�");
		} else {
			System.out.println("ɾ��ʧ��");
		}
	}

	public void findByName() {
		
		System.out.println("������һ��name");
		String name = scanner.next();
		ArrayList<Student> a = new ArrayList<Student>();
		
		for (int i = 0; i <stu.size(); i++) {
			if (name.equals(stu.get(i).getName())) {
				a.add(stu.get(i));
			}
		}
		if (a.isEmpty()) {
			System.out.println("������");
		} else {
			System.out.println(a);
		}
	}

	public void findByName1() {
		System.out.println("������һ��name");
		String name = scanner.next();
		System.out.println("������age");
		int age = scanner.nextInt();
		ArrayList<Student> a = new ArrayList<Student>();
		for (int i = 0; i < stu.size(); i++) {
			if (name.equals(stu.get(i).getName()) && age==stu.get(i).getAge()) {
				a.add(stu.get(i));
				break;
			}
		}
		if (a.isEmpty()) {
			System.out.println("������");
		} else {
			System.out.println(a);
		}
	}

	public void findByName2() {
		System.out.println("������һ��name");
		String name = scanner.next();
		System.out.println("������age");
		int age = scanner.nextInt();
		System.out.println("������id");
		int id = scanner.nextInt();
		int index = -1;
		for (int i = 0; i < stu.size(); i++) {
			if (name.equals(stu.get(i).getName()) && age==stu.get(i).getAge()  && id==stu.get(i).getId()) {
				index =i;
				break;
			}
		}
			if (index == -1) {
				System.out.println("������");
			} else {
				stu.set(index, new Student(id,name,55));
				System.out.println(stu);
			}
		}
	public void findByName3(){
		for (int i = 0; i < stu.size(); i++) {
			if(4==stu.get(i).getAge()){
				System.out.println(stu.get(i));
			}
		}
	}
	

	public void show() {

		for (Student student : stu) {
			System.out.println(student);
		}
	}

}
