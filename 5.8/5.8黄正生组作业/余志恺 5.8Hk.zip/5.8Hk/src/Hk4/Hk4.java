package Hk4;
import java.util.*;
public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ShoppingCart shoppingcart = new ShoppingCart();
        @SuppressWarnings("resource")
        Scanner sc = new Scanner(System.in);
        System.out.println("-------------���ﳵϵͳ-------------");
        while (true) {
            System.out.println("1.������Ʒ");
            System.out.println("2.ɾ����Ʒ");
            System.out.println("3.�޸���Ʒ");
            System.out.println("4.�鿴��Ʒ");
            System.out.println("5.�˳�ϵͳ");
            System.out.println("��ѡ����Ҫ���еĲ�����");
            int num = sc.nextInt();
            switch (num) {
            case 1:
                shoppingcart.addMerchandise();
                break;
            case 2:
                shoppingcart.delMerchandise();
                break;
            case 3:
                shoppingcart.alterMerchandise();
                break;
            case 4:
                shoppingcart.showInfo();
                break;
            case 5:
                System.out.println("�˳�ϵͳ�ɹ���");
                System.exit(0);
                break;
            }
        }
    }
}
