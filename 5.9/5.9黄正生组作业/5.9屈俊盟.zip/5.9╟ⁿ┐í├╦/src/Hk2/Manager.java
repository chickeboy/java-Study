package Hk2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class Manager {
	private LinkedList<Teacher> lk;
	private Scanner scanner;
	public Manager() {
		lk = new LinkedList<>();
		scanner = new Scanner(System.in);
	}
	public void add() {
		for (int i = 0; i< 5;) {
			System.out.println("��ʦ��id");
			int id = scanner.nextInt();
			System.out.println("��ʦ��name");
			String name = scanner.next();
			System.out.println("��ʦ��sex");
			String sex = scanner.next();
			System.out.println("��ʦ��score");
			double score =scanner.nextDouble();
			Teacher teacher = new Teacher(id,name,sex,score);
			if(lk.add(teacher)) {
				i++;
			}
		}
	}
	public void u () {
		for (Teacher teacher : lk) {
			System.out.println(teacher);
		}
	}
	public void uByIterator() {
		Iterator<Teacher> iterator = lk.iterator();
		while (iterator.hasNext()) {
			Teacher teacher = (Teacher) iterator.next();
			System.out.println(teacher);
	}
	}

}
