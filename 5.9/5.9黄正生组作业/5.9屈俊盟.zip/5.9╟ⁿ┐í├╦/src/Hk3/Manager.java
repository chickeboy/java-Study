package Hk3;

import java.util.ArrayList;
import java.util.Scanner;

public class Manager {
	private ArrayList<Student> al ;
	private Scanner scanner ;
	private Util util;
	
	public Manager () {
		al= new ArrayList<>();
		scanner = new Scanner(System.in);
		util= new Util();
		
	}
	public void add() {
		int count = 0;
		while (count < 8) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("age");
			int age = scanner.nextInt();
			System.out.println("score");
			double score = scanner.nextDouble();
			Student student = new Student(id, name, age, score);
				al.add(student);
		}
	}
}