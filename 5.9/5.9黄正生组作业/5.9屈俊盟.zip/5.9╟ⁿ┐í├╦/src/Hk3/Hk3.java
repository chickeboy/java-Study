package Hk3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/*
 * 创建一个学生类，具有属性 id name age score
使用ArrayList存放8个学生对象，有2个对象的属性值相同
然后将ArrayList中的内容复制到HashSet中
通过HashSet去重，然后删除一个叫a的学员信息
再通过年龄排序输出，
删除成绩最高的，和成绩最低的，并且输出
最后在通过一种排序规则输出：id相同，比姓名，姓名相同，比年龄。输出结果 
 */

public class Hk3 {

	public static void main(String[] args) {
		ArrayList<Student> al = new ArrayList<>();
		HashSet<Student> hs = new HashSet<>(al);
		Iterator<Student> iterator = hs.iterator();
		while (iterator.hasNext()) {
			Student student = (Student) iterator.next();
			if (student.equals("a")) {
				iterator.remove();
			}
		}

	}

}
