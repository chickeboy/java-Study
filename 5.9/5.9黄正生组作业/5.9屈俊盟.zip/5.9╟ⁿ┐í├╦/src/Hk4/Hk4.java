package Hk4;
/*
 * 用TreeSet存储以下数据：
“xiaoqiang”、 “zhangsan”、“lisi”、“xiaohua”、 “ruhua”、 “wangcai”
要求按照字符串的长度进行排序后再存储（如果长度相同，则按字符串的自然顺序排序）
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class Hk4 {

	public static void main(String[] args) {
		TreeSet<String> ts = new TreeSet<>(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				int res = o2.length()-o1.length();
				if (res==0) {
					res=o1.compareTo(o2);
				}
				return res;
			}
		});
		ts.add("xiaoqiang");
		ts.add("zhangsan");
		ts.add("lisi");
		ts.add("xiaohua");
		ts.add("ruhua");
		ts.add("wangcai");
		for (Iterator iterator =ts.iterator();iterator.hasNext();) {
			String string = (String)iterator.next();
			System.out.println(string);
		}
	}
}
