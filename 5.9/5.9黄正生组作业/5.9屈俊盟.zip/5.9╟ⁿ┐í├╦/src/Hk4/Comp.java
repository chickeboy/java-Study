package Hk4;

import java.util.ArrayList;

public class Comp {
	ArrayList<String> al =new ArrayList<>();

}
