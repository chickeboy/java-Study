package Hk3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;


public class Manager {
	private ArrayList<Student> al ;
	private HashSet<Student> set;
	private Scanner scanner ;
	private Iterator<Student> iterator;
	public Manager () {
		al= new ArrayList<>();
		set = new HashSet<>();
	    iterator = set.iterator();
		scanner = new Scanner(System.in);		
	}
	
	public void add() {
		for (int i =0;i<8;i++) {
			System.out.println("id");
			int id = scanner.nextInt();
			System.out.println("name");
			String name = scanner.next();
			System.out.println("age");
			int age = scanner.nextInt();
			System.out.println("score");
			double score = scanner.nextDouble();
			Student student = new Student(id, name, age, score);
				al.add(student);
		}
	}
	public void del() {
		while (iterator.hasNext()) {
			Student student = (Student) iterator.next();
			if (student) {
				iterator.remove();
			}
		}
	}
}
