package Hk3;

public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Manager m = new Manager();
        m.add();
        m.del();
	}

}
