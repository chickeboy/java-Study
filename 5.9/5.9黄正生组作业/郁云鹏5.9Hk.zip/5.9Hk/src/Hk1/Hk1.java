package Hk1;

public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m = new Manager();
		m.add();
		m.show();
	}
}
