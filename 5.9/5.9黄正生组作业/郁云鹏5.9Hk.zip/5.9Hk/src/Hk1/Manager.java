package Hk1;

import java.util.HashSet;
import java.util.Scanner;

public class Manager {
	
	private HashSet<Animal> set;
	private Scanner scanner;
	
	public Manager() {
		set = new HashSet<>();
		scanner = new Scanner(System.in);
	}
        public  void add() {        	
    		for(int i = 0; i<5;i++) {
    			System.out.println("�����빷������");
    			String name = scanner.next();
    			System.out.println("�����빷������");
    			int age = scanner.nextInt();
    			System.out.println("�����빷����ɫ");
    			String color = scanner.next();		
    			Animal animal = new Dogs(name,age,color);
    		    set.add(animal);
    	    }
        }
        public void show() {
        	System.out.println(set);
        }
}
