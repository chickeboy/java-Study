package Hk2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class Manager {
	private LinkedList<Teacher> link;
	private Scanner scanner;
	public Manager() {
		link = new LinkedList<>();
		scanner = new Scanner(System.in);
	}
	public void add() {
		for (int i = 0; i< 5;) {
			System.out.println("��������ʦ��id");
			int id = scanner.nextInt();
			System.out.println("��������ʦ������");
			String name = scanner.next();
			System.out.println("��������ʦ���Ա�");
			String sex = scanner.next();
			System.out.println("��������ʦ�ĳɼ�");
			double score =scanner.nextDouble();
			Teacher teacher = new Teacher(id,name,sex,score);
			link.add(teacher);
	}
	}
	public void show1 () {
		for (Teacher teacher : link) {
			System.out.println(teacher);
		}
	}
	public void show2() {
		Iterator<Teacher> iterator = link.iterator();
		while (iterator.hasNext()) {
			Teacher teacher = (Teacher) iterator.next();
			System.out.println(teacher);
	}
	}
}
