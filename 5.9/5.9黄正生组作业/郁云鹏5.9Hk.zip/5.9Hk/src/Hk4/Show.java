package Hk4;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class Show {
       private TreeSet<String> tree;
       
       public Show() {
    	   tree = new TreeSet<>(new Comparator<String>() {

   			@Override
   			public int compare(String o1, String o2) {
   				int res = o1.length()-o2.length();
   				if (res==0) {
   					res=o1.compareTo(o2);
   				}
   				return res;
   			}
    	   });       
     }
     public void add() {
    	 tree.add("xiaoqiang");
 		 tree.add("zhangsan");
 		 tree.add("lisi");
 		 tree.add("xiaohua");
 		 tree.add("ruhua");
 		 tree.add("wangcai");
     }
     public void show() {
    	 for (Iterator iterator =tree.iterator();iterator.hasNext();) {
 			String string = (String)iterator.next();
 			System.out.println(string);
 		}
     }
}
