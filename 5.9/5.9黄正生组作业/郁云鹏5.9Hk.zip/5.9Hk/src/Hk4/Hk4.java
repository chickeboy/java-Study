package Hk4;

public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Show show = new Show();
        show.add();
        show.show();
	}

}
