package Hk5;

import Hk4.Show;

public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Show show = new Show();
        show.add();
        show.show();
	}

}
