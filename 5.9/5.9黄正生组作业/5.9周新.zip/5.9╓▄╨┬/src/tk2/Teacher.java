package tk2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class Teacher {
	private String id;
	private String name;
	private String sex;
	private String score;
	
	public void print1(LinkedList<Teacher>te){
		for (Teacher teacher : te) {
			System.out.println(teacher);
		}
	}
	public void print(LinkedList<Teacher>te){
		for (Iterator iterator = te.iterator(); iterator.hasNext();) {
			Teacher teacher = (Teacher) iterator.next();
			System.out.println(teacher);
		}
	}
	public LinkedList<Teacher> get(LinkedList<Teacher>te){
		Scanner scanner=new Scanner(System.in);
		int i=0;
		while(i<5){
			System.out.println("id");
			String id=scanner.next();
			System.out.println("name");
			String name=scanner.next();
			System.out.println("sex");
			String sex=scanner.next();
			System.out.println("score");
			String score=scanner.next();
			te.add(new Teacher(id,name,sex,score));
		i++;
		}
		return te;
	}
	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", sex=" + sex
				+ ", score=" + score;
	}
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Teacher(String id, String name, String sex, String score) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.score = score;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
}
