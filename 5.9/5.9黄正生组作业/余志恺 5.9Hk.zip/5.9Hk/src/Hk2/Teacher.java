package Hk2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class Teacher {
	private int id;
	private String name;
	private String sex;
	private int score;
	
	
	public Teacher() {
		super();
	}
	public Teacher(int id, String name, String sex, int score) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.score = score;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", name=" + name + ", sex=" + sex + ", score=" + score + "]";
	}
	LinkedList<Teacher>te=new LinkedList<Teacher>();
	public void show() {
		for (Teacher teacher : te) {
			System.out.println(teacher);
		}
	}
	public void print(){
		for (Iterator iterator = te.iterator(); iterator.hasNext();) {
			Teacher teacher = (Teacher) iterator.next();
			System.out.println(teacher);
		}
	}
	public LinkedList<Teacher> get(){
		Scanner scanner=new Scanner(System.in);
		int i=0;
		while(i<5){
			System.out.println("id");
			int id=scanner.nextInt();
			System.out.println("name");
			String name=scanner.next();
			System.out.println("sex");
			String sex=scanner.next();
			System.out.println("score");
			int score=scanner.nextInt();
			te.add(new Teacher(id,name,sex,score));
		i++;
		}
		return te;
	}

}
