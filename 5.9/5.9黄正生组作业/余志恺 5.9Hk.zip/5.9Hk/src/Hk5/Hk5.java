package Hk5;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<String> set = new HashSet<>();// ����_<����>_������=new_HashSet<>();
		set.add("xiaoqiang");// set.add()
		set.add("zhangsan");
		set.add("lisi");
		set.add("xiaohua");
		set.add("ruhua");
		set.add("wangcai");
		Set<String> treeSet = new TreeSet<>(new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				int a = o1.length() - o2.length();
				if (a == 0) {
					int b = o1.compareTo(o2);
					return b;
				}
				return a;
			}
		});
		for (String i : set) {
			treeSet.add(i);
		}
		for (String i : treeSet) {
			System.out.println(i);
		}
	}
}
