package hk1;

public class Dog extends Animal{

	public Dog(String name, String color) {
		super(name, color);
		// TODO Auto-generated constructor stub
	}
	
}
