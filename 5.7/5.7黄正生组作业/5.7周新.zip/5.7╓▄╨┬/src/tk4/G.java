package tk4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
public class G {
	public void dei(ArrayList<String> st){
		for (Iterator iterator = st.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			System.out.println(string);
		}
	}
	public void pai(ArrayList<String> st){
		for (int i = 0; i < st.size()-1; i++) {
			for (int j = i+1; j < st.size(); j++) {
				if(st.get(i).length()>st.get(j).length()){
					String str=st.get(i);
					st.add(i, st.get(j));
					st.add(j, str);
				}
			}
		}
	}
	public void ge(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		ArrayList<String>s=new ArrayList<String>();
		while(true){
			while(true){
				System.out.println("����������");
		String str=scanner.next();
		s.add(str);
		System.out.println("�Ƿ����y/n");
		String str1=scanner.next();
		char a=str1.charAt(0);
		if(a=='n'||a=='N'){
			break;
		}
			}
		
		for (int i = 0; i < st.size(); i++) {
			if(s.get(i).equals(st.get(i))){
				System.out.println(st.get(i));
			}
		}
		
		}}
	public ArrayList<String> re(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		while(true){
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
				st.remove(i);
				i=0;
				System.out.println("ɾ���ɹ�");
			}
		}
		System.out.println("�Ƿ����y/n");
		String str1=scanner.next();
		char a=str1.charAt(0);
		if(a=='n'||a=='N'){
			break;
		}
		}
		
		return st;
	}
	public void print1(ArrayList<String> st){
		String []str=new String[st.size()];
		for (int i = 0; i < str.length; i++) {
			str[i]=st.get(i);
		}
		for (String string : str) {
			System.out.println(string);
		}
	}
	public ArrayList<String> rem(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		while(true){
		System.out.println("����������");
		String str=scanner.next();
		if(st.remove(str)){
			System.out.println("ɾ���ɹ�");
		}else{
			System.out.println("ɾ��ʧ��");
		}
		System.out.println("�Ƿ����y/n");
		String str1=scanner.next();
		char a=str1.charAt(0);
		if(a=='n'||a=='N'){
			break;
		}
		}
		return st;
	}
	public ArrayList<String> gai(ArrayList<String> st){
		int t=look(st);
		if(t>=0){
			st.add(t, "abc");
			System.out.println("�޸ĳɹ�");
		}else{
			System.out.println("�޸�ʧ��");
		}
		
		return st;
	}
	public ArrayList<String> add1(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		while(true){
		System.out.println("����������");
		String str=scanner.next();
		st.add(str);
		System.out.println("���ӳɹ�");
		System.out.println("�Ƿ����y/n");
		String str1=scanner.next();
		char a=str1.charAt(0);
		if(a=='n'||a=='N'){
			break;
		}
		}
		return st;
	}
	public void leek(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
				System.out.println(i);
				
			}
		}
		
	}
	public ArrayList<String> remov(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
		st.remove(i);
		i=0;
		}
			
		}
		System.out.println("ɾ���ɹ�");
		return st;
	}
	public ArrayList<String> remove(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
				System.out.println(st.remove(i));
				break;
			}
	}
		return st;
	}
	public void loo(ArrayList<String> st){
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
				System.out.println(st.get(i));
				
			}
	}}
	public int look(ArrayList<String> st){
		int ton=-1;
		Scanner scanner=new Scanner(System.in);
		System.out.println("����������");
		String str=scanner.next();
		for (int i = 0; i < st.size(); i++) {
			if(str.equals(st.get(i))){
				ton=i;
				break;
			}
		}
		return ton;
	}
	public void prin(ArrayList<String> st){
		for (String string : st) {
			System.out.println(string);
		}
	}
	public void print(ArrayList<String> st){
		for (int i = 0; i < st.size(); i++) {
			System.out.println(st.get(i));
		}
	}
public void add(ArrayList<String> st){
	Scanner scanner=new Scanner(System.in);
	int i=0;
	while(i<5){
		System.out.println("������һ���ַ���");
		String str=scanner.next();
		st.add(str);
		System.out.println("¼��ɹ�");
		i++;
	}
}

void pai2(ArrayList<String> st){
	for (int i = 0; i < st.size()-1; i++) {
		for (int j = i+1; j < st.size(); j++) {
			if(st.get(i).length()>st.get(j).length()){
				String str=st.get(i);
				st.add(i, st.get(j));
				st.add(j, str);
			}else if(st.get(i).length()==st.get(j).length()){
					for (int j2 = 0; j2 < st.get(i).length(); j2++) {
				if(st.get(i).charAt(j2)>st.get(j).charAt(j2)){
					String str=st.get(i);
					st.add(i, st.get(j));
					st.add(j, str);
				}}
			}
		}
	}
}}
