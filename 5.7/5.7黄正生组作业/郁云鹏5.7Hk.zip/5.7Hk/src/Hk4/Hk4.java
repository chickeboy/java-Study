package Hk4;



public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Student.str1();
        Student.str2();
        Student.str3();
        Student.str4();
        Student.str5();
        Student.str6();
        Student.str7();
        Student.str8();
        Student.str9();
        
		}
}
