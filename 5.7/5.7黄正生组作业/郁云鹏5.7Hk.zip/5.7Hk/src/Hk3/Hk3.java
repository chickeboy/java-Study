package Hk3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> array = new ArrayList<String>();
		array.add("����");
		array.add("����");
		array.add("����");
		array.add("����");
		array.add("aaa");
		array.add("aaa");
		array.add("bbb");
		for (int i = 0; i < array.size() - 1; i++) {
			for (int j = i + 1; j < array.size(); j++) {
				if (array.get(i).equals(array.get(j))) {
					array.remove(j);
					j--;
				}
			}
		}
		Iterator it = array.iterator();
		while (it.hasNext()) {
			String str = (String) it.next();
			System.out.println(str);
		}

	}

}
