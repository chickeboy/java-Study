package Hk2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add("nihao");
		list.add("wohao");
		list.add("dajiahao");
		list.add("nihao");
		list.add(1,"tahao");
		Iterator<String> it = list.iterator();
        while(it.hasNext()) {
        	String str =it.next();
        	System.out.println(str);
        }
	}

}
