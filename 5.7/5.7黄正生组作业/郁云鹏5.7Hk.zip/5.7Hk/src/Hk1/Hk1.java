package Hk1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

i

import java.util.List;



public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);      
        List<String> myArrayList = new ArrayList<String>();
        for (int i = 0;i<5;i++) {
        	System.out.println("����������");       	
        	myArrayList.add(sc.nextLine());
        }
        Iterator<String> it = myArrayList.iterator();
        while(it.hasNext()) {
        	String name =it.next();
        	System.out.println(name);
        }
        int num =myArrayList.indexOf("zhangsan");
        if (num ==-1) {
        	System.out.println("������zhangsan");
        } else {
        	System.out.println("zhangsan�±�λ���ǣ�"+num);
        }
        if(myArrayList.remove("lisi")== true) {
        	System.out.println("ɾ���ɹ�");
        } else {
        	System.out.println("ɾ��ʧ��");
        }
        System.out.println("�޸��±�3Ϊakak");
        myArrayList.set(3,"akak");
        int num2 =myArrayList.indexOf("wanger");
        if (num2 ==-1) {
        	System.out.println("������wanger");
        } else {
        	System.out.println("����wanger");
        }
        List<String> List = new ArrayList<String>();
        List.add("wangwu");
        List.add("zhaoliu");
        List.add("erhuo");
        myArrayList.addAll(List);
        Collections.sort(myArrayList);
	}

}
