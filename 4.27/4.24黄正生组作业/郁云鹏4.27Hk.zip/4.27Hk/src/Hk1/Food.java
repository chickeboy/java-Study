package Hk1;

public class Food {
	public  final static String bone ="��ͷ";
	public  final static String fish ="��";
	private String food;
	public String getFood() {
	return food;
	}
	public void setFood(String food) {
	this.food = food;
	}
	public Food(String food) {
	this.food = food;
	}
	
       
}
