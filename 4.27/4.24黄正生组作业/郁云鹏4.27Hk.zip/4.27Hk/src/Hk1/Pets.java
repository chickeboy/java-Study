package Hk1;



public class Pets {
	public void eat(Food food) {
        
    }
        
}
