package Hk1;


public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Master master = new Master();
        master.feedDog("��ͷ");
        master.feedCat("��ͷ");
        
	}

}
