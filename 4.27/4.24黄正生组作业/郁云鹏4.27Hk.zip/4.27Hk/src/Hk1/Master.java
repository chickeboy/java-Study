package Hk1;

public class Master {
	private Pets mPet;
	private Food mFood;
	public void feedCat(String food) {
	mPet = new Cat();
	mFood = new Food(food);
	mPet.eat(mFood);
	}
	public void feedDog(String food) {
	mPet = new dog();
	mFood = new Food(food);
	mPet.eat(mFood);
	}
}
