package Hk2;

public class BlackPrinter extends Printer {
	public BlackPrinter() {
		super(PrinterFactory.BLACK);
	}

	public void print() {
		super.print();
		System.out.println("��ӡ���Ǻڰ׵�");
	}

}
