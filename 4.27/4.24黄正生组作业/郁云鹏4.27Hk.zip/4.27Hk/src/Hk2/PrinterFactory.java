package Hk2;

public class PrinterFactory {
	public static final String BLACK = "�ڰ�";
	public static final String COLOUR = "��ɫ";

	public static Printer getPrinter(String name) {
		switch (name) {
		case BLACK:
			return new BlackPrinter();
		case COLOUR:
			return new ColorPrinter();
		default:
			return null;
		}
	}

}
