package Hk2;

public class ColorPrinter extends Printer {
	public ColorPrinter() {
		super(PrinterFactory.COLOUR);
		// TODO Auto-generated constructor stub
	}

	public void print() {
		super.print();
		System.out.println("��ӡ���Ǻڰ׵�");
	}
}
