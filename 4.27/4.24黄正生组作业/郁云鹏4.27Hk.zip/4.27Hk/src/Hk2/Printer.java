package Hk2;

public class Printer {
	protected String name;

	public Printer(String name) {
		super();
		this.name = name;
	}

	public void print() {
		// TODO Auto-generated method stub System.out.println("��ʹ�õ���"+name+"��ӡ�� "); }
	}

}
