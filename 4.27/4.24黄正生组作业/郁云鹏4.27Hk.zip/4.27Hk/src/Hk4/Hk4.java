package Hk4;

public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee=new Employee("aa", 12, "aaa", "afafz");
		Employee employee1=new Employee("bb", 72, "bbb", "aghjd");
		System.out.println(employee.toString());
		System.out.println(employee1.toString());
		System.out.println("�ж���λְԱ�Ƿ�"+"\"���\"");
		employee.look(employee, employee1);

		}
	}

}
