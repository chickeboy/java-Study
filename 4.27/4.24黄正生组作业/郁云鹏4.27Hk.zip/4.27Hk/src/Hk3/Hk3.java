package Hk3;

public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test test=new Test();
		test.set();
	}
	}

