package Hk3;

public class Test {
	public void set(){
		Worker worker=new Worker(1, "abc", 11);
		Worker worker1=new Worker(2, "dfe", 22);
		worker.look(worker.getId(), worker1.getId(), worker.getName(), worker1.getName());
		
	}
}
