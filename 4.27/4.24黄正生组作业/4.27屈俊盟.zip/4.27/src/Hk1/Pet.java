package Hk1;

public class Pet {
	private String name;

	public Pet(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void eat (Food food,String str) {
		System.out.println(name+str+food.getName());
	}

}
