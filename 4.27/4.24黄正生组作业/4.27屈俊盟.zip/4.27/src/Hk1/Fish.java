package Hk1;

public class Fish extends Food{

	public Fish(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	

}
