package Hk1;

public class Bone extends Food{

	public Bone(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	

}
