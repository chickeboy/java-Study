package Hk1;
/*
 *  用Java程序完成以下场景：
有一个主人（Master类），他养了两只宠物（Pet类），
一只宠物是狗（Dog类），名字叫“旺财”，另一只宠物是猫（Cat类），名字叫“小花”，
现在有两种食物（Food类），分别是骨头（Bone）和鱼（Fish）。
主人分别给两只宠物喂食物，两只宠物挑食，
狗只吃骨头（如果主人为够吃别的食物，就显示“狗不吃某某食物”）；
猫只吃鱼（如果主人为猫吃别的食物，就显示“猫不吃某某食物”）
 */

public class Hk1 {
	
	 public static void main(String[] args){
		Master master = new Master();
		Pet pet = new Dog("旺财");
		Food food = new Food("骨头");
		master.feed(pet,food);
		pet = new Cat("小花");
		food = new Food("鱼");
		master.feed(pet,food);
		pet = new Cat("旺财");
		food = new Food("鱼");
		master.feed(pet,food);
		pet = new Cat("小花");
		food = new Food("骨头");
		master.feed(pet,food);
	}

}
