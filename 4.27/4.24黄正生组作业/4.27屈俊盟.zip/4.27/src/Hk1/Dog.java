package Hk1;

public class Dog extends Pet{

	public Dog(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
