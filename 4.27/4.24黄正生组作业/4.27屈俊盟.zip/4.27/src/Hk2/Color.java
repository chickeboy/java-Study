package Hk2;

public class Color extends Printer {

	public Color(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
}
