package Hk2;

public class Printer {
	String name;

	public Printer(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void print(Students students) {
		System.out.println(name+"�����ǣ�"+students.getName()+"		�����ǣ�"+students.getAge()+"		רҵ�ǣ�"+students.getJod());
	}

	@Override
	public String toString() {
		return "Printer [name=" + name + "]";
	}
	

}
