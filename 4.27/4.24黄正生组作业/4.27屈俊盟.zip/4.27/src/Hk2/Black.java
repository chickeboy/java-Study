package Hk2;

public class Black extends Printer{

	public Black(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	

}
