package Hk4;

public class Person {
	private String name;// ����
	private int age;// ����
	private char sex;// �Ա�

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + sex;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (age != other.age)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (sex != other.sex)
			return false;
		return true;
	}

	public Person(String name, int age, char sex) {
		this.setName(name);
		this.setAge(age);
		this.setSex(sex);
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public char getSex() {
		return sex;
	}

}

class Employee extends Person {
	private String position;// ְλ
	
	
	public Employee(String name, int age, char sex, String position) {
		super(name, age, sex);
		this.position = position;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		return true;
	}


	// ����������Ϣ
	public void getDetail() {
		System.out.println("name: " + this.getName() + " age: " + this.getAge() + " sex: " + this.getSex() + " position: "
				+ this.getPosition());

	}

}
