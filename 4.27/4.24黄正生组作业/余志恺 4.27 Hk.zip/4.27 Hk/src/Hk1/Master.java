package Hk1;

public class Master {
	private Pet mPet;
	private Food mFood;

	public void feedCat(String food) {
		mPet = new Cat(food);
		mFood = new Food(food);
		mPet.eat(mFood);
	}

	public void feedDog(String food) {
		mPet = new Dog(food);
		mFood = new Food(food);
		mPet.eat(mFood);
	}

	
}

class Dog extends Pet {
	public Dog(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void eat(Food food) {
		System.out.println("����ιС����" + food.getFood());
		if (food.getFood().matches(Food.BONE)) {
			System.out.println("С�����ڳ�" + food.getFood() + "��");
		} else {
			System.out.println("����С����ϲ����" + food.getFood() + "!");
		}
	}
}

class Cat extends Pet {
	public Cat(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void eat(Food food) {
		System.out.println("����ιСè��" + food.getFood());
		if (food.getFood().matches(Food.FISH)) {
			System.out.println("Сè���ڳ�" + food.getFood() + "��");
		} else {
			System.out.println("����Сè��ϲ����" + food.getFood() + "!");
		}
	}
}

class Food {
	public final static String BONE = ".*��.*";
	public final static String FISH = ".*��.*";
	private String food;

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public Food(String food) {
		this.food = food;
	}
}

class Pet {
	private String name;
	
	public Pet(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void eat(Food food) {

	}

}
