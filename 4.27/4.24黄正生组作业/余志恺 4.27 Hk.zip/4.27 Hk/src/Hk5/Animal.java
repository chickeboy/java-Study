package Hk5;

public class Animal {
	private String name;
	private int age;
	private String color;

	
	public Animal(String name, int age, String color) {
		super();
		this.name = name;
		this.age = age;
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void eat() {
		System.out.println(getName() + "��" );
	}

	@Override
	public String toString() {
		return "����" + name + "  �ҵ���ɫ��" + color + " �ҵ�������" + age+"��" ;
	}
	
}

class Dog extends Animal {
	public void play() {
		System.out.println(getName() + "�����");
	}

	public Dog(String name, int age, String color) {
		super(name, age, color);
		// TODO Auto-generated constructor stub
	}

}

class SmallDog extends Dog {

	public SmallDog(String name, int age, String color) {
		super(name, age, color);
		// TODO Auto-generated constructor stub
	}

	public void eat() {
		System.out.println(getName() + "��ţ��" );
	}
	
}

class BigDog extends Dog {

	public BigDog(String name, int age, String color) {
		super(name, age, color);
		// TODO Auto-generated constructor stub
	}

	public void eat() {
		System.out.println(getName() + "�����ͷ");
	}
}
