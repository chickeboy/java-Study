package tk5;

public class Pup extends Dog{

public void eat(){
	System.out.println("ţ��");
}
}
