package tk5;

public class Dog extends Animal {
public void play(Animal animal1){
	System.out.print(animal1.getName()+"�����,");
}
}
