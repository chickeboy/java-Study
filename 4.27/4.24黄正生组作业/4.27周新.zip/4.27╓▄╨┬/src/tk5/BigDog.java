package tk5;

public class BigDog extends Dog {
public void eat(){
	System.out.print("���ͷ");
}
}
