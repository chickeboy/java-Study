package tk6;

public class ElectricFan extends ElectricalAppliance{

}
