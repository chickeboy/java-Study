package tk6;

public class ElectricalAppliance {
private String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public ElectricalAppliance() {
	super();
	// TODO Auto-generated constructor stub
}

public ElectricalAppliance(String name) {
	super();
	this.name = name;
}
}
