package tk6;

public class Open extends Zhang {
	public Open(){
		
	}
	public Open(String action){
		super(action);
	}
public void set(ElectricalAppliance electricalAppliance){
	System.out.println("��"+electricalAppliance.getName());
}
}
