package tk6;

public class Kuan extends Zhang{
	public void set(ElectricalAppliance electricalAppliance){
		System.out.println("�ر�"+electricalAppliance.getName());
	}
}
