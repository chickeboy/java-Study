package tk6;

public class Television extends ElectricalAppliance{

}
