package tk6;

public class ElectricLamp extends ElectricalAppliance{

}
