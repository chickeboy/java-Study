package tk6;

public class Zhang {
	private String action;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Zhang other = (Zhang) obj;
		if (action == null) {
			if (other.action != null)
				return false;
		} else if (!action.equals(other.action))
			return false;
		return true;
	}
	public void use(Zhang zhang,ElectricalAppliance electricalAppliance){
		if(action.equals("Open")){
			Open open=new Open();
			open.set(electricalAppliance);
		}else{
			Kuan kuan=new Kuan();
			kuan.set(electricalAppliance);
		}
	}
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Zhang() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Zhang(String action) {
		super();
		this.action = action;
	}
}
