package th1;

public class Master {
public Master() {
		super();
		// TODO Auto-generated constructor stub
	}

public void feed(Pet pet,Food food){
	pet.eat(pet, food);

}}