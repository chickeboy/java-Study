package th1;

public class Fish extends Food{
	
}
