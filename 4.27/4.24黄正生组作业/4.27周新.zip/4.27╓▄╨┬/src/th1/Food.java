package th1;

public class Food {
private String name;

@Override
public String toString() {
	return "Food [name=" + name + "]";
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Food() {
	super();
	// TODO Auto-generated constructor stub
}

public Food(String name) {
	super();
	this.name = name;
}
}
