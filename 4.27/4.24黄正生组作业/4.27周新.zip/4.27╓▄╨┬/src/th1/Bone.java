package th1;

public class Bone extends Food{

}
