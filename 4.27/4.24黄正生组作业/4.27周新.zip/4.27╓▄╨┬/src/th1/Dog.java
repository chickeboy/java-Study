package th1;

public class Dog extends Pet{
private String food="Bone";

@Override
public String toString() {
	return "Dog [id=" + ", food=" + food + "]";
}
public String getFood() {
	return food;
}
public void setFood(String food) {
	this.food = food;
}
public Dog() {
	super();
	// TODO Auto-generated constructor stub
}
public Dog(String name) {
	super(name);
	// TODO Auto-generated constructor stub
}





}
