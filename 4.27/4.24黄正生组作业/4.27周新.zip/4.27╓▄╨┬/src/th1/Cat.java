package th1;

public class Cat extends Pet {
	private String food="Fish";
	
	@Override
	public String toString() {
		return "Cat [id="  + ", food=" + food + "]";
	}
	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public Cat() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
