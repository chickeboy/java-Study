package th1;

public class Pet {
private String name;

public String getName() {
	return name;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Pet other = (Pet) obj;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}
public void eat(Pet pet,Food food){
	
	if(!food.equals("Bone")&&!pet.equals("����")){
		System.out.println(pet.getName()+"��"+food.getName());
	}else if(!food.equals("Fish")&&pet.equals("����")){
		System.out.println(pet.getName()+"����"+food.getName());
		}
	else if(!food.equals("Fish")&&pet.equals("С��")){
		System.out.println(pet.getName()+"��"+food.getName());
	}else{
		System.out.println(pet.getName()+"����"+food.getName());
		}
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	return result;
}

public void setName(String name) {
	this.name = name;
}

public Pet() {
	super();
	// TODO Auto-generated constructor stub
}

public Pet(String name) {
	super();
	this.name = name;
}
}
