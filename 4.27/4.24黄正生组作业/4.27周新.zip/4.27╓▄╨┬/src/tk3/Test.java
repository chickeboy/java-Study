package tk3;

public class Test {
public void set(){
	Worker worker=new Worker(3, "ad", 23);
	Worker worker1=new Worker(6, "acd", 53);
	worker.look(worker.getId(), worker1.getId(), worker.getName(), worker1.getName());
	
}
}
