package tk2;

public class LiSi extends Personal{

}
