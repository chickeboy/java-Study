package tk2;

public class ColorPrinter extends Personal {
	public void print(Personal personal){
		Printer printer=new Printer();
		System.out.println(printer.getName()+personal.getName());
	}
}
