package tk2;

public class Zhang extends Personal {

}
