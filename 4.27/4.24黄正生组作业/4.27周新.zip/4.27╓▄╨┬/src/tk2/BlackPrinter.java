package tk2;

public class BlackPrinter extends Personal{
	public void print1(Personal personal){
		Printer printer=new Printer();
		System.out.println(printer.getName()+personal.getName());
	}
}
