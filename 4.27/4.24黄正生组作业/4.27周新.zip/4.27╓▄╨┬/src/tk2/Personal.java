package tk2;

public class Personal {
private String name;

@Override
public String toString() {
	return "Personal [name=" + name + "]";
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Personal() {
	super();
	// TODO Auto-generated constructor stub
}

public Personal(String name) {
	super();
	this.name = name;
}
}
