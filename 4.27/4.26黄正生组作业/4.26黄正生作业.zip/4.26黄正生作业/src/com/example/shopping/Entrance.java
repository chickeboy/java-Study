package com.example.shopping;
//�������
public class Entrance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		menu.mainMenu();
	}

}
