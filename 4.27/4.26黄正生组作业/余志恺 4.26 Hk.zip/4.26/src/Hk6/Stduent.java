package Hk6;
/*
 * ѧ���ࣺid,name,gender,age,score
 */
public class Stduent {
	int id;
	String name;
	char gender;
	int age;
	int score;
	public Stduent(int id, String name, char gender, int age, int score) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.score = score;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Stduent [id=" + id + ", name=" + name + ", gender=" + gender + ", age=" + age + ", score=" + score
				+ "]";
	}
	

}
