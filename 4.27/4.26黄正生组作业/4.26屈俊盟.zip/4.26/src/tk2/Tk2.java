package tk2;

public class Tk2 {
	public static void main(String[] args) {
		C c = new C(23);
		B b = new B();
		System.out.println(c.getId());
		b.change(c);
		System.out.println(c.getId());
		c = b.changeBigger(c);
		c = b.changeBigger(c);
		c = b.changeBigger(c);
		c = b.changeBigger(c);
		c = b.changeBigger(c);
		c = b.changeBigger(c);
		System.out.println(c);
	}
}

class B {
	public void change(C c) {
		c.show();
		c.setId(32);
	}

	public C changeBigger(C c) {
		c 5= new C(c.getId() + 100);
		return c;
	}
}

class C {
	private int id;

	public C(int id) {
		this.id = id;
	}

	public void show() {
		System.out.println(id);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
