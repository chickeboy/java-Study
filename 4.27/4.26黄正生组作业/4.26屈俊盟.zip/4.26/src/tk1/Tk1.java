package tk1;

public class Tk1 {
	public static void main(String[] args) {
		A a = new A();
		
	}
}

class A {
	private int a = 3;

	public String toString() {
		return a + "";
	}
}
