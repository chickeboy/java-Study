package Tk3;

public class Goods {
	private Cpu cpu;
	private Audio audio;
	private Gpu gpu;
	private String name;
	private double price;

}
