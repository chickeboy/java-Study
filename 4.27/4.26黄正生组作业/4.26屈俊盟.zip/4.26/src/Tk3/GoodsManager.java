package Tk3;

public class GoodsManager {

}
