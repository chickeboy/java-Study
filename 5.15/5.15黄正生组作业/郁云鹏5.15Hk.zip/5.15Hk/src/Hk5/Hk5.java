package Hk5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*1. ����һ��MP3�ļ�
Ҫ�󣺽�D�̸�Ŀ¼�µ�src.mp3�ļ����Ƶ�ͬһĿ¼�²�����Ϊdes.mp3
*/
public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File fi = new File("d:\\aa\\src.mp3");
		File fo = new File("d:\\aa\\des.mp3");
		FileUtil fileUtil = new FileUtil();
		fileUtil.copyB(fi, fo);
	}
}

class FileUtil {

	public void copyA(File fi, File fo) {

		FileInputStream fis = null;

		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(fi);

			fos = new FileOutputStream(fo);

			int len = -1;
			while ((len = fis.read()) != -1) {

				System.out.print((char) len);
				fos.write(len);
			}
			fis.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public void copyB(File fi, File fo) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(fi);
			fos = new FileOutputStream(fo);
			byte[] bt = new byte[1024 * 1024 * 8];

			int len = -1;
			while ((len = fis.read(bt)) != -1) {
				System.out.println(len);
				fos.write(bt, 0, len);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
