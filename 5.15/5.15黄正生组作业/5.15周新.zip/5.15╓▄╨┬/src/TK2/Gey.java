package TK2;

import java.io.File;

public class Gey {
public void get(File file){
	File[] listFiles = file.listFiles();
	for (File f : listFiles) {
		if(f.isDirectory()){
			System.out.println("�ļ��У�"+f.getAbsolutePath());
			get(f);
		}else{
			System.out.println("�ļ���"+f.getAbsolutePath());
		}
	}
}
}
