package TK1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy {
public void co(File fi,File fo){
	FileInputStream fi1=null;
	FileOutputStream fo1=null;
	try {
		fi1=new FileInputStream(fi);
		fo1=new FileOutputStream(fo);
		int len=-1;
	while((len=fi1.read())!=-1){
		fo1.write(len);
	}
	fi1.close();
	fo1.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
