package TK5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class G {
public void copy(File fi,File fo){
	FileInputStream fio=null;
	FileOutputStream foo=null;
	try {
		 fio=new FileInputStream(fi);
		 foo=new FileOutputStream(fo);
		int len=-1;
		while((len=fio.read())!=-1){
			foo.write(len);
		}
		fio.close();
		foo.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
