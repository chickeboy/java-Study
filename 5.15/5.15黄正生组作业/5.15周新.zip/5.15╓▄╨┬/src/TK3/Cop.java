package TK3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Cop {
public void cop(File fi){
	FileInputStream fio=null;
	
	TreeMap<Character, Integer>a=new TreeMap<Character, Integer>();
	try {
		fio=new FileInputStream(fi);
		int len=-1;
		while((len=fio.read())!=-1){
			char c=(char)len;
			if(a.containsKey(c)){
				a.put(c,a.get(c)+1);
			}else{
				a.put(c,1);
			}
			
		}
		fio.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	Set<Entry<Character, Integer>> entrySet = a.entrySet();
	for (Entry<Character, Integer> entry : entrySet) {
		System.out.println(entry.getKey()+"\t"+entry.getValue());
	}
}
}
