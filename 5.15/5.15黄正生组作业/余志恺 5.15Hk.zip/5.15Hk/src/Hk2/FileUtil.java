package Hk2;

import java.io.File;

public class FileUtil {
	public void show(File file) {
		File[] listFiles = file.listFiles();
		for (File f : listFiles) {
			if (f.isDirectory()) {
				System.out.println("�ļ���" + f.getAbsolutePath());
				show(f);
			} else {
				System.out.println("�ļ�" + f.getAbsolutePath());
			}
		}
	}
	
}
