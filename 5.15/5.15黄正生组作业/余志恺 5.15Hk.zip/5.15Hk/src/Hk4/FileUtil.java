package Hk4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileUtil {

	public void copy(File fi) {

		FileInputStream fis = null;

		try {
			fis = new FileInputStream(fi);

			int len = -1;

			while ((len = fis.read()) != -1) {
				System.out.print((char) len);

			}
		} catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		} catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				fis.close();

			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
}
