package Hk3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class FileUtil {
	public void show(File file) {
		FileInputStream fis=null;
		
		TreeMap<Character, Integer>a=new TreeMap<Character, Integer>();
		try {
			fis=new FileInputStream(file);
			int len=-1;
			while((len=fis.read())!=-1){
				char c=(char)len;
				if(a.containsKey(c)){
					a.put(c,a.get(c)+1);
				}else{
					a.put(c,1);
				}
				
			}
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Set<Entry<Character, Integer>> entrySet = a.entrySet();
		for (Entry<Character, Integer> entry : entrySet) {
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}
	}

	}

