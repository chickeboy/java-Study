package Hk1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * 将一个文件夹中的内容复制到其它目录中。
 * （比如:把D:\\chenhao中的内容复制一份到 e:\\zhangsan文件夹中）
(递归和通过字节流来进行复制FileInputStream和FileOutputStream)
 */

public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File fi = new File ("d:\\chenhao");
		File fo = new File("e:\\zhangsan");
		FileUtil fileUtil = new FileUtil();
		fileUtil.copyA(fi, fo);
	}

}
class FileUtil{
	public void copyA(File fi, File fo) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(fi);
			fos = new FileOutputStream(fo);
			int len = -1;
			while ((len = fis.read()) != -1) {
				fos.write(len);
			}
			fis.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}
	
	
}