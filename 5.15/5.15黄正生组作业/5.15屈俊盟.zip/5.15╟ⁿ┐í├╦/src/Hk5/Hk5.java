package Hk5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * Ҫ�󣺽�D�̸�Ŀ¼�µ�src.mp3�ļ����Ƶ�ͬһĿ¼�²�����Ϊdes.mp3
 */

public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File fi = new File("d:src.mp4");
		File fo = new File("d:des.mp4");
		FileUtil fileUtil = new FileUtil();
		fileUtil.copyA(fi, fo);
	}
}

class FileUtil {
	public void copyA(File fi, File fo) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(fi);
			fos = new FileOutputStream(fo);
			int len = -1;
			while ((len = fis.read()) != -1) {
				System.out.print((char) len);
				fos.write(len);
			}
			fis.close();
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}
}