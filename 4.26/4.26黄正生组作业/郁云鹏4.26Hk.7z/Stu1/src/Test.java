import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Menu().mainMenu();
		ArrayList<Student> arrayList = new ArrayList<Student>();
		arrayList.add(new Student(3, "ff"));
	}

}
