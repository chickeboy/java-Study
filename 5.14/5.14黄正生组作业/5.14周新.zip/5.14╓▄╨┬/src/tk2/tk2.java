package tk2;

/*1. д�����̣߳�һ���̴߳�ӡ 1~52��
 * ��һ���̴߳�ӡ��ĸA-Z��ӡ˳��Ϊ12A34B56C
 * ����Y5152Z��2������1����ĸ����
 ��ʾ��ʹ���̼߳��ͨ�š�
 */
public class tk2 {
	public static void main(String[] args) {
		String st=new String();
		new G(st).start();
		new t(st).start();
	}
}

class G extends Thread {
	private String st=new String();
	
	public G(String st) {
		super();
		this.st = st;
	}

	@Override
	public  void run() {
		synchronized (st) {
			
		
		for (int i = 1; i <= 52; i++) {
			System.out.println(i);
			if (i % 2 == 0) {
				st.notify();

				try {
					st.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}}
		}
	}
}

class t extends Thread {
	private String st=new String();
	public t(String st) {
		super();
		this.st = st;
	}
	@Override
	public  void run() {
		synchronized (st) {
			
		
		for (char i = 'A'; i <= 'Z'; i++) {
			System.out.println(i);
			if (i != 'Z') {
				st.notify();

				try {
					st.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
		}
	}
}
