package Hk2;
/*
 * 写两个线程，一个线程打印 1~52，
 * 另一个线程打印字母A-Z打印顺序为12A34B56C……Y5152Z（2个数字1个字母）。
 */

public class Hk2 {

	public static void main(String[] args) {
		Basket basket = new Basket();
		new NumThread(basket).start();
		new EnglishThread(basket).start();

	}

}
class NumThread extends Thread{
	private Basket basket;

	public NumThread(Basket basket) {
		super();
		this.basket = basket;
	}
	public void run () {
		for (int i = 1; i<53;i++) {
			basket.show(i);
		}
	}
}
class EnglishThread extends Thread{
	private Basket basket;

	public EnglishThread(Basket basket) {
		super();
		this.basket = basket;
	}
	public void run () {
		for (char c = 'A';c<'Z';c++) {
			basket.show2(c);
		}
	}
}
class Basket{
	private int index = 1;
	public synchronized void show (int i) {
		while (index%3==0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 System.out.print(" " + i);
		  index++ ;
		  notify();
	}
	public synchronized void show2(char c) {
		while (index%3!=0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.print(" "+c);
		index++;
		notify();
	}
	

}
