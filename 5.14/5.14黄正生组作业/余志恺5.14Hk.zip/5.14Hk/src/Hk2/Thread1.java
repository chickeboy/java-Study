package Hk2;

public class Thread1 extends Thread {
	private Object obj;

	public Thread1(Object obj) {
		this.obj = obj;
	}

	public void run() {
		synchronized (obj) {
			// ��ӡ1-52
			for (int i = 1; i < 53; i++) {
				System.out.println(i + " ");
				if (i % 2 == 0) {				
					obj.notifyAll();//��2����������ĸ
					try {
						obj.wait();
						Thread.sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}

	}

}
