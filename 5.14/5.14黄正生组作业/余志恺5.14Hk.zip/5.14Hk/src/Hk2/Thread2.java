package Hk2;

public class Thread2 extends Thread {
	private Object obj;

	public Thread2(Object obj) {
		this.obj = obj;
	}

	public void run() {
		synchronized (obj) {
			// ��ӡA-Z
			for (int i = 0; i < 26; i++) {
				System.out.println((char) ('A' + i) + " ");

				obj.notifyAll();
				try {

					if (i != 25) // ���һ������
					{
						obj.wait();
						Thread.sleep(300);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}

		}
	}
}
