package Hk3;

class Monkey extends Thread {
    private Peach peach;

    public Monkey(String name, Peach peach) {
        super(name);
        this.peach = peach;
    }

    public void run() {       
        while (peach.getPeachNum() != 0) {
            peach.getPeach();
        }
    }
}

class Peach {
    private int peachNum = 100;
    private int temp = 0;

    public int getPeachNum() {
        return peachNum;
    }
    //�����ӵķ���
    public synchronized void getPeach() {
        temp = peachNum;
        if (temp != 0) {
            if (temp % 2 == 0) {
                peachNum = temp / 2;
            } else {
                peachNum = temp - (temp + 1) / 2;
            }

            try {
                Thread.sleep(500);
                System.out.println(Thread.currentThread().getName() + " ������ " + (temp - peachNum) + " �����ӣ���ʣ "
                        + peachNum + " ������");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
