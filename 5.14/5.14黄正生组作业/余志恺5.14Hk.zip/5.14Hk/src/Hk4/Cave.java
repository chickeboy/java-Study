package Hk4;

class Cave implements Runnable {
	Object obj = new Object();

	public void run() {
		synchronized (obj) { 
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + " ͨ��ɽ��");
		}
		
	}
}
