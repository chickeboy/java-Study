package Hk1;

import java.util.*;

public class Producer extends Thread {
	private Basket basket;

	public Producer(Basket basket) {
		super();
		this.basket = basket;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		basket.pushApple();
	}
}

class Apple {
	private int id;

	Apple(int id) {
		this.id = id;
	}

	public String toString() {
		return "ƻ��" + id;
	}
}

class Basket {
	private LinkedList<Apple> basket = new LinkedList<Apple>();

	public synchronized void pushApple() {
		for (int i = 1; i <= 4; i++) {
			Apple apple = new Apple(i);
			push(apple);
		}
	}

	public synchronized void popApple() {
		for (int i = 1; i <= 4; i++) {
			pop();
		}
	}

	public void push(Apple apple) {

		if (basket.size() == 1) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		basket.addFirst(apple);
		System.out.println("���" + apple.toString());
		notifyAll();

	}

	private void pop() {
		if (basket.size() == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Apple apple = basket.removeFirst();
		System.out.println("�Ե�" + apple.toString());
		notifyAll();
	}

}