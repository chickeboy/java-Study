package Hk5;

public class MyThread2 extends Thread {
	private Object obj = new Object();

	public MyThread2(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (obj) {

			try {
				while (true) {
					System.out.println(Thread.currentThread().getName() + "......" + "B");
					Thread.sleep(1000);
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}

	}

}
