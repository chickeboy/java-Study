package Hk5;

public class MyThread1 extends Thread {
	private Object obj = new Object();

	public MyThread1(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (obj) {

			try {
				while (true) {
					System.out.println(Thread.currentThread().getName() + "......" + "AAA");
					Thread.sleep(5000);
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

}
