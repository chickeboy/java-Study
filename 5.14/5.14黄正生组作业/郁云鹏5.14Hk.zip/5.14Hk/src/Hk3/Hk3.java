package Hk3;

public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PichRun run = new PichRun();
		new Thread(run, "1�ź���").start();
		new Thread(run, "2�ź���").start();
		new Thread(run, "3�ź���").start();
	}

}
