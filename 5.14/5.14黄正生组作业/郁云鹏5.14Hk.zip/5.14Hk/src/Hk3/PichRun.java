package Hk3;

public class PichRun implements Runnable {
	private int pich = 100;
	private Object obj = new Object();

	public void run() {
		while (true) {
			synchronized (obj) {
				if (pich == 0) {
					break;
				}
				pich = pich / 2;
				System.out.println(Thread.currentThread().getName() + "��" + pich);
			}
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
