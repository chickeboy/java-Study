package Hk2;

public class Put extends Thread {
	private Object obj;

	public Put(Object obj) {
		this.obj = obj;
	}

	public void run() {
		synchronized (obj) {
			for (char a = 'A'; a <= 'Z'; a++) {
				System.out.print(a);
				System.out.println(" ");
				obj.notifyAll();
				try {
					obj.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
