package Hk2;

public class Get extends Thread {
	private Object obj;

	public Get(Object obj) {
		super();
		this.obj = obj;
	}

	public void run() {
		synchronized (obj) {
			for (int i = 1; i < 53; i++) {
				System.out.print(i);
				System.out.println(" ");
				if (i % 2 == 0) {
					obj.notifyAll();
					try {
						obj.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
