package Hk4;

public class Run implements Runnable {
	private int time = 1;
	private Object obj = new Object();

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			synchronized (obj) {
				if (time == 6) {
					break;
				}
				System.out.println(Thread.currentThread().getName() + time++);
			}
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}