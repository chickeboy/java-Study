package Hk5;

public class ThreadB extends Thread {
	public void run() {
		while (true) {
			System.out.println("B");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
