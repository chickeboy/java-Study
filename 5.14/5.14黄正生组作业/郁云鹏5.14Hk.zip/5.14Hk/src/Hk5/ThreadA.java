package Hk5;

public class ThreadA extends Thread {
	public void run() {
		while (true) {
			System.out.println("AAA");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
