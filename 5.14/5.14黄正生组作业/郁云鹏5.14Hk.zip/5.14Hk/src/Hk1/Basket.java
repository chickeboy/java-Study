package Hk1;

import java.util.LinkedList;

public class Basket {
	private LinkedList<Apple> lk = new LinkedList<Apple>();
	private Object object = new Object();

	public synchronized void put(Apple apple) {
		if (lk.size() == 1) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		notify();
		System.out.println("�������з�" + apple );
		lk.add(apple);
	}

	public synchronized void get() {
		if (lk.size() == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("��" + lk.removeLast() );
		notify();
	}

	public void putAll() {
		for (int i = 0; i < 4; i++) {
			Apple apple = new Apple(i);
			put(apple);
		}
	}

	public void getAll() {
		for (int i = 0; i < 4; i++) {
			get();
		}
	}
}
