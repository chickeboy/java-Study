package Hk1;

public class PutThread extends Thread {
	private Basket basket;

	public PutThread(Basket basket) {
		super();
		this.basket = basket;
	}

	@Override
	public void run() {
		basket.putAll();
	}
}
