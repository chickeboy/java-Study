package Hk1;

public class GetThread extends Thread {
	private Basket basket;

	public GetThread(Basket basket) {
		super();
		this.basket = basket;
	}

	@Override
	public void run() {
		basket.getAll();
	}
}
