//��дһ����������һ���ַ���ȫ����ɴ�д��2�ַ�����
import java.util.*;
public class Hk4{
		public static void main(String[] args){
		String a = "absuSDaa";
	getmethod1(a);
	a=getmethod2(a);
		System.out.println("����2"+a);
	}
	public static void getmethod1(String a){
		String newstr2 = a.toUpperCase();
		System.out.println("����1"+newstr2);
	}
	public static String getmethod2(String a) {
		if ("".equals (a))
        {
            return "";
        }
		String tmp = a.substring (0, 1);
        if (tmp.matches ("^[a-z]$"))
        {
            char c = (char) ( (int)tmp.charAt (0) - 32 );
		return c + getmethod2 (a.substring (1));
		}else if (tmp.matches ("^[A-Z]$"))
		{
			char c = (char) ( (int)tmp.charAt (0) );
			return c + getmethod2 (a.substring (1));
		}
		return tmp;
	}
}