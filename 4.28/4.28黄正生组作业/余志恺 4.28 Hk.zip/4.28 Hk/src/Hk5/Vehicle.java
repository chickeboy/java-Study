package Hk5;

public abstract class Vehicle {
	public abstract void run();
}

class Tractor extends Vehicle {
	public void run() {
		System.out.println("��������");
	}
}

class Truck extends Vehicle {
	public void run() {
		System.out.println("������");
	}
}

class Saloon extends Vehicle {
	public void run() {
		System.out.println("�γ���");
	}
}