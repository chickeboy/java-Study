package Hk4;

public abstract class Army {
	private String name;
	
	public Army(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void title() {
		System.out.println(getName()+"�Ķ���");
	}
	public void start() {
		System.out.println("��ʼ����");
	}

	public void end() {
		System.out.println("����");
	}

	abstract void attack();

	public void action() {
		title();
		start();
		attack();
		end();
		System.out.println("********");
	}
}

class Saber extends Army {
	public Saber(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void attack() {
		
		System.out.println(getName()+":Excalibur");
	}
}

class Lancer extends Army {
	public Lancer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void attack() {
		System.out.println(getName()+":Gale Bolg");
	}
}

class Archer extends Army {
	public Archer(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public void attack() {
		System.out.println(getName()+":Unlimited Blade Works");
	}
}
class Master extends Army{
	private Army[] army=new Army[3]; 
    public Master(String name)
    {
        super(name);
        army[0]=new Saber("Saber"); //��̬;
        army[1]=new Lancer("Lancer");
        army[2]=new Archer("Archer");
       
    }
    public void attack()
    {
        System.out.println(getName()+"��Ϸ");
    }
    public void callAllToAttack() 
    {
        for(int i=0;i<army.length;i++)
        {
              army[i].action();
        }
    }
    public void callSomeToAttack(Army s)
    {
        s.action();
    }
    public Army[] getArmy() //����һ������;
    {
        return army;
    }

}