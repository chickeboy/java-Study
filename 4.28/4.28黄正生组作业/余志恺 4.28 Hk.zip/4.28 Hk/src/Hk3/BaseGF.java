package Hk3;

public abstract class BaseGF {
	public abstract void eat();
    public void shopping() {
          System.out.println("ÿ��ȥ����");
    }

}

class GFFactory {
    public static BaseGF createGF(String gfType) {  	
          switch (gfType) {
                case "�Ĵ�":
                      return new SiChuanGF();
                case "�㶫":
                      return new GuangDongGF();
                default:
                case "ɽ��":
                      return new ShanDongGF();
          }
    }
}
class SiChuanGF extends BaseGF {
    @Override
    public void eat() {
          System.out.println("���Ĵ�ʳ��");
    }
}
class GuangDongGF extends BaseGF {
    @Override
    public void eat() {
          System.out.println("�Թ㶫ʳ��");
    }
}
class ShanDongGF extends BaseGF {
    @Override
    public void eat() {
          System.out.println("��ɽ��ʳ��");
    }
}