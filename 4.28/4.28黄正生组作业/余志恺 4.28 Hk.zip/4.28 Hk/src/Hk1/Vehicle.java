package Hk1;

public abstract class Vehicle {
	
		abstract void drive();
}

class Bike extends Vehicle {
	
	public void drive() {
		System.out.println("�����г�");
	}
}

class Car extends Vehicle {

	public void drive() {
		System.out.println("����");
	}
}

class Train extends Vehicle {
	
	public void drive() {
		System.out.println("����");
	}
}