package tk2;

public abstract class Hummer {
private String name;



 public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Hummer() {
	
	// TODO Auto-generated constructor stub
}
public Hummer(String name) {
	
	this.name = name;
}
abstract void start();	
 abstract void stop();	
abstract void alarm();	
abstract void engineBoom();
abstract void run();
}
