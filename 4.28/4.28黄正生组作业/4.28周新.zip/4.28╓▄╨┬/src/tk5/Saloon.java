package tk5;

public class Saloon extends Car{
public Saloon() {
		
	}
	public Saloon(String name) {
		super(name);
	}
	@Override
	void run() {
		System.out.println("��΢�۶���ͬ��");
		
	}

}
