package tk5;

public abstract class Car {
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Car() {
		
	}
	public Car(String name) {
		this.name = name;
	}
	abstract void run();
}
