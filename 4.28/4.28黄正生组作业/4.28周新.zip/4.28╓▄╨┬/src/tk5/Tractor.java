package tk5;

public class Tractor extends Car{
public Tractor() {
		
	}
	public Tractor(String name) {
		super(name);
	}
	@Override
	void run() {
		System.out.println("��������");
		
	}

}
