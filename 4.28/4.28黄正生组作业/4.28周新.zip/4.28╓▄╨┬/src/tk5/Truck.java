package tk5;

public class Truck extends Car{
public Truck() {
		
	}
	public Truck(String name) {
		super(name);
	}
	@Override
	void run() {
		System.out.println("�ٶȷ������");
		
	}

}
