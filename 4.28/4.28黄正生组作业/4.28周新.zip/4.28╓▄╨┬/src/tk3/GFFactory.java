package tk3;

public class GFFactory {
public BaseGF GFFactory(String gfType){
	J1 j1=new J1();
	J2 j2=new J2();
	J3 j3=new J3();
	if(gfType==null){
		System.out.println("û��Ů����");
	}else{
		switch(gfType){
		case "�Ĵ�":
			j1.eat();
			break;
		case "�㶫":
			j2.eat();
			break;
		case "ɽ��":
			j3.eat();
			break;
		default :
			System.out.println("û������Ů����"+(char)2);
			break;	
		}
	}
	return null;
		
	}
}
