package tk3;

public class J3 extends BaseGF{
public J3() {
		
	}
	public J3(String where) {
		super(where);
		
	}
	@Override
	void eat() {
		System.out.println("�Գ���");
		
	}

}
