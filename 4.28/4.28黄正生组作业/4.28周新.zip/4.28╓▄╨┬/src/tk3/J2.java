package tk3;

public class J2 extends BaseGF{
public J2() {
		
	}
	public J2(String where) {
		super(where);
		
	}
	@Override
	void eat() {
		System.out.println("����ֹ��");
		
	}

}
