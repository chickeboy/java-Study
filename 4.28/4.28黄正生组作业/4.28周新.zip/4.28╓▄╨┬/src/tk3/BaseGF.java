package tk3;

public abstract class BaseGF {
private String where;
public String getWhere() {
	return where;
}
public void setWhere(String where) {
	this.where = where;
}
public BaseGF() {
	
}
public BaseGF(String where) {

	this.where = where;
}
abstract void eat();
public void shopping(){
	System.out.println("��������������");
}
}
