package tk3;

public class J1 extends BaseGF{
	public J1() {
		
	}
	public J1(String where) {
		super(where);
		
	}
	@Override
	void eat() {
		System.out.println("��������");
		
	}

}
