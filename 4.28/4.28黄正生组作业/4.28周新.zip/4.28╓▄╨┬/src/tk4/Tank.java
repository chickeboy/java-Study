package tk4;

public class Tank extends Arms{
	public Tank() {
		super();
	}

	public Tank(String name) {
		super(name);

	}
	@Override
	void attack() {
		System.out.println("̩��ѹ��");
	
	}
}
