package tk4;

public class AutomotiveSoldier extends Arms{
	public AutomotiveSoldier() {
		super();
	}

	public AutomotiveSoldier(String name) {
		super(name);

	}
	@Override
	void attack() {
		System.out.println("ս����̤");
		
	}

}
