package tk4;

public abstract class Arms {
private String name;
abstract void attack();
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Arms() {
	
}

public Arms(String name) {
	
	this.name = name;
}}
