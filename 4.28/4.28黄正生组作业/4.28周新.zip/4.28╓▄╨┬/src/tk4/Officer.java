package tk4;

import java.util.Scanner;

public class Officer extends Arms{
	

	public Officer(String name) {
		super(name);

	}
public void use(){
	Scanner scanner=new Scanner(System.in);
	Tank tank=new Tank();
	AutomotiveSoldier automotiveSoldier=new AutomotiveSoldier();
	Infantry infantry=new Infantry();
	while(true){
		System.out.println("���������");
		String str=scanner.next();
	switch(str){
	case "����":
		infantry.attack();
		break;
	case "������":
		automotiveSoldier.attack();
		break;
	case "̹��":
		tank.attack();
		break;
	case "����":
		System.out.println("��ǹ"+"����");
		break;
		default :
			System.out.println("û���������");
			break;
	}
	System.out.println("�Ƿ����y/n");
	String str1=scanner.next();
	char a=str1.charAt(0);
	if(a=='n'||a=='N'){
		break;
	}
	}
}

	public Officer() {
	super();
	// TODO Auto-generated constructor stub
}

	@Override
	void attack() {
		System.out.println("�õ���");
		
	}

}
