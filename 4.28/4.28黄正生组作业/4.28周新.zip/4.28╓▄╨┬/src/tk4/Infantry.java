package tk4;

public class Infantry extends Arms{
	public Infantry() {
		super();
	}

	public Infantry(String name) {
		super(name);

	}
	@Override
	void attack() {
		System.out.println("��ͷײ");
		
	}

}
