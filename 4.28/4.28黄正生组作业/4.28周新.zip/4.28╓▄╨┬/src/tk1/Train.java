package tk1;

public class Train extends Vehicle{
public  Train() {
		
	}
public Train(String name) {
	super(name);
}
	@Override
	public void drive() {
		System.out.println("����");
		
	}

}
