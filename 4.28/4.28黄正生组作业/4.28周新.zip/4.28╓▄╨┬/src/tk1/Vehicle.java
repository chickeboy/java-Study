package tk1;

 abstract class Vehicle {
private String name;

 abstract void drive();
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Vehicle() {
	
	// TODO Auto-generated constructor stub
}

public Vehicle(String name) {
	
	this.name = name;
}
}
