package tk1;

public class Bike extends Vehicle{
	
	public  Bike() {
		
	}
public  Bike(String name) {
	super(name);
}
	@Override
	public void drive() {
		System.out.println("����");
		
	}

}
