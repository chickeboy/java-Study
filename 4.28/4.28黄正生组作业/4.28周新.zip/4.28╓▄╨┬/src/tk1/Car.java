package tk1;

public class Car extends Vehicle{
public  Car() {
		
	}
public  Car(String name) {
	super(name);
}
	@Override
	public void drive() {
		System.out.println("����");
		
	}

}
