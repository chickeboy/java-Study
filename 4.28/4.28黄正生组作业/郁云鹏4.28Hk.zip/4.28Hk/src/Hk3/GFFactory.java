package Hk3;

import Hk3.BaseGF;
import Hk3.Sichuan;
import Hk3.Guangdong;
import Hk3.Shandong;

public class GFFactory {
	public BaseGF createGF(String gfType) {
		BaseGF gf = null;
		switch (gfType) {
		case "�Ĵ�":
			gf = new Sichuan(gfType,"��ɫ");
			break;
		case "�㶫":
			gf = new Guangdong(gfType,"��ɫ");
			break;
		case "ɽ��":
			gf = new Shandong(gfType,"��ɫ");
			break;
		default:
			break;
		}
		return gf;
	}
} 
