package Hk3;

public class Sichuan extends BaseGF{
	public Sichuan(String gfType, String colour) {
		super(gfType, colour);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("һ��������Ŷ�����");
	}
}
