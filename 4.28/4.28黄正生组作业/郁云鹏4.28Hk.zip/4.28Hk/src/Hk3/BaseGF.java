package Hk3;

public abstract class BaseGF {
	private String gfType;
	private String colour;

	public BaseGF(String gfType, String colour) {
		super();
		this.gfType = gfType;
		this.colour = colour;
	}
	public abstract void eat();
	
	public void shopping() {
		System.out.println("Ȼ��ȥ���");
	}
	public String getGfType() {
		return gfType;
	}
	public void setGfType(String gfType) {
		this.gfType = gfType;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	
	
}
