package Hk3;

import Hk3.BaseGF;
import Hk3.GFFactory;

public class Master {
	public GFFactory factory;

	public Master(GFFactory factory) {
		super();
		this.factory = factory;
	}

	public BaseGF createGF(String gfType) {
		return factory.createGF(gfType);
	}
}
