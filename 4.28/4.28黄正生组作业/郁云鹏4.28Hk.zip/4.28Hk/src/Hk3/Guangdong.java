package Hk3;

public class Guangdong extends BaseGF{
	public Guangdong(String gfType, String colour) {
		super(gfType, colour);
		// TODO Auto-generated constructor stub
	}
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("һ�����ͧ���ࡣ");
	}
}
