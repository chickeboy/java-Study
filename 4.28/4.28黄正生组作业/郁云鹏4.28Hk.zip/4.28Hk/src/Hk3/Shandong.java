package Hk3;

public class Shandong extends BaseGF{
	public Shandong(String gfType, String colour) {
		super(gfType, colour);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("һ������ൺ�����");
	}
}
