package Hk4;

public class Hk4 {
	public static void main(String[] args) {
		War war=new War();
		JuGuan juGuan=new JuGuan("����");
		Army a1=new Cavalry("���");
		Army a2=new Infantry("����");
		Army a3=new Mauler("�ܱ�");
		War.addArmy(a1);
		War.addArmy(a2);
		War.addArmy(a3);
		juGuan.SendSignal();
		War.display();
}
}
