package Hk4;

public class Infantry extends Army{
	public Infantry(String bingType) {
		super(bingType);
		}
		@Override
		public void atract() {
		System.out.println(this.getType()+"�ó��˵�");
		}
}
