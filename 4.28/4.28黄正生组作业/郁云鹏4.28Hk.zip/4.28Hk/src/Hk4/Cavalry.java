package Hk4;

public class Cavalry extends Army{
	public Cavalry(String bingType) {
		super(bingType);
		}
		@Override
		public void atract() {
		System.out.println(this.getType()+"�������");
		}
}
