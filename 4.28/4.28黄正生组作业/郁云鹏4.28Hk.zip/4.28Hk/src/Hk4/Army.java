package Hk4;

public abstract class Army {
	private String bingType;
	public Army(String bingType)
	{
	this.bingType=bingType;
	}
	public String getType()
	{
	return bingType;
	}
	public abstract void atract();
	
	public void SendSignal() {
		// TODO Auto-generated method stub
		
	}
	
}
