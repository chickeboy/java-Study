package Hk4;

public class Mauler extends Army{
	public Mauler(String bingType) {
		super(bingType);
		}
		@Override
		public void atract() {
		System.out.println(this.getType()+"�ڳ��˷�������");
		}
		
}
