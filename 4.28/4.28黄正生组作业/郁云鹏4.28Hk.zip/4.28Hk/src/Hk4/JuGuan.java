package Hk4;

public class JuGuan extends Army{
	public JuGuan(String bingType) {
		super(bingType);
		}
		@Override
		public void SendSignal() {
		System.out.println("���ٷ�������ź�");
		}
		@Override
		public void atract() {
		}
}
