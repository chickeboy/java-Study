package Hk4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class War {
	static List<Army> list = new ArrayList<Army>();

	public static void addArmy(Army army) {
		list.add(army);
	}

	public static void display() {
		Iterator<Army> iterator = list.iterator();
		while (iterator.hasNext()) {
			iterator.next().atract();
		}
	}
}