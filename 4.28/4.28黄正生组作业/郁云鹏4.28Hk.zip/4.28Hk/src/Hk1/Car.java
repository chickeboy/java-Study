package Hk1;

public class Car extends Vehicle{
	
	public void drive() {
  	  System.out.println("쭳�");
    }
	
}
