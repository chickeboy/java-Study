package Hk1;

abstract public class Vehicle {
	
  
	public abstract void drive();


}
