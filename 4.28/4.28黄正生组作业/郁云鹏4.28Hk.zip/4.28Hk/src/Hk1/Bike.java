package Hk1;

public class Bike extends Vehicle{
	  
      public void drive() {
    	  System.out.println("�����г�");
      }

	
}
