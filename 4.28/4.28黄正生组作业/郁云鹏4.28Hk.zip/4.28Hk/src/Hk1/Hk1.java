package Hk1;

public class Hk1 {
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Vehicle [] vehicle= {new Bike(),new Car(),new Train()};
		  for (int i =0;i<vehicle.length;i++) {
			  vehicle[i].drive();
		  }
		  
	}
    
}
