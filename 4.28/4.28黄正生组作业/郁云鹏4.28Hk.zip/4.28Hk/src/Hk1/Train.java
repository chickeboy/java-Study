package Hk1;

public class Train extends Vehicle{
	
	public void drive() {
  	  System.out.println("����");
    }
	
	
}
