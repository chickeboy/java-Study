package Hk2;

public class Hk2 {
public static void main(String[] args) {
		
		Hummer h1 = new H1();		
		h1.run(); 
		Hummer h2 = new H2();
		h2.run();
}
}
