package Hk2;

public class H2 extends Hummer{
	public void alarm() {
		System.out.println("H2����.");
	}
 
	public void engineBoom() {
		System.out.println("H2����������.");
	}
 	
	public void start() {
		System.out.println("H2����.");
	}
 	
	public void stop() {
		System.out.println("H2ͣ��.");
	}
 	
	public void run() {
 		
		this.start();
 		
		this.engineBoom();
 		
		this.alarm();
 		
		this.stop();
	}
	
}
