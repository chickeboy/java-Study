package Hk5;

public abstract class Car {
        public abstract void run();
}
