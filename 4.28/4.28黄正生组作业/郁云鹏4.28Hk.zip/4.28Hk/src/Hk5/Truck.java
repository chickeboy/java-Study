package Hk5;

public class Truck extends Car{
	public void run() {
   	 System.out.println("С�γ��~");
    }
}
