package Hk5;

public class Hk5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Car c1= new Saloon();
        Car c2= new Tractor();
        Car c3= new Truck();
        c1.run();
        c2.run();
        c3.run();
	}

}
