package Hk5;

public class Saloon extends Car{

	@Override
	public void run() {
		System.out.println("����");
		
	}

}
