package Hk5;

public class Tractor extends Car{

	@Override
	public void run() {
		System.out.println("����");
		
	}

}
