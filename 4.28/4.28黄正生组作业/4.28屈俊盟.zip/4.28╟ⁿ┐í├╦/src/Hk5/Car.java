package Hk5;

abstract public class Car {
	public abstract void run();
	

}
