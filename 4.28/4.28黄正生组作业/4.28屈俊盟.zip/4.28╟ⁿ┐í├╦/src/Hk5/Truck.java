package Hk5;

public class Truck extends Car{

	@Override
	public void run() {
		System.out.println("����");
		
	}

}
