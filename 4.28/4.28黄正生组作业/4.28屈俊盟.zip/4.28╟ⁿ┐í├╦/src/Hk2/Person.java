package Hk2;

public class Person {
	public HanmaFactory factory;

	public Person(HanmaFactory factory) {
		super();
		this.factory = factory;
	}

	public Hanma create(String name) {
		return factory.createHuman(name);

}
}
