package Hk2;

public class HanmaFactory {
	public Hanma createHuman(String name) {
		Hanma hanma = null;
		switch (name) {
		case "H1":
			hanma = new H1();
			break;
		case "H2":
			hanma = new H2();
			break;
		default:
			break;
		}
		return hanma;
}
}
