package Hk3;

public class GF2 extends BaseGF{

	@Override
	public void eat() {
		System.out.println("ʲô���ҳ�");
	}
	

}
