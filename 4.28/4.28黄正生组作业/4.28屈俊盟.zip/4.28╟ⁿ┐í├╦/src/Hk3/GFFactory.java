package Hk3;

public class GFFactory {
	public static BaseGF createGF(String gfType) {
		BaseGF basegf =null;
		switch (gfType) {
		case "�Ĵ�":
			basegf = new GF1();
			break;
		case "�㶫":
			basegf = new GF2();
			break;
		case "ɽ��":
			basegf= new GF3();
			break;
		default:
			break;
		}
		return basegf;
		
	}

}
