package Hk3;

public class Master {
	public GFFactory factory;

	public Master(GFFactory factory) {
		super();
		this.factory = factory;
	}

	public BaseGF create(String gfType) {
		return GFFactory.createGF(gfType);

}
}
