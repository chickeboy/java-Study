package Hk3;

public abstract class BaseGF {
	public abstract void eat();
	public void shopping () {
		System.out.println("���Ա�");
	}
}
