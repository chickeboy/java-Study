package Hk3;

public class GF1 extends BaseGF{

	@Override
	public void eat() {
		System.out.println("�ر��ܳ���");
	}
	

}
