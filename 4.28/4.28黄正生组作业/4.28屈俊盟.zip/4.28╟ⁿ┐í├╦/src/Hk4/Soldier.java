package Hk4;

abstract public class Soldier {
	public abstract void fight();
	

}
