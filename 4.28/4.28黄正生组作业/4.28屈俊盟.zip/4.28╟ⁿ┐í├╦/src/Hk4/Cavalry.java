package Hk4;

public class Cavalry extends Soldier{

	@Override
	public void fight() {
		System.out.println("��");
		
	}
}
