package Hk4;

public class Infantry extends Soldier{

	@Override
	public void fight() {
		System.out.println("��");
		
	}
	

}
