package Hk4;

public class Artillery extends Soldier{

	@Override
	public void fight() {
		System.out.println("��");
		
	}

}
