package Hk4;

public class Leader extends Soldier{
	

	@Override
	public void fight() {
		System.out.println("��");
		
	}
	public void order(String name) {
		System.out.println("����"+name+"����");
		
	}

}
