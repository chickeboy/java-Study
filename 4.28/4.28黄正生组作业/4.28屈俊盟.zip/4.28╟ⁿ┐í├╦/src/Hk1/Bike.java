package Hk1;

public class Bike extends Vehicle{

	public Bike(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drive() {
		System.out.println("�ﳵ");
	}
	

}
