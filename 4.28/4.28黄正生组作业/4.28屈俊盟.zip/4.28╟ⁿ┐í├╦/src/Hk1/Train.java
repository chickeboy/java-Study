package Hk1;

public class Train extends Vehicle{

	public Train(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void drive() {
		System.out.println("����");
		
	}
	

}
