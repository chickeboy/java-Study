//8.键盘输入年月，判断这一月一共有几天
import java.util.Scanner;
public class hk8{
    public static void main (String [] args){
	Scanner scanner = new Scanner (System.in);
	System.out.println("请输入一个年份");
	int i = scanner.nextInt();
	if((i%4==0&&i%100!==0)||i%400==0){
		System.out.println("请输入一个月份");
		int a = scanner.nextInt();
		
		
	