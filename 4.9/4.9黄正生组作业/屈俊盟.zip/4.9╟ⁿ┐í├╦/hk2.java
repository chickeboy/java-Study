//2.已知方程ax2+bx+c=0的系数值（设b2-4ac>0），求方程的根。
//提示：方程ax2+bx+c=0(a≠0)称为一元二次方程
//一元二次方程的基本解法有开平方法、配方法、公式法和国式分解法．
//对于方程ax2+bx+c=0(a≠0)，△=b2-4ac称为该方程的根的判别式．当△＞0时，方程有两个不相等的实数根，即
//当△=0时，方程有两个相等的实数根，即
//当△＜0时，方程无实数根．
import java.util.Scanner;
public static void main (String [] args){
	Scanner scanner = new Scanner (System.in);
	System.out.println("请输入一个数值");
	
	