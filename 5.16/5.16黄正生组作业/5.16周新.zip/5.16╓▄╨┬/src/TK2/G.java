package TK2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class G {
private File file;
private FileReader fr;
private FileWriter fw;
private BufferedReader br;
private BufferedWriter bw;
public void print(){
	fr=null;
	br=null;
	File file=new File("a.txt");
	try {
		fr=new FileReader(file);
		br=new BufferedReader(fr);
		String len=null;
		while((len=br.readLine())!=null){
			System.out.println(len);	
		}
		br.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public void input(){
	Scanner scanner=new Scanner(System.in);
	while(true){
		System.out.println("������");
		String str=scanner.next();
		if(str.equals("exit")){
			break;
		}
		bw=null;
		fw=null;
		File f=new File("a.txt");
		try {
			fw=new FileWriter(f,true);
			bw=new BufferedWriter(fw);
			bw.write(str);
			bw.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bw.flush();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
}
