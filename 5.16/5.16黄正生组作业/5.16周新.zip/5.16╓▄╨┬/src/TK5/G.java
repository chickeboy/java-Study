package TK5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class G {
	private FileReader fr;
	private FileWriter fw;
	private BufferedReader br;
	private BufferedWriter bw;
	public void cop(File f,File fi){
		fr=null;
		br=null;
		fw=null;
		bw=null;
		try {
			fr=new FileReader(f);
			br=new BufferedReader(fr);
			fw=new FileWriter(fi);
			bw=new BufferedWriter(fw);
			String len=null;
			while((len=br.readLine())!=null){
				bw.write(len);
				bw.newLine();
			}
			bw.flush();
			fr.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void input(File f){
		Scanner scanner=new Scanner(System.in);
		if(f.isFile()){
			try {
				fw=new FileWriter(f);
				bw=new BufferedWriter(fw);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while(true){
			System.out.println("������");
			String str=scanner.next();
			try {
				bw.write(str);
				bw.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("�Ƿ����y/n");
			String a=scanner.next();
			if(a.equals("n")||a.equals("N")){
				break;
			}
		}
			try {
				bw.flush();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
	}
	public void get(File f) {
		if (!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.println("�Ѵ���");
		}
	}
}
