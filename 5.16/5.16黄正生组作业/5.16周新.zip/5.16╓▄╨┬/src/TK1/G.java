package TK1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class G {
public void look(){
	FileInputStream fis = null;
	FileOutputStream fos = null;
		try {
			Properties prop = new Properties();
			File file = new File("count����");
			if (!file.exists()) {
				file.createNewFile();
			}
			 fis = new FileInputStream(file);
			prop.load(fis);
			int count = Integer.parseInt(prop.getProperty("count", "0"));
			count++;
			if (count > 5) {
				throw new RuntimeException("��ʧ��");		
			} else {
				 fos = new FileOutputStream(file);
				prop.setProperty("count", String.valueOf(count));
				prop.store(fos, "open count");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (RuntimeException e) {
		e.getMessage();
		} finally {
			if (fos != null) {
				try {
					fos.close();
					fos = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
					fis = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}


