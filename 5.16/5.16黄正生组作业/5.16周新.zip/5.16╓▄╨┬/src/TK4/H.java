package TK4;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.IOException;

public class H {
	public void get(File f,File fi){
		BufferedWriter bw=null;
		FileWriter fw=null;
		
		if(!f.exists()){
			System.out.println("��������");
		}else{
			File[] listFiles = f.listFiles();
			for (File file : listFiles) {
			if(file.isDirectory()){
				get(file,fi);
			}else{
				if(file.getName().endsWith(".java")){
				System.out.println(file);
				try {
					fw=new FileWriter(fi,true);
					bw=new BufferedWriter(fw);
					bw.write(String.valueOf(file.getCanonicalPath()));
					bw.newLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		try {
			bw.flush();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}}}
	}}
}
