package TK3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*.���ı��ļ��д���쳲��������У�
 * 1,1,2,3,5,8,13,21,34,55����ȡ��12����
 */
public class TK3 {
public static void main(String[] args) {
	int []a={1,1,2,3,5,8,13,21,34,55,89,144,133,277};
	File f=new File("쳲���.txt");
	if(!f.exists()){
	try {
		f.createNewFile();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}else{
		FileWriter fw=null;
		BufferedWriter bw=null;
		File file=new File("쳲���.txt");
		try {
			fw=new FileWriter(file);
			bw=new BufferedWriter(fw);
			for (int i : a) {
				bw.write(String.valueOf(i)+":");
			}
			bw.flush();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileReader fr=null;
		BufferedReader br=null;
		try {
			fr=new FileReader(file);
			br=new BufferedReader(fr);
			String len=null;
			while((len=br.readLine())!=null){
				String []str=len.split(":");
				int t=Integer.parseInt(str[11]);
				System.out.println(t);
				
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
