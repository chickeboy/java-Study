package TK7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class G {
	public ArrayList<Student> st = new ArrayList<Student>();
	private FileReader fr;
	private FileWriter fw;
	private BufferedReader br;
	private BufferedWriter bw;

	public void read(File f) {
		fr = null;
		br = null;
		if (f.isFile()) {
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				String len = null;
				while ((len = br.readLine()) != null) {
					String[] str = len.split(":");
					String name = str[0];
					int gerden = Integer.parseInt(str[1]);
					String accounts = str[2];
					double accrual = Double.parseDouble(str[3]);
					Student s = new Student(name, gerden, accounts, accrual);
					if (st.contains(s)) {
						int t = st.indexOf(s);
						accrual = st.get(t).getAccrual() + s.getAccrual();
						s = new Student(name, gerden, accounts, accrual);
						st.set(t, s);
					} else {
						st.add(s);
					}

				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		Collections.sort(st);
		for (Iterator iterator = st.iterator(); iterator.hasNext();) {
			Student student = (Student) iterator.next();
			System.out.println(student);
		}
	}

	public void werit(String[] s, File f) {
		fw = null;
		bw = null;
		if (s == null) {
			System.out.println("����Ϊnull");
		} else if (!f.isFile()) {
			System.out.println("�봫���ļ�");
		} else {
			try {
				fw = new FileWriter(f);
				bw = new BufferedWriter(fw);
				for (String str : s) {
					bw.write(str);
					bw.newLine();
				}
				bw.flush();
				bw.close();
				fw.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
