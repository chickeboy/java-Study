package TK7;

public class Student implements Comparable<Student>{
private String name;
private int gerden;
private String accounts;
private double accrual;
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((accounts == null) ? 0 : accounts.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Student other = (Student) obj;
	if (accounts == null) {
		if (other.accounts != null)
			return false;
	} else if (!accounts.equals(other.accounts))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}
@Override
public String toString() {
	return "name=" + name + ", \tgerden=" + gerden + ", \taccounts="
			+ accounts + ", \taccrual=" + accrual;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(String name, int gerden, String accounts, double accrual) {
	super();
	this.name = name;
	this.gerden = gerden;
	this.accounts = accounts;
	this.accrual = accrual;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getGerden() {
	return gerden;
}
public void setGerden(int gerden) {
	this.gerden = gerden;
}
public String getAccounts() {
	return accounts;
}
public void setAccounts(String accounts) {
	this.accounts = accounts;
}
public double getAccrual() {
	return accrual;
}
public void setAccrual(double accrual) {
	this.accrual = accrual;
}
@Override
public int compareTo(Student o) {
	// TODO Auto-generated method stub
	return -Double.compare(getAccrual(), o.getAccrual());
}
}
