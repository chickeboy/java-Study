package TK6;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class G {
	private FileReader fr;
	private FileWriter fw;
	private BufferedReader br;
	private BufferedWriter bw;
	public synchronized void cop(File f,File fi){
		fr=null;
		br=null;
		fw=null;
		bw=null;
		try {
			fr=new FileReader(f);
			br=new BufferedReader(fr);
			fw=new FileWriter(fi,true);
			bw=new BufferedWriter(fw);
			String len=null;
			while((len=br.readLine())!=null){
				bw.write(len);
				bw.newLine();
			}
			bw.flush();
			fr.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
