package TK6;

import java.io.File;

public class Can extends Thread{
private File f;
public Can() {
	super();
	// TODO Auto-generated constructor stub
}
private File fi;
	public Can(File f, File fi) {
	super();
	this.f = f;
	this.fi = fi;
}
	@Override
	public void run() {
		new G().cop(f, fi);
		
	}

}
