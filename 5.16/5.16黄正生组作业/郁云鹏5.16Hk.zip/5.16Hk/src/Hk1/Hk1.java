package Hk1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Hk1 {
	public static void main(String[] args) {
		File file = new File("e://b.txt");
		U u = new U(file);
		int i = u.read();
		u.write(i);
		if (i > 5) {
			System.err.println("��������");

		} else {
			System.out.println("�Ѿ���" + i + "��");
		}
	}
}

class U {
	private File file;
	private FileInputStream fis;
	private FileOutputStream fos;

	public U(File file) {
		super();
		this.file = file;
	}

	public void write(int i) {
		try {
			fos = new FileOutputStream(file);
			fos.write(i + 1);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public int read() {
		int i = 1;

		try {
			fis = new FileInputStream(file);
			int len = -1;
			while ((len = fis.read()) != -1) {
				i = len;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

}