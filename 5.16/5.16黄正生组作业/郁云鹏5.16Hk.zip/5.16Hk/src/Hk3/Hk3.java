package Hk3;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Hk3 {
	public static void main(String[] args) throws IOException{
		 try {
		        File file = new File("E:\\a.txt");
		        InputStream inputStream = new FileInputStream(file);
		        BufferedInputStream bis = new BufferedInputStream(inputStream);
		        ByteArrayOutputStream bos = new ByteArrayOutputStream();
		        int date = -1;
		        while ((date = bis.read()) != -1) {
		            bos.write(date);
		        }
		        byte[] bytes = bos.toByteArray();
		        String content = new String(bytes);
		        System.out.println("content:" + content);
		        String[] split = content.split(",");
		        System.out.println("������Ҫ��ȡ��λ�ã�");
		        @SuppressWarnings("resource")
		        Scanner scanner = new Scanner(System.in);
		        int index = scanner.nextInt();
		        System.out.println("���еĵ�" + index + "λ�õ���Ϊ��" + split[index - 1]);
		        bis.close();
		        inputStream.close();
		        bos.close();
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
	}
}