package Hk4;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Hk4 {
	public static void main(String[] args) {
		Util u = new Util();
		File f1 = new File("E:\\aa");
		File f2 = new File("e:\\b.txt");
		u.open(f1, f2);
	}
}
class Util{
	private FileWriter fw ;
	private BufferedWriter bw;
	public void open(File f1,File f2) {
	try {
		fw = new FileWriter(f2,true);
		bw = new BufferedWriter(fw);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	File [] listFiles = f1.listFiles();
	for (File f : listFiles) {
		if (f.isFile()) {
			if (f.getName().endsWith(".java")) {
				String lien = f.getAbsolutePath();
				try {
					bw.write(lien);
					bw.newLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {
			open(f,f2);
		}
	}
	}
	
}

