package Hk4;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Util {

	/*
	 * public static void GetPclLib(File file) { File[] listFiles =
	 * file.listFiles(); for (File lf : listFiles) { if (lf.isFile()) { if
	 * (lf.getName().endsWith(".java")) { System.out.println(lf); } } else { if
	 * (lf.isDirectory()) { GetPclLib(lf); } } } }
	 */

	public void fileToList(File dir, List<File> list) {
		File[] files = dir.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				fileToList(file, list);
				
			} else {// ������������ӽ��뼯����
				if (file.getName().endsWith(".java")) {
					list.add(file);
					System.out.println(file);
				}
			}
		}
	}

	public void writeToFile(List<File> list, String javaListFile) throws IOException {
		BufferedWriter bw = null;
		try {

			bw = new BufferedWriter(new FileWriter(javaListFile));
			for (File f : list) {
				String path = f.getAbsolutePath();// ��ȡ�ļ��ľ���·��
				bw.write(path);
				bw.newLine();
				bw.flush();

			}
		} catch (Exception e) {
			throw e;

		} finally {
			try {
				if (bw != null) {
					bw.close();
				}
			} catch (Exception e2) {
				throw e2;
			}
		}
	}
}
