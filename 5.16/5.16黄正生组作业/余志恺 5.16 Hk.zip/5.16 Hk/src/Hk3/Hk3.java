package Hk3;
import java.io.*;
import java.util.*;
/*
 * 1.���ı��ļ��д���쳲��������У�1,1,2,3,5,8,13,21,34,55����ȡ��12����
 */
public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 try {
		        File file = new File("f://abc.txt");
		        InputStream inputStream = new FileInputStream(file);
		        BufferedInputStream bis = new BufferedInputStream(inputStream);
		        ByteArrayOutputStream bos = new ByteArrayOutputStream();
		        int date = -1;
		        while ((date = bis.read()) != -1) {
		            bos.write(date);
		        }
		        byte[] bytes = bos.toByteArray();
		        String content = new String(bytes);
		        System.out.println("�ĵ�:" + content);
		        String[] split = content.split(",");
		        System.out.println("������Ҫ��ȡ��λ�ã�");		      
		        Scanner scanner = new Scanner(System.in);
		        int index = scanner.nextInt();
		        System.out.println("쳲��������еĵ�" + index + "λ�õ���Ϊ��" + split[index - 1]);
		        bis.close();
		        inputStream.close();
		        bos.close();
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}
}