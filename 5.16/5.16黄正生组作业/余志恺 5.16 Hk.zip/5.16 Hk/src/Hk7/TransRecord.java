package Hk7;

public class TransRecord implements Comparable<TransRecord>{	
    private String customerName;//�ͻ���   
    private int sex;//�Ա�
    private String accountNumber;//�˺�
    private Double amount;//������
    
	public TransRecord() {
		super();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransRecord other = (TransRecord) obj;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		return true;
	}
	public TransRecord(String customerName, int sex, String accountNumber, Double amount) {
		super();
		this.customerName = customerName;
		this.sex = sex;
		this.accountNumber = accountNumber;
		this.amount = amount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TransRecord [customerName=" + customerName + ", sex=" + sex + ", accountNumber=" + accountNumber
				+ ", amount=" + amount + "]";
	}
	@Override
	public int compareTo(TransRecord o) {
		// TODO Auto-generated method stub
		return Double.compare(getAmount(), o.getAmount());
	}
    
}
    