package Hk7;

import java.util.*;
import java.io.*;

public class Util {
	public ArrayList<TransRecord> st = new ArrayList<TransRecord>();
	private FileReader fr;
	private FileWriter fw;
	private BufferedReader br;
	private BufferedWriter bw;

	public void read(File f) {
		FileReader fr = null;
		BufferedReader br = null;
		if (f.isFile()) {
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				String len = null;
				while ((len = br.readLine()) != null) {
					String[] str = len.split("\\|");
					String customerName = str[0];
					int sex = Integer.parseInt(str[1]);
					String accountNumber = str[2];
					double amount = Double.parseDouble(str[3]);
					TransRecord s = new TransRecord(customerName, sex, accountNumber, amount);
					if (st.contains(s)) {
						int t = st.indexOf(s);
						amount = st.get(t).getAmount() + s.getAmount();
						s = new TransRecord(customerName, sex, accountNumber, amount);
						st.set(t, s);
					} else {
						st.add(s);
					}

				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		Collections.sort(st);
		for (Iterator iterator = st.iterator(); iterator.hasNext();) {
			TransRecord student = (TransRecord) iterator.next();
			System.out.println(student);
		}
	}

	public void write(String[] s, File f) {
		fw = null;
		bw = null;
		if (s == null) {
			System.out.println("����Ϊ��");
		} else if (!f.isFile()) {
			System.out.println("û���ļ����봫���ļ�");
		} else {
			try {
				fw = new FileWriter(f);
				bw = new BufferedWriter(fw);
				for (String str : s) {
					bw.write(str);
					bw.newLine();
				}
				bw.flush();
				bw.close();
				fw.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
