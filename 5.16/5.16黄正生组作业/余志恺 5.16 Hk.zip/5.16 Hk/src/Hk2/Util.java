package Hk2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Util {

	public  void show() throws IOException {

		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		
		File file = new File("a.txt");
		
		FileOutputStream fos = new FileOutputStream(file, true);
		OutputStreamWriter osw = new OutputStreamWriter(fos, "GBK");
		System.out.println(osw.getEncoding());
		BufferedWriter bw = new BufferedWriter(osw);
		while (true) {
			System.out.println("请输入");
			try {
				String line = br.readLine();
				if (line.equals("exit")) {
					break;
				}
				bw.write(line);
				bw.newLine();
				bw.flush();
			} catch (IOException e) {
				e.printStackTrace();
				// TODO: handle exception
			}
		}
	}

}
