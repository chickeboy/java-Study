package Hk5;

import java.util.Scanner;
import java.io.*;
public class Util {
	private FileReader fr;
	private FileWriter fw;
	private BufferedReader br;
	private BufferedWriter bw;
	public void copy(File f1,File f2){
		FileReader fr=null;
		BufferedReader br=null;
		FileWriter fw=null;
		BufferedWriter bw=null;
		try {
			fr=new FileReader(f1);
			br=new BufferedReader(fr);
			fw=new FileWriter(f2);
			bw=new BufferedWriter(fw);
			String len=null;
			while((len=br.readLine())!=null){
				bw.write(len);
				bw.newLine();
			}
			bw.flush();
			fr.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void inputMessage(File f){
		Scanner scanner=new Scanner(System.in);
		if(f.isFile()){
			try {
				fw=new FileWriter(f);
				bw=new BufferedWriter(fw);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while(true){
			System.out.println("������");
			String str=scanner.next();
			try {
				bw.write(str);
				bw.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("�Ƿ����y/n");
			String a=scanner.next();
			if(a.equals("n")||a.equals("N")){
				break;
			}
		}
			try {
				bw.flush();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
	}
	public void OutMessage(File f) {
		if (!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.println("�Ѵ���");
		}
	}
	/*
	 * public void copya(File f1, File f3) throws IOException { f3.mkdirs(); File[]
	 * files = f1.listFiles(); for (File file : files) { if (file.isFile()) {
	 * FileInputStream fis = new FileInputStream(file); FileOutputStream fos = new
	 * FileOutputStream(f3.getAbsoluteFile()+"\\"+file.getName()); int len; byte[]
	 * by = new byte[1024]; while ((len = fis.read(by)) != -1) { fos.write(by, 0,
	 * len); } fis.close(); fos.close(); } else { copy(file, new
	 * File(f3.getAbsoluteFile()+"\\"+file.getName()));
	 * 
	 * } } }
	 */
}
