package Hk1;

import java.io.*;
import java.util.Properties;

public class Util {
	public void check() {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			Properties prop = new Properties();
			File file = new File("count����");
			if (!file.exists()) {
				file.createNewFile();
			}
			fis = new FileInputStream(file);
			prop.load(fis);
			int count = Integer.parseInt(prop.getProperty("count", "0"));
			count++;
			if (count > 5) {
				throw new RuntimeException("��ʧ��");		
			} else {
				fos = new FileOutputStream(file);
				prop.setProperty("count", String.valueOf(count));
				prop.store(fos, "open count");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fos != null) {
				try {
					fos.close();
					fos = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
					fis = null;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}