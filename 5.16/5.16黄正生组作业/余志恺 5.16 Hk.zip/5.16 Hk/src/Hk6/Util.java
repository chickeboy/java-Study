package Hk6;

import java.io.*;

public class Util {
	public  void writeFile() throws IOException {
		BufferedReader buffered1 = new BufferedReader(new FileReader("f://test//a//1.txt"));
		BufferedReader buffered2 = new BufferedReader(new FileReader("f://test//a//2.txt"));
		BufferedReader buffered3 = new BufferedReader(new FileReader("f://test//a//3.txt"));
		StringBuilder builder = new StringBuilder();
		String str = null;
		while((str =buffered1.readLine()) != null){
		builder.append(str).append("\r\n");
		}
		str = null;
		while((str =buffered2.readLine()) != null){
		builder.append(str).append("\r\n");
		}
		str = null;
		while((str =buffered3.readLine()) != null){
		builder.append(str).append("\r\n");
		}
		System.err.println(builder.toString());
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("F:\\test\\a\\aaa.txt")));
		bufferedWriter.write(builder.toString());
		bufferedWriter.flush();

		bufferedWriter.close();
		buffered1.close();
		buffered2.close();
		buffered3.close();
}
}