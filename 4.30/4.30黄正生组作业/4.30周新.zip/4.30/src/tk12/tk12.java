package tk12;
/*12.
ʹ�ò���ģʽ����Ʒ�ʽ��ʵ�ֶ����������
�ṩ���־����ʵʩ���ԣ�
ð�����򷨺�ѡ������ 
 */
public class tk12 {
public static void main(String[] agrs) {
    int []a={9,5,12,4};
	G g=new G();
	T t=new Xuan();
	g.useT(t,a);
	for (int i : a) {
		System.out.println(i);
	}
	 T t1=new Mao();
	g.useT(t1, a);
	for (int i : a) {
		System.out.println(i);
	}
}
}
class G{
	public void useT(T t,int[] a){
		t.t(a);
	}
}
class Xuan implements T{
	@Override
	public void t(int[] a){
		for (int i = 0; i < a.length-1; i++) {
			int min=i;
			for (int j = i+1; j < a.length; j++) {
				if(a[min]>a[j]){
					min=j;
				}
			}
			if(min!=i){
				int ton=a[min];
				a[min]=a[i];
				a[i]=ton;
			}
		}
	}
}
class Mao implements T{
	@Override
	public void t(int[] a){
		for (int i = 0; i < a.length-1; i++) {
			for (int j = i+1; j < a.length-i-1; j++) {
				if(a[i]>a[j]){
					int ton=a[i];
					a[i]=a[j];
					a[j]=ton;
				}
			}
		}
	}
}

interface T{
	void t(int[] a);
}
