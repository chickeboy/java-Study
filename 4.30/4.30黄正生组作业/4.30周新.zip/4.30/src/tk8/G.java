package tk8;

public class G {
public void useU(U u,Student[]stu){
	u.u(stu);
}

	interface U{
		void u(Student[]stu);
	}
}


