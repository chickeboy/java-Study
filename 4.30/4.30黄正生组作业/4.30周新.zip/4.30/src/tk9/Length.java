package tk9;

import tk9.G.U;

class Length implements U{
	@Override
	public void u(String[]a){
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length-1-i; j++) {
			if(a[i].length()>a[j].length()){
				String ton=a[i];
				a[i]=a[j];
				a[j]=ton;
			}
		}
	}}}
