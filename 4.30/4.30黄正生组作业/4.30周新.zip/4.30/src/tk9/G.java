package tk9;

public class G {
public void makeU(U u,String[]a){
	u.u(a);
}
interface U{
	void u(String[]a);
}
}
