package tk9;

import tk9.G.U;

class Can implements U{
	@Override
	public void u(String[]a){
		for (int i = 0; i < a.length; i++) {
			for (int j = i+1; j < a.length-1-i; j++) {
			if(a[i].length()>a[j].length()){
				String ton=a[i];
				a[i]=a[j];
				a[j]=ton;
			}else if(a[i].length()==a[j].length()){
				for (int j2 = 0; j2 < a[i].length(); j2++) {
					if(a[i].charAt(j2)>a[j].charAt(j2)){
						String ton=a[i];
						a[i]=a[j];
						a[j]=ton;
					}
				}
		
		
	

}
}}}}
