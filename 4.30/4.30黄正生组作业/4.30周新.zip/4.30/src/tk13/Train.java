package tk13;
import tk13.G.T;
public class Train implements T{
	@Override
	public void t(double weight,double space){
		double sum=-1;
		if(space<=900){
			 sum=weight*space*250;
		}else{
			sum=weight*space*300;
		}
			System.out.println("���˷�Ϊ"+sum);
		
	}
}
