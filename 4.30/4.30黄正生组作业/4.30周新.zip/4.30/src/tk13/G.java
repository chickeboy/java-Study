package tk13;

public class G {
public void T(T t,double weight,double space){
	t.t(weight,space);
}
interface T{
	void t(double weight,double space);
}
}
