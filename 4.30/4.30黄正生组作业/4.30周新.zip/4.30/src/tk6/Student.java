package tk6;

public class Student implements Comparable<Student> {
private int number;
private String name;
private double score;
@Override
public String toString() {
	return "number=" + number + ",\tname=" + name + ",\tscore=" + score;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getScore() {
	return score;
}
public void setScore(double score) {
	this.score = score;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public Student(int number, String name, double score) {
	super();
	this.number = number;
	this.name = name;
	this.score = score;
}
@Override
public int compareTo(Student o){
	
	return number-o.getNumber();
}
}
