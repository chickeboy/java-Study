package tk6;

public class G {
public void copmer(Student[] stus){
	T t=new Score();
	t.t(stus);
}
interface T{
	void t(Student[] stus);
}
public class Score implements T{
	@Override
	public void t(Student[] stus){
		for (int i = 0; i < stus.length; i++) {
			for (int j = i+1; j < stus.length-1-i; j++) {
				if(stus[i].getScore()>stus[j].getScore()){
					Student ton=stus[i];
					stus[i]=stus[j];
					stus[j]=ton;
				}
			}
		}
	}
}
}
