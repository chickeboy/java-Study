package tk1;

import java.util.Comparator;

public  class Person implements Comparable<Person> {
private int id;
private String name;
private int scer;

@Override
public String toString() {
	return "id=" + id + ", \tname=" + name + ", \tscer=" + scer ;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getScer() {
	return scer;
}
public void setScer(int scer) {
	this.scer = scer;
}
public Person() {
	super();
	// TODO Auto-generated constructor stub
}
public Person(int id, String name, int scer) {
	super();
	this.id = id;
	this.name = name;
	this.scer = scer;
}

@Override
public int compareTo(Person o) {
	if(name.length()>o.getName().length()){
		return 1;
	}else if(name.length()<o.getName().length()){
		return -1;
	}
	
	return name.compareTo(o.getName());
	}

}
