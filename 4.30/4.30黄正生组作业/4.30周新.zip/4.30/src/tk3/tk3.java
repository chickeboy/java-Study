package tk3;

import java.util.Scanner;

/*3.
��һ��ѧ���࣬��������id  name  age  score
Ҫ�󴴽�һ������ѭ������ѧ������
ѧ����������������� ����ID����
�ٴ���2���Ƚ��� �ֱ���� ���� ���� �ɼ�����
��󴴽�һ���Ƚ���,�ȽϹ����ȱ����֣�
����������䣬������ͬ�ȳɼ���
�ֱ���������
 */
public class tk3 {
public static void main(String[] args) {
	Student[] stu=new Student[5];
	Scanner scanner=new Scanner(System.in);
	for (int i = 0; i < stu.length; i++) {
		System.out.println("name");
		String name=scanner.next();
		System.out.println("age");
		int age=scanner.nextInt();
		System.out.println("score");
		int score=scanner.nextInt();
		System.out.println("id");
		int id=scanner.nextInt();
		Student student=new Student(id, name, age, score);
		stu[i]=student;
	}
	G g=new G();
	B b=new Comper();
	g.makeB(b, stu);
	for (Student student : stu) {
		System.out.println(student.toString());
	}
	System.out.println("================================");
	B b1=new Compertor();
	g.makeB(b1, stu);
	for (Student student : stu) {
		System.out.println(student.toString());
	}
}
}
class Student{
	private String name;
	private int age;
	private int score;
	private int id;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + score;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (age != other.age)
			return false;
		if (score != other.score)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "id=" + id + ",\t name=" + name + ",\tage=" + age
				+ ",\tscore=" + score;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id, String name, int age, int score) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.score = score;
	}
}
class G{
	public void makeB(B b,Student[]stu){
		b.b(stu);
	} 
}
class Comper implements B{
	@Override
	public void b(Student[]stu){
		for (int i = 0; i < stu.length-1; i++) {
			for (int j = i+1; j < stu.length; j++) {
				if(stu[i].getId()>stu[j].getId()){
					Student ton=stu[i];
					stu[i]=stu[j];
					stu[j]=ton;
				}
			}
		}
	}
}
class Compertor implements B{
	@Override
	public void b(Student[]stu){
		for (int i = 0; i < stu.length-1; i++) {
			for (int j = i+1; j < stu.length; j++) {
				if(stu[i].equals(stu[j])){
					Student ton=stu[i];
					stu[i]=stu[j];
					stu[j]=ton;
				}
			}
		}
	}
	}

interface B{
	void b(Student[]stu);
}