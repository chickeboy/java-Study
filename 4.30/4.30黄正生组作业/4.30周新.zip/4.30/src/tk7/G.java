package tk7;

public class G {
	public void makeP(P p){
		p.p();
	}
interface P{
	void p();
}



}
