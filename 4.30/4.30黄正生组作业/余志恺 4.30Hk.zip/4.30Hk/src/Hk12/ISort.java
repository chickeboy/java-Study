package Hk12;

interface ISort {
	public void sort(int[] array);
}

class Context {
	private ISort isort = null;

	public Context(ISort isort) {
		this.isort = isort;
	}

	public void sort(int[] array) {
		isort.sort(array);
	}

	public void printArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}
}

class BubbleSort implements ISort {
	public void sort(int[] array) {
		System.out.println("ð��");
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = 0; j < array.length - i - 1; j++) {
				if (array[j] > array[j + 1]) {
					int temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
				}
			}
		}
	}
}

class SelectSort implements ISort {
	public void sort(int[] array) {
		System.out.println("ѡ��");
		int min = 0;
		for (int i = 0; i < array.length; i++) {
			min = i;
			for (int j = i + 1; j < array.length; j++) {
				if (array[min] > array[j]) {
					min = j;
				}
			}
			if (i != min) {
				int temp = array[i];
				array[i] = array[min];
				array[min] = temp;
			}
		}
	}
}