package Hk3;

import java.util.Comparator;

class Stu implements Comparable<Stu> {
	private int id;
	private String name;
	private int age;
	private double score;

	public Stu(int id, String name, int age, double score) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.score = score;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Stu [id=" + id + ", name=" + name + ", age=" + age + ", score=" + score + "]";
	}

	@Override
	public int compareTo(Stu o) {
		if (name.compareTo(o.getName()) == 0) {
			if (age == o.getAge()) {
				return Double.compare(score, o.getScore());
			}
			return age - o.getAge();

		}
		return name.compareTo(o.getName());
	}
}
	class ComareByAge implements Comparator<Integer> {

		@Override
		public int compare(Integer o1, Integer o2) {
			// TODO Auto-generated method stub
			return o2 - o1;
		}
	}

	class CompareByScore implements Comparator<Integer> {

		@Override
		public int compare(Integer o1, Integer o2) {
			// TODO Auto-generated method stub
			return o2 - o1;
		}

	}

