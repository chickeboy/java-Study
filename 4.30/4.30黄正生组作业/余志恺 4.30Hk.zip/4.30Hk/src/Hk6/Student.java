package Hk6;

class Student implements Comparable<Student> {
	private int number;// ѧ��
	private String name;// ����
	private double score;// �ɼ�

	public Student(int number, String name, double score) {
		this.name = name;
		this.number = number;
		this.score = score;
	}

	public int compareTo(Student other) {
		if (this.score < other.score)
			return -1;
		else if (this.score > other.score)
			return 1;
		return 0;

	}

	public int getNumber() {
		return number;
	}

	public String getName() {
		return name;
	}

	public double getScore() {
		return score;
	}

}
