package Hk5;

public class Goods {
	private String name;

	public Goods(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}

class Elec extends Goods implements IChargeable {
	public void elec() {
		System.out.println(getName()+"���");		
	}
	public Elec(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}

class Clothing extends Goods implements IWearable {
	public void wear() {
		System.out.println(getName() + "����");
	}

	public Clothing(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
}

class GoogleGlass extends Elec implements IChargeable, IWearable {
	public void elec() {
		System.out.println(getName() + "���");
	}

	public void wear() {
		System.out.println(getName() + "����");
	}

	public GoogleGlass(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}

interface IChargeable {
	void elec();
}

interface IWearable {
	void wear();
}