package Hk10;

public interface Method {

	public void operate();
}

class BackDoor implements Method {
	public void operate() {
		System.out.println("���ǹ��ϰ�æ(������)");
	}
}

class GivenGreenLight implements Method {
	public void operate() {
		System.out.println("�����̫����(�߿�)");
	}
}

class BlockEnemy implements Method {
	public void operate() {
		System.out.println("����˶Ϻ�");
	}
}

class Context {

	private Method method;

	public Context(Method method) {
		this.method = method;
	}

	public void operate() {
		this.method.operate();
	}
}