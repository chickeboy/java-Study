package Hk4;

class Context {

	private Calculater calculater;

	public Context(Calculater calculater) {
		this.calculater = calculater;
	}

	public double doStrategy(double num1, double num2) {
		return calculater.doOperation(num1, num2);
	}
}

	interface Calculater {

		// ���Ծ��巽��
		double doOperation(double num1, double num2);
	}

	class add implements Calculater {
		public double doOperation(double num1, double num2) {
			return num1 + num2;
		}
	}

	class minus implements Calculater {
		public double doOperation(double num1, double num2) {
			return num1 - num2;
		}
	}

	class mul implements Calculater {
		public double doOperation(double num1, double num2) {
			return num1 * num2;
		}
	}

class divide implements Calculater {
	public double doOperation(double num1, double num2) {
		return num1 / num2;
	}
}