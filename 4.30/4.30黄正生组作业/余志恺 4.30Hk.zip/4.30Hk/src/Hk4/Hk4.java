package Hk4;

public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Context context = new Context(new add());
		Context context1 = new Context(new minus());
		Context context2 = new Context(new mul());
		Context context3 = new Context(new divide());
		double add = context.doStrategy(10, 20);
		double minus = context1.doStrategy(10, 20);
		double mul = context2.doStrategy(10, 20);
		double divide = context3.doStrategy(10, 20);
		System.out.println("�ӷ������" + add);
		System.out.println("���������" + minus);
		System.out.println("�˷������" + mul);
		System.out.println("���������" + divide);

	}

}
