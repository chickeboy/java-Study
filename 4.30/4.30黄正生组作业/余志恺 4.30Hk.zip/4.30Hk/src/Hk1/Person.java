package Hk1;
import java.util.*;
class Person implements Comparable<Person> {
	private double score;
	private String name;

	public Person(String name,double score) {
		super();
		this.name = name;
		this.score = score;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public String toString() {
		return "Person [score=" + score + ", name=" + name + "]";
	}

	@Override
	public int compareTo(Person o) {
		if(name.length()>o.getName().length()){
			return 1;
		}else if(name.length()<o.getName().length()){
			return -1;
		}
		return name.compareTo(o.getName());
	
	}
}
class Score implements Comparator<Person> {
	@Override
	public int compare(Person o1, Person o2) {
		if (o1.getScore() > o2.getScore()) {
			return -1;
		} else if (o1.getScore() < o2.getScore()) {
			return 1;
		} else {
			return 0;
		}
		
	}

}

