package Hk9;

public class Two {
	public void makeIUse(IUse use, String[] a) {
		use.use(a);
	}
}

interface IUse {
	void use(String[] a);
}

class Com implements IUse {
	@Override
	public void use(String[] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length - 1 - i; j++) {
				if (a[i].length() > a[j].length()) {
					String temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				} else if (a[i].length() == a[j].length()) {
					for (int k = 0; k < a[i].length(); k++) {

						if (a[i].charAt(k) > a[j].charAt(k)) {
							String temp1 = a[i];
							a[i] = a[j];
							a[j] = temp1;
						}
					}

				}
			}
		}
	}
}

class Length implements IUse {
	@Override
	public void use(String[] a) {
		for (int i = 0; i < a.length-1; i++) {
			for (int j = i+1; j < a.length - 1 - i; j++) {
				if (a[i].length() > a[j].length()) {
					String temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
		}
	}
}
