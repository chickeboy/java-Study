package Hk15;

public class Hk15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d = new Dog();
		Cat c = new Cat();
		makeCry(d);
		makeCry(c);
	}

	public static void makeCry(CanCry cry) {
		cry.cry();
	}

}
