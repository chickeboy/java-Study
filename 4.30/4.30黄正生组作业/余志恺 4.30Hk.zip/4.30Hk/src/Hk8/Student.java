package Hk8;

import java.util.*;

class Student implements Comparable<Student> {

	private int id;
	private String name;
	private double score;

	public Student(int id, String name, double score) {
		super();
		this.id = id;
		this.name = name;
		this.score = score;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Stu [id=" + id + ", name=" + name + ", score=" + score + "]";
	}

	@Override
	public int compareTo(Student o) {

		if (name.compareTo(o.getName()) == 0) {
			if (id == o.getId()) {
				return Double.compare(score, o.getScore());
			}
			return id - o.getId();
		}
		return name.compareTo(o.getName());
	}
}
	
	
	class CompareByName implements Comparator<Student> {

		@Override
		public int compare(Student o1, Student o2) {
			return o1.getName().compareTo(o2.getName());
		}

	}
class ComareById implements Comparator<Integer> {

	@Override
	public int compare(Integer o1, Integer o2) {
		// TODO Auto-generated method stub
		return o2 - o1;
	}
	}
class CompareByScore implements Comparator<Integer>{

		@Override
		public int compare(Integer o1, Integer o2) {
			// TODO Auto-generated method stub
			return o2 - o1;
		}
		
	}
	






