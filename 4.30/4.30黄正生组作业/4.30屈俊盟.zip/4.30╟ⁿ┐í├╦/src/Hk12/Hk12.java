package Hk12;

public class Hk12 {
	public static void main(String[] agrs) {
	    int []array={6,3,9,4,8};
		G g=new G();
		T t=new Xuan();
		g.useT(t,array);
		for (int i : array) {
			System.out.println(i);
		}
		System.out.println("*********************");
		 T t1=new Mao();
		g.useT(t1, array);
		for (int i : array) {
			System.out.println(i);
		}
	}
	}
	class G{
		public void useT(T t,int[] array){
			t.t(array);
		}
	}
	class Xuan implements T{
		@Override
		public void t(int[] array){
			for (int i = 0; i < array.length-1; i++) {
				int min=i;
				for (int j = i+1; j < array.length; j++) {
					if(array[min]>array[j]){
						min=j;
					}
				}
				if(min!=i){
					int ton=array[min];
					array[min]=array[i];
					array[i]=ton;
				}
			}
		}
	}
	class Mao implements T{
		@Override
		public void t(int[] array){
			for (int i = 0; i < array.length-1; i++) {
				for (int j = i+1; j < array.length-i-1; j++) {
					if(array[i]>array[j]){
						int ton=array[i];
						array[i]=array[j];
						array[j]=ton;
					}
				}
			}
		}
	}

	interface T{
		void t(int[] a);
	}


