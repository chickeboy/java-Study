package Hk8;

import Hk8.Comp.A;

public class Score implements A{
	@Override
	public void a(Student[]stu){
		for (int i = 0; i < stu.length; i++) {
			for (int j = i+1; j < stu.length-1-i; j++) {
				if(stu[i].getScore()>stu[j].getScore()){
					Student ton=stu[i];
					stu[i]=stu[j];
					stu[j]=stu[i];
				}
			}
		}
	}
}
