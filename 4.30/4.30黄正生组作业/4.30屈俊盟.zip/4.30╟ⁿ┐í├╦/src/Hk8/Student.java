package Hk8;

public class Student implements Comparable<Student>{
	private int id;
	private String name;
	private double score;
	@Override
	public String toString() {
		return "id=" + id + ",\tname=" + name + ",\tscore=" + score;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id, String name, double score) {
		super();
		this.id = id;
		this.name = name;
		this.score = score;
	} 
	@Override
	public int compareTo(Student o) {
		if(getId()==o.getId()){
			if (name.compareTo(o.getName()) == 0) {
				return Double.compare(score, o.getScore());
			}
			return name.compareTo(o.getName());
		}	
		
		return getId()-o.getId();
	}

}
