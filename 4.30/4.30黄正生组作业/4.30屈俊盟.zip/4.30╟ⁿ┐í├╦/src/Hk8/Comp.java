package Hk8;

public class Comp {
	public void useA(A a,Student[] student){
		a.a(student);
	}

		interface A{
			void a(Student[]stu);
		}
}

