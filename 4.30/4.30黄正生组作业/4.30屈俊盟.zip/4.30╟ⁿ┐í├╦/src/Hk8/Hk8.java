package Hk8;
/*
 * 写一个学生类：具有属性 id name score 
 * 要求实现compareable接口 完成以下排序功能，
 * 首先根据姓名排序，英文字母的自然顺序即可，姓名相同，根据id排序，
 * 如果id再相同，根据 score排序。
 * 要求在test中创建长度为5的学生类型数组，进行排序测试。 
 * 然后再创建3个类实现comparator接口，
 * 分别根据id,name,score单独排序，并且调用测试排序结果。
 */

import java.util.Arrays;
public class Hk8 {

	public static void main(String[] args) {
		Student[] student = new Student[4];
		student[0] = new Student(2,"linda",98);
		student[1] = new Student(5,"namei",99);
		student[2] = new Student(6,"lufei",90);
		student[3] = new Student(1,"suolong",100);
		Arrays.sort(student);
		for (Student i : student) {
			System.out.println(i);
		}
		System.out.println("*******************************");
		Id id=new Id();
		Comp comp=new Comp();
		comp.useA(id, student);
		for (Student i : student) {
			System.out.println(i);
		}

	}

}
