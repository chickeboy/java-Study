package Hk10;

public class Hk10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
