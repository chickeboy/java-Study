package Hk5;

interface Use{
	void use();
}
