package Hk5;

public class Elec implements Use{
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Elec() {
		
	}
	public Elec(String name) {
		this.name = name;
	}
	@Override
	public void use(){
		System.out.println("���");
	}
}
class Geogle implements Use{
	@Override
	public void use(){
		Elec elec=new Elec();
		elec.use();
		Clothing clothing=new Clothing();
		clothing.use();
	}

}
