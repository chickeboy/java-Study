package Hk5;

public class Clothing implements Use{
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Clothing() {
	
	}
	public Clothing(String name) {
		this.name = name;
	}
	@Override
	public void use(){
		System.out.println("�Դ�");
	}
}


