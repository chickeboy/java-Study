package Hk5;

public class Google implements Use{
	@Override
	public void use(){
		Elec elec=new Elec();
		elec.use();
		Clothing clothing=new Clothing();
		clothing.use();
	}

}
