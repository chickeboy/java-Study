package Hk5;
/*
 * 淘宝上的商品(Goods)种类繁多，
 * 有电器类(Elec)，有服装类(Clothing)。
 * 电器类商品都可以充电(IChargeable)，
 * 服装类商品都可以穿戴(IWearable)。
 * Google眼镜(GoogleGlass)属于电器类，
 * 却既可以充电，也可以穿戴。
 * 请根据题目描述创建相应的类、接口，
 * 正确关联它们的关系（继承 or 实现） 
 */

public class Hk5 {
	public static void main (String [] args) {
		Use use=new Google(); 
		Goods goods=new Goods();
		goods.makeUse(use);
	}

}
