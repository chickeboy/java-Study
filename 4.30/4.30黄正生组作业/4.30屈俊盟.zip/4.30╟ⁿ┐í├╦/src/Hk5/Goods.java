package Hk5;

public class Goods {
	public void makeUse(Use use){
		use.use();
	}
}

