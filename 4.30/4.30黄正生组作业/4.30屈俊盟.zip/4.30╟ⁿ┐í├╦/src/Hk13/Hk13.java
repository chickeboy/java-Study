package Hk13;

public class Hk13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
