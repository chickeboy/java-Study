package Hk1;

import java.util.Comparator;

public class CompareByScore implements Comparator<Person> {

	

	@Override
	public int compare(Person o1, Person o2) {
		// TODO Auto-generated method stub
		return o1.getScore()-o2.getScore();
	}

}


