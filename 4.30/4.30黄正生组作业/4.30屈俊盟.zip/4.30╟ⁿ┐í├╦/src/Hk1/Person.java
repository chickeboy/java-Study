package Hk1;

public class Person implements Comparable<Person>{
	private String name ;
	private int score;
	public Person(String name, int score) {
		super();
		this.name = name;
		this.score = score;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", score=" + score + "]";
	}
	@Override
	public int compareTo(Person o) {
		
		return name.compareTo(o.getName());
	}
	

}
