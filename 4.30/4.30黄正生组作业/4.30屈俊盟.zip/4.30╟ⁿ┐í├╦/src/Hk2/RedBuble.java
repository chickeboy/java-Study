package Hk2;

public class RedBuble extends Buble{
	

	@Override
	public void lingt() {
		System.out.println("�������");
		
	}
	

}
