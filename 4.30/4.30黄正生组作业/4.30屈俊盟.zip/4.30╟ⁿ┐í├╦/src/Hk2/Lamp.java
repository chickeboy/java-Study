package Hk2;

public class Lamp {
	public Buble b;

	public Lamp(Buble b) {
		super();
		this.b = b;
	}
	public void on() {
		b.lingt();
	}

}
