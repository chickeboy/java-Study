package Hk2;

public abstract class Buble {
	public abstract void lingt() ;
	}

