package Hk4;

public class Cheng extends Math{

	public Cheng(int a, int b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void suan() {
		// TODO Auto-generated method stub
		System.out.println(getA()*getB());
	}

}
