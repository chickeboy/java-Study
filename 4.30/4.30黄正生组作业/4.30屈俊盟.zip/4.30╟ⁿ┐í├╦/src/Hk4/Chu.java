package Hk4;

public class Chu extends Math{

	public Chu(int a, int b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void suan() {
		// TODO Auto-generated method stub
		System.out.println(getA()/getB());
	}

}
