package Hk4;

public class Jian extends Math{

	public Jian(int a, int b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void suan() {
		// TODO Auto-generated method stub
		System.out.println(getA()-getB());
	}

}
