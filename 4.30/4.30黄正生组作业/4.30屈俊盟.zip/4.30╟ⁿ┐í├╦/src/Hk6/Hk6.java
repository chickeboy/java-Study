package Hk6;
/*
 * 编写一个程序，要求：
1) 定义一个Student类（属性：学号、名字、成绩），
通过实现comparable接口让它具有比较大小的能力（通过成绩来比较）
2) 定义一个Student数组stus，
生成5个Student对象，存入stus中
3) 定义一个StudentTest类，
通过调用Arrays工具类中的sort方法来对stus中的元素进行排序。
 */

import java.util.Arrays;

public class Hk6 {
	public static void main (String [] args) {
		Student[] student = new Student[4];
		student[0] = new Student(2,"linda",98);
		student[1] = new Student(5,"namei",99);
		student[2] = new Student(6,"lufei",90);
		student[3] = new Student(1,"suolong",100);
		Arrays.sort(student);
		for (Student i : student) {
			System.out.println(i);
		}
	
	}

}
