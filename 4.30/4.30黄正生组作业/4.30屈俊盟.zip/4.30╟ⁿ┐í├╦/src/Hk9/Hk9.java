package Hk9;

public class Hk9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
