package Hk3;
/*
 * 有一个学生类，具有属性id  name  age  score
要求创建一个数组循环输入学生对象
学生本身带有排序规则 根据ID排序
再创建2个比较器 分别根据 年龄 或者 成绩排序
最后创建一个比较器,比较规则：先比名字，名字相比年龄，年龄相同比成绩。
分别调用输出。
 */
import java.util.Arrays;
public class Hk3 {
	public static void main (String [] args) {
		Students[] stus = new Students[5];
		stus[0] = new Students(1,"aa",24,90);
		stus[1] = new Students(2,"bb",23,92);
		stus[2] = new Students(3,"cc",22,91);
		stus[3] = new Students(4,"dd",25,95);
		stus[4] = new Students(5,"ee",26,91);
		Arrays.sort(stus);
		for (Students s : stus) {
			System.out.println(s);
		}
	}

}
