package Hk11;

abstract public class CanCry {
	public abstract  void c();

}
