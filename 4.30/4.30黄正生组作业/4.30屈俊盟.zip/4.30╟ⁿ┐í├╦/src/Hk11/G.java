package Hk11;

public class G {
	public void makeCry(Dog dog){
		dog.c();
	}
}

