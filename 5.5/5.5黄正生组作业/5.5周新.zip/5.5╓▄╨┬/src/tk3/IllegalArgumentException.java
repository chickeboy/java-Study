package tk3;

public class IllegalArgumentException extends Exception{
private String num;

@Override
public String toString() {
	return "IllegalArgumentException [num=" + num + "]";
}

public String getNum() {
	return num;
}

public void setNum(String num) {
	this.num = num;
}

public IllegalArgumentException(String num) {
	super();
	this.num = num;
}
}
