package tk4;

public class SickException extends Exception{
	private int num;
   public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
public SickException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SickException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
	public SickException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	public SickException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	public SickException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
public SickException(int num) {
		super();
		this.num = num;
	}
}
