package tk4;

import java.util.Random;

public class Worker {
	private int alive;

	public int getAlive() {
		return alive;
	}

	public void setAlive(int alive) {
		this.alive = alive;
	}

	public Worker() {
	}

	public Worker(int alive) {
		this.alive = alive;
	}
	public int work(){
		Random random=new Random();
		int t=-1;
		t=random.nextInt(10)+1;
		if(t>=7){
			t=1;
		}else{
			t=-1;
		}
		return t;
	}
}
