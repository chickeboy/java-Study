package tk4;

import java.util.Random;

public class Doctor {
public void cure(Worker worker){
	int t=0;
	Random random=new Random();
	t=random.nextInt(10)+1;
	if(t>=5){
		t=1;
	}else{
		t=-1;
	}if(t>0){
		worker.setAlive(1);
	}else{
		worker.setAlive(-1);
	}
}
}
