package tk2;

public class IllegalArgumentException extends Exception{
private int num;

public IllegalArgumentException(int string) {
	super();
	this.num = string;
}

public IllegalArgumentException() {
	// TODO Auto-generated constructor stub
}

public int getNum() {
	return num;
}

public void setNum(int num) {
	this.num = num;
}
}
