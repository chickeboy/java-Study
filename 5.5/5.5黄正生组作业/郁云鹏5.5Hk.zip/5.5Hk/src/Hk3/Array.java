package Hk3;

public class Array {
	static int get(char[] array, char a) {
		if(array==null){ 
			throw new IllegalArgumentException("���鲻��Ϊ�գ�");
		}
		for (int i = 0; i < array.length; i++) {
			if (array[i] == a) {
				return i+1;
			} 
		}
		return -1;
	}
}
