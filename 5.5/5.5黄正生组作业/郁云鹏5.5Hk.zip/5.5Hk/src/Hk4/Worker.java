package Hk4;

public class Worker {
        public void work() {
        	
        }
}
