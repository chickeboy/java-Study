package Hk2;

public class san {
	public static void  judge(int a,int b,int c) {
		try {			
			if((a+b)>c && (a+c)>b && (b+c)>a) {				
				System.out.println(a+","+b+","+c);
			}else {
				throw new IllegalArgumentException("a,b,c���ܹ���������");
			}
			
		}catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
}
