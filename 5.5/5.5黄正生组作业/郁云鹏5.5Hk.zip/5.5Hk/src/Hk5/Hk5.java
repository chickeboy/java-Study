package Hk5;

import java.util.InputMismatchException;
import java.util.Scanner;
public class Hk5 {
	public static void main(String[] args)  {
        // TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("������");
        int []array = new int[5];
        try{int i;
            for( i = 0;i<array.length;i++){
                array[i] = sc.nextInt();
            }
            System.out.println(array[i-1]);
      for(int j=0;j<array.length;j++)
            System.out.println(array[j]);
        }catch(InputMismatchException e){
            System.out.println("����������");
            e.printStackTrace();
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("������5������");
            e.printStackTrace();
        }finally{
            System.out.println("������");           
        }
    }

}
