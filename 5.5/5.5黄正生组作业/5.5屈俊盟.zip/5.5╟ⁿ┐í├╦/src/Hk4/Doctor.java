package Hk4;

public class Doctor {

}
