package Hk3;
import java.util.*;
public class Hk3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Judge judge = new Judge();
		Judge judge1 = new Judge();
		Judge judge2 = new Judge();
		char[] arr = new char[]{'a','b','c','d','e','f','7','$'};
		char[] arr_null = null;
		try {
			judge.CharSearch(arr, 'd');
			judge1.CharSearch(arr_null, '8');
			judge2.CharSearch(arr, '8');
		}catch (IllegalArgumentException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("�ټ�");
		}
	}

}

