package Hk4;

public class Hk4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Worker worker = new Worker();
		Doctor doctor = new Doctor();
		try {
			worker.work();
		} catch (SickException e) {
			doctor.cure(worker);
			if (worker.getAlive().equals("����")) {
				System.out.println("��ϲ��");
			} else {
				System.out.println("���Ǿ�����");
			}
		}

	}

}
