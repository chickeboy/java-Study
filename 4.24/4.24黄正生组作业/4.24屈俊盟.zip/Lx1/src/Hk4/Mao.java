package Hk4;

public class Mao {
	String name1="С��";
	String name2="С��";
	int age1=5;
	int age2=2;
	String eye1="��ɫ";
	String eye2="��ɫ";
	public void fu1() {
		System.out.println(name1+" "+age1+"��"+" "+eye1);
	}
	public void fu2() {
		System.out.println(name2+" "+age2+"��"+" "+eye2);
	}

}
