package Hk1;

class A {
	int v=100;

}
