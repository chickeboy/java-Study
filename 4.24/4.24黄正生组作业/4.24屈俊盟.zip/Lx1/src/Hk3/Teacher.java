package Hk3;

 class Teacher {
	 String name;
	 int age;
	 char xin;
	 int a;
	 public int jia(int a) {
		 a+=5000;
		 return a;
	 }
}
