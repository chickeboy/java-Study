package Hk1;

public class A {
        int v = 100;
}
