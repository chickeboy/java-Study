package Hk4;

public class Cat {
	String name;
	int age;
	char color;

	public Cat(String name, int age, char color) {
		this.name = name;
		this.age = age;
		this.color = color;
	}
	public String getName() {
		return name;
	}
	public int getage() {
		return age;
	}
	public char getColor() {
		return color;
	}

}
