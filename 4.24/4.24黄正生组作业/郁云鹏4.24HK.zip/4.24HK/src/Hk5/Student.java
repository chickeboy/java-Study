package Hk5;

public class Student {
	String name;
	int age;
	String xin;
	String major;

	public Student() {
	}

	public Student(String name, int age) {
		this.name = name;
		this.age = age;
		this.xin = "��";
		this.major = "Android";
	}

	public Student(String name, int age, String xin, String major) {
		this.name = name;
		this.age = age;
		this.xin = xin;
		this.major = major;
	}
	public void out() {
		System.out.println("�ҵ������ǣ�" + this.name + "������:" + this.age + "���Ա�" + this.xin + "��רҵ��" + this.major);
	}

}
