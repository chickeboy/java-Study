package Hk2;

public class Vehicle {
        int speed;
        int size;
        public void move() {
        	
        }
        public void setSpeed(int speed) {
        	
        }
        public void speedUp() {
        	 speed = speed + 20;
        }
        public void speedDown() {
        	 speed = speed - 20;
        }
}

