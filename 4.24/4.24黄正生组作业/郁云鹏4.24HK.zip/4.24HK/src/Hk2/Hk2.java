package Hk2;

public class Hk2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle veh = new Vehicle();
		veh.speed = 100;
		veh.size = 50;
		System.out.println("�ý�ͨ���ߵ��ٶ���:"+veh.speed+","+"�����:"+veh.size);		
		veh.speedUp();
		System.out.println(veh.speed);
		veh.speedDown();
		System.out.println(veh.speed);
	}

}
