package HK6;

public class HK6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****************");
		System.out.println("**   ��ȭ��ʼ        **");
		System.out.println("****************");
		Select select = new Select();
		select.name();
	}
}
