package HK3;

public class Teacher {
	String name;
	String sex;
	int age;
	int money;
	public void addmoney() {
		money+=5000;
		System.out.println(name+","+sex+","+age+","+money);
	}
}
