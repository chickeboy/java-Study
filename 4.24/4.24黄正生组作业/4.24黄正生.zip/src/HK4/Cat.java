package HK4;

public class Cat {
	String name;
	int age;
	String color;
	public void blackcat() {
		name = "С��";
		age = 2;
		color = "��ɫ";
		System.out.println(name+","+age+","+color);
	}
	public void whitecat() {
		name = "С��";
		age = 5;
		color = "��ɫ";
		System.out.println(name+","+age+","+color);
	}
}
