package Hk1;

class A {
	int V= 100;
}
