package Hk5;

public class Student {
	String name;
	int age;
	String sex;
	String major;

	public Student() {
	}

	public Student(String name, int age) {
		this.name = name;
		this.age = age;
		this.sex = "��";
		this.major = "Android";
	}

	public Student(String name, int age, String sex, String major) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.major = major;
	}

	public void setAge() {
		System.out.println("�ҵ������ǣ�" + this.name + "������:" + this.age + "���Ա�" + this.sex + "��רҵ��" + this.major);
	}

}
