package Hk4;

public class Cat {
	String name;
	int age;
	char color;

	public Cat(String name, int age, char color) {
		this.name = name;
		this.age = age;
		this.color = color;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getage() {
		return age;
	}

	public void setColor(char color) {
		this.color = color;
	}

	public char getColor() {
		return color;
	}

}
