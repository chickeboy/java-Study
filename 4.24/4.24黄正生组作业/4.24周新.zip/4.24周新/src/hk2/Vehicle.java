package hk2;

import java.util.Scanner;

class Vehicle {
int speed;
int size;

public int setSpeed(int speed) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("������һ����");
	speed=scanner.nextInt();
	return speed;
}
public int move(int size) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("������һ����");
	size=scanner.nextInt();
	return size;
}
public void speedUp() {
	speed*=2;
}
public void speedDown() {
	speed/=2;
}
}
