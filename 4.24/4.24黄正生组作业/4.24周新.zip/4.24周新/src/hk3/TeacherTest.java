package hk3;

class TeacherTest {
	String name="15";
	 int age=12;
	 char xin='��';
	 int xing=10000;
}
