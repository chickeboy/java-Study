package hk3;

 class Teacher {
	 String name;
	 int age;
	 char xin;
	 int xing;
	 public int jia(int xing) {
		 xing+=5000;
		 return xing;
	 }
}
