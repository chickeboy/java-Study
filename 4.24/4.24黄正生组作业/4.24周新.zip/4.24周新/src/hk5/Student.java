package HK5;

 class Student {
String name;
int gae;
char xing;
String zhuan;
public void print(){
	System.out.println(name+"\t"+"age"+"\n"+xing+"\t"+zhuan);
}
public Student(){
	xing='��';
	zhuan="Android";
}
}
