package HK5;

import java.util.Scanner;
 class StudentTest {
public static void main(String[] args) {
	Student student=new Student();
	student.name="dsfsg";
	student.gae=12;
	student.xing='Ů';
	student.zhuan="asdasfsdfs";
	student.print();
	Scanner scanner=new Scanner(System.in);
	System.out.println("������name");
	student.name=scanner.next();
	System.out.println("������age");
	student.gae=scanner.nextInt();
	System.out.println("�������Ա�");
	String str=scanner.next();
	student.xing=str.charAt(0);
	System.out.println("������רҵ");
	student.zhuan=scanner.next();
	student.print();
}
}
