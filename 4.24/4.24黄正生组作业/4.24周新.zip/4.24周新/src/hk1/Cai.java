package hk1;

import java.util.Scanner;

class Cai {
	 int a;
	 public int fu() {
		 System.out.println("������һ����");
		 Scanner scanner=new Scanner(System.in);
		 a=scanner.nextInt();
		 return a;
	 }
}
