package HK6;
public class Xu{
public int Switch (int a){
	int t=0;
 switch(a){
 case 1:
	 t=1;
	 break;
 case 2:
	 t=2;
	 break;
 case 3:
	 t=3;
	 break;
 }
 return t;
}}
