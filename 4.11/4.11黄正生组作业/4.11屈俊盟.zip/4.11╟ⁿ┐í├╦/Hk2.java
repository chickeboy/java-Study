//2.��1!+2!+3!+...+20!֮�͡�
public class Hk2{
    public static void main (String [] args){
		double sum =1l;
		double sum2=0l;
		for (int a=1;a<=20;a++){
			sum=sum*a;
			sum2=sum2+sum;
		}System.out.println(sum2);
	}
}
			
		
