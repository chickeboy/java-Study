//6.ʹ��˫��ѭ����ӡ��2������������ 4��ֱ��������
public class HK6{
public static void main(String[]agrs){
	for(int i=0;i<5;i++){   //4��ֱ��������
		for(int t=0;t<=i;t++){
			System.out.print("*");
		}
		System.out.println();
	}
	System.out.println("=================================");
	for(int i=0;i<5;i++){
		for(int t=5;t>i;t--){
			System.out.print("*");
		}
		System.out.println();
	}
	System.out.println("=================================");
	for(int i=0;i<5;i++){
		for(int t=0;t<i;t++){
		System.out.print(" ");}
		for(int t=5;t>i;t--){
			System.out.print("*");
		}
		System.out.println();
		}
		System.out.println("=================================");
		for(int i=0;i<5;i++){
		for(int t=5;t>i;t--){
		System.out.print(" ");}
		for(int t=0;t<i+1;t++){
			System.out.print("*");
		}
		System.out.println();
		}
		System.out.println("=================================");
		              //����������
		for(int i=0;i<10;i++){
            for(int j=0;j<i;j++){
                System.out.print(" ");    
            }
            for(int j=0;j<2*10-2*i -1;j++){
                System.out.print("*");    
            }
		System.out.println();  }  
		System.out.println("=================================");
		for(int i=0;i<10;i++){
            for(int j=10;j>i;j--){
                System.out.print(" ");    
            }
            for(int j=10;j>10-2*i -1;j--){
                System.out.print("*");    
            }
		System.out.println();  }  
}}