//1.��ѭ����ӡ��99�˷���ʹ��whileѭ����˫ѭ��
public class HK1{
public static void main(String[]agrs){
	
	for(int a=1;a<=9;a++){
		for(int b=1;b<=a;b++){
		System.out.print(a+"*"+b+"="+a*b+"	");
		}
		System.out.println("");
	}
	System.out.println("=============================================");
	int a=1;int b=1;
	while(a<=9){
		while(b<=a){
		System.out.print(a+"*"+b+"="+a*b+"	");
		b++;
		}
		a++;System.out.println();b=1;
	}
	
	
}}

