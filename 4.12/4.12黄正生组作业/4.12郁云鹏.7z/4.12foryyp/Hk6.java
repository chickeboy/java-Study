//6.ʹ��˫��ѭ����ӡ��2������������ 4��ֱ��������
public class Hk6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++){
	         for(int j=1;j<=i;j++){
	             System.out.print("*");
             }
	         System.out.println();
	         }
	     System.out.println("=================");	    
	     for(int i=1;i<=10;i++){
	    	   for(int j=10;j>=i;j--){
	    	System.out.print("*");
	    	   }
	    	System.out.println();
	    	 }
	     System.out.println("=================");
	     for(int i=0;i<8;i++){
	         for(int j=0;j<i;j++){
	             System.out.print(" ");
	             }
	         for (int j=14;j>2*i+1;j--){
	             System.out.print("*");
	             }
	             System.out.println();	 
	             }	 
	     System.out.println("=================");
	     for(int i=1;i<=10;i++){
	    	 for(int j =10;j>i;j--){
	    	 System.out.print(" ");
	    	 }
	    	 for(int j=1;j<=2*i-1;j++){
	    	 System.out.print("*");
	    	 }
	    	 System.out.println();
	    	 }	
        
		
	
	}
}
