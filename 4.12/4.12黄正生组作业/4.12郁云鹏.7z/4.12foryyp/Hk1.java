//1.ʹ��whileѭ����˫��ѭ����ӡ��99�˷���
public class Hk1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		 for(int i=1;i<=9;i++) {
//           for(int j=1;j<=i;j++) {
//             System.out.print(j+"��"+i+"="+i*j+"\t");
//          }
//             System.out.println();
//		 }
		int a = 1;
		while (a <= 9) {
		int b = 1;
		while (b <= a) {
		System.out.print(b + "*" + a+ "=" + a * b + "  ");
		b++;
		}
		a++;
		System.out.println();
		}
	}
}










