import java.util.Scanner;
public class Hk6{
public static void main(String[]agrs){ 
     double[]array=new double[5];
	for(int i=0;i<5;i++){
		Scanner scanner=new Scanner(System.in);
		System.out.println("����һ����");
		double num=scanner.nextDouble();
			array[i]=num;
	}
	double a=array[0];
	double b=array[1];
	double d=array[3];
	double e=array[4];
	array[0]=d;
	array[1]=e;
	array[3]=a;
	array[4]=b;
	for(int i=0;i<5;i++){
		System.out.print(array[i]+"	");
	}
}
}