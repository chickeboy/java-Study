//13.	����һ���������5�����ݣ�Ȼ��ͨ�����ַ�ʽ��ɶ�����ĸ�ֵ�����
import java.util.Scanner;
public class Hk13{
	public static void main(String[] args){			
		int[] arr = new int[5];	
		arr[0] = 3;
		arr[1] = 4;
		arr[2] = 1; 
		arr[3] = 9;
		arr[4] = 6;
		System.out.print(arr[0]+" ");
		System.out.print(arr[1]+" ");
		System.out.print(arr[2]+" ");
		System.out.print(arr[3]+" ");
		System.out.print(arr[4]+"\n");
		System.out.println("====================");		
		int[] arr2 = new int[]{1,3,5,7,9};
		System.out.print(arr2[0]+" ");
		System.out.print(arr2[1]+" ");
		System.out.print(arr2[2]+" ");
		System.out.print(arr2[3]+" ");
		System.out.print(arr2[4]+"\n");
		System.out.println("====================");
		{
			int[] array = new int[5];
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < array.length; i++) {
			System.out.print("������һ����: ");
			int num = scanner.nextInt();array[i] = num;
		}
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]+" ");
		}
	}
}
	}